# Subscription Expiration Automation System

## Overview
Automated system for managing subscription expiration, grace periods, and user notifications.

## Database Schema

### user_subscriptions table
```sql
CREATE TABLE user_subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  user_email TEXT NOT NULL,
  plan TEXT NOT NULL CHECK (plan IN ('daily', 'weekly', 'monthly', 'yearly')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'grace_period', 'cancelled')),
  start_date TIMESTAMP WITH TIME ZONE NOT NULL,
  end_date TIMESTAMP WITH TIME ZONE NOT NULL,
  grace_period_end TIMESTAMP WITH TIME ZONE,
  auto_renew BOOLEAN DEFAULT false,
  payment_method TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_user_subscriptions_user_id ON user_subscriptions(user_id);
CREATE INDEX idx_user_subscriptions_end_date ON user_subscriptions(end_date);
CREATE INDEX idx_user_subscriptions_status ON user_subscriptions(status);
```

### subscription_warnings table
```sql
CREATE TABLE subscription_warnings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_id UUID REFERENCES user_subscriptions(id) ON DELETE CASCADE,
  warning_sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  days_remaining INTEGER NOT NULL,
  email_sent BOOLEAN DEFAULT false
);
```

## Supabase Edge Function: Daily Subscription Checker

Create file: `supabase/functions/check-subscriptions/index.ts`

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const GRACE_PERIOD_DAYS = 3;

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  const now = new Date();
  const threeDaysFromNow = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

  // 1. Find subscriptions expiring in 3 days (send warning)
  const { data: expiringSoon } = await supabase
    .from('user_subscriptions')
    .select('*')
    .eq('status', 'active')
    .gte('end_date', now.toISOString())
    .lte('end_date', threeDaysFromNow.toISOString());

  for (const sub of expiringSoon || []) {
    // Check if warning already sent
    const { data: existingWarning } = await supabase
      .from('subscription_warnings')
      .select('*')
      .eq('subscription_id', sub.id)
      .gte('warning_sent_at', new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString())
      .single();

    if (!existingWarning) {
      // Send warning email (integrate with your email service)
      await sendWarningEmail(sub);
      
      // Log warning
      await supabase.from('subscription_warnings').insert({
        user_id: sub.user_id,
        subscription_id: sub.id,
        days_remaining: Math.ceil((new Date(sub.end_date).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)),
        email_sent: true
      });
    }
  }

  // 2. Find expired subscriptions and set grace period
  const { data: expired } = await supabase
    .from('user_subscriptions')
    .select('*')
    .eq('status', 'active')
    .lt('end_date', now.toISOString());

  for (const sub of expired || []) {
    const gracePeriodEnd = new Date(new Date(sub.end_date).getTime() + GRACE_PERIOD_DAYS * 24 * 60 * 60 * 1000);
    
    await supabase
      .from('user_subscriptions')
      .update({
        status: 'grace_period',
        grace_period_end: gracePeriodEnd.toISOString(),
        updated_at: now.toISOString()
      })
      .eq('id', sub.id);
  }

  // 3. Revoke access for subscriptions past grace period
  const { data: pastGrace } = await supabase
    .from('user_subscriptions')
    .select('*')
    .eq('status', 'grace_period')
    .lt('grace_period_end', now.toISOString());

  for (const sub of pastGrace || []) {
    await supabase
      .from('user_subscriptions')
      .update({
        status: 'expired',
        updated_at: now.toISOString()
      })
      .eq('id', sub.id);
  }

  return new Response(JSON.stringify({ success: true }), {
    headers: { 'Content-Type': 'application/json' }
  });
});

async function sendWarningEmail(subscription: any) {
  // Integrate with email service (SendGrid, Resend, etc.)
  console.log(`Sending warning email to ${subscription.user_email}`);
}
```

## Setup Instructions

1. Deploy edge function:
```bash
supabase functions deploy check-subscriptions
```

2. Set up cron job (use Supabase cron or external service):
```sql
-- Using pg_cron extension
SELECT cron.schedule(
  'check-subscriptions-daily',
  '0 0 * * *', -- Run at midnight daily
  $$
  SELECT net.http_post(
    url:='https://your-project.supabase.co/functions/v1/check-subscriptions',
    headers:='{"Authorization": "Bearer YOUR_ANON_KEY"}'::jsonb
  ) AS request_id;
  $$
);
```

## Email Integration

Configure email service in edge function. Options:
- Resend (recommended)
- SendGrid
- AWS SES
- Supabase Auth emails

## Frontend Integration

The system includes:
- `UserContext` - Tracks user subscription status
- `SubscriptionCountdown` - Displays days remaining
- Automatic checks every hour
- Toast notifications for expiration warnings

## Testing

Test the system:
1. Create test subscription with near-expiry date
2. Run edge function manually
3. Verify status updates and emails sent
4. Check grace period activation
5. Confirm access revocation after grace period
