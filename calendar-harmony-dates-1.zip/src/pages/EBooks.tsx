import { useState } from 'react';
import { ebooks, ebookCategories, EBook } from '@/data/ebooksData';
import EBookCard from '@/components/EBookCard';
import EBookDetailModal from '@/components/EBookDetailModal';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, BookOpen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function EBooks() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEBook, setSelectedEBook] = useState<EBook | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const filteredEBooks = ebooks.filter((ebook) => {
    const matchesCategory = selectedCategory === 'all' || ebook.category === selectedCategory;
    const matchesSearch = 
      ebook.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ebook.titleKhmer.includes(searchQuery) ||
      ebook.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ebook.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleDownload = (ebook: EBook) => {
    toast({
      title: 'Purchase Initiated',
      description: `Processing purchase for "${ebook.title}"`,
    });
    // In a real app, this would open a payment gateway
  };

  const handleViewDetails = (ebook: EBook) => {
    setSelectedEBook(ebook);
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <BookOpen className="w-16 h-16 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">E-Book Library</h1>
            <p className="text-xl mb-2">បណ្ណាល័យសៀវភៅអេឡិចត្រូនិក</p>
            <p className="text-lg opacity-90">Discover ancient wisdom through our collection of digital books</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search Bar */}
        <div className="mb-8">
          <div className="max-w-xl mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search books by title, author, or keyword..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 py-6 text-lg"
            />
          </div>
        </div>

        {/* Category Filters */}
        <div className="mb-8">
          <div className="flex flex-wrap justify-center gap-3">
            {ebookCategories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? 'default' : 'outline'}
                onClick={() => setSelectedCategory(category.id)}
                className="rounded-full"
              >
                {category.name}
                <span className="ml-2 text-xs opacity-75">{category.nameKhmer}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6 text-center">
          <p className="text-gray-600">
            Showing {filteredEBooks.length} of {ebooks.length} books
          </p>
        </div>

        {/* E-Books Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredEBooks.map((ebook) => (
            <EBookCard
              key={ebook.id}
              ebook={ebook}
              onDownload={handleDownload}
              onViewDetails={handleViewDetails}
            />
          ))}
        </div>

        {filteredEBooks.length === 0 && (
          <div className="text-center py-16">
            <BookOpen className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No books found</h3>
            <p className="text-gray-500">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      <EBookDetailModal
        ebook={selectedEBook}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onDownload={handleDownload}
      />
    </div>
  );
}
