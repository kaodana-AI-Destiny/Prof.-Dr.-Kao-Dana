import { AdminVerificationPanel } from '@/components/AdminVerificationPanel';

export default function Admin() {
  return <AdminVerificationPanel />;
}
