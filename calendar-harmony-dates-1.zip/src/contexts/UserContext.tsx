import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { UserSubscription } from '@/lib/subscriptionTypes';
import { getSubscriptionStatus, shouldSendWarning } from '@/utils/subscriptionChecker';
import { toast } from '@/components/ui/use-toast';

interface UserContextType {
  user: any;
  subscription: UserSubscription | null;
  isPremium: boolean;
  loading: boolean;
  checkSubscription: () => Promise<void>;
  logout: () => void;
}

const UserContext = createContext<UserContextType>({
  user: null,
  subscription: null,
  isPremium: false,
  loading: true,
  checkSubscription: async () => {},
  logout: () => {},
});

export const useUser = () => useContext(UserContext);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any>(null);
  const [subscription, setSubscription] = useState<UserSubscription | null>(null);
  const [loading, setLoading] = useState(true);

  const checkSubscription = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      if (data) {
        const status = getSubscriptionStatus(data);
        
        if (status === 'expired') {
          toast({
            title: "⚠️ Subscription Expired",
            description: "Your premium access has expired. Please renew to continue.",
            variant: "destructive",
          });
          setSubscription({ ...data, status: 'expired' });
        } else if (status === 'grace_period') {
          toast({
            title: "⏰ Grace Period Active",
            description: "Your subscription expired but you're in grace period. Renew soon!",
          });
          setSubscription({ ...data, status: 'grace_period' });
        } else {
          if (shouldSendWarning(data)) {
            toast({
              title: "⏰ Subscription Expiring Soon",
              description: "Your subscription expires in 3 days or less. Renew now!",
            });
          }
          setSubscription(data);
        }
      }
    } catch (error) {
      console.error('Error checking subscription:', error);
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    const { data: { subscription: authSub } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => authSub.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      checkSubscription();
      const interval = setInterval(checkSubscription, 1000 * 60 * 60); // Check hourly
      return () => clearInterval(interval);
    }
  }, [user]);

  const isPremium = subscription?.status === 'active' || subscription?.status === 'grace_period';

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSubscription(null);
  };

  return (
    <UserContext.Provider value={{ user, subscription, isPremium, loading, checkSubscription, logout }}>
      {children}
    </UserContext.Provider>
  );
};
