import { YearData } from "@/utils/calendarCalculator";
import YearCard from "./YearCard";

interface YearGridProps {
  years: YearData[];
  onYearClick: (yearData: YearData) => void;
}

export default function YearGrid({ years, onYearClick }: YearGridProps) {
  if (years.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-xl text-gray-500">No years found matching your criteria</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
      {years.map((yearData) => (
        <YearCard 
          key={yearData.year} 
          yearData={yearData} 
          onClick={() => onYearClick(yearData)}
        />
      ))}
    </div>
  );
}
