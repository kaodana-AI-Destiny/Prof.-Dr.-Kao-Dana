import { Period9FlyingStars, Period9StarData } from '@/utils/period9FlyingStarsCalculator';
import { starMeanings } from '@/data/flyingStarsData';
import { Card } from './ui/card';
import { CompassDiagram } from './CompassDiagram';
import { analyzeThreeStars } from '@/utils/flyingStarsAnalyzer';
import FlyingStarsSectorAnalysis from './FlyingStarsSectorAnalysis';

interface Period9FlyingStarsGridProps {
  stars: Period9FlyingStars;
  starGrid?: Period9StarData[];
  year?: number;
}

export function Period9FlyingStarsGrid({ stars, starGrid, year }: Period9FlyingStarsGridProps) {
  const { yearStar, monthStar, dayStar, timeStar, clashDirection, clashDegrees } = stars;
  const getStarInfo = (star: number) => starMeanings[star];

  const grid = starGrid ? [
    [starGrid[0], starGrid[1], starGrid[2]],
    [starGrid[3], starGrid[4], starGrid[5]],
    [starGrid[6], starGrid[7], starGrid[8]]
  ] : null;

  return (
    <div className="space-y-8">
      {/* 9-Box Grid with Period and Annual Stars */}
      {grid && year && (
        <div className="space-y-4">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-purple-900">Period & Annual Flying Stars {year}</h3>
            <p className="text-sm text-gray-600 mt-1">Period Star (blue) + Annual Star (purple)</p>
          </div>
          <div className="grid grid-cols-3 gap-2 max-w-2xl mx-auto">
            {grid.map((row, rowIdx) => (
              row.map((sector, colIdx) => (
                <Card key={`${rowIdx}-${colIdx}`} className="p-4 border-2 bg-gradient-to-br from-purple-50 to-blue-50">
                  <div className="text-center space-y-2">
                    <div className="text-xs font-semibold text-gray-700">{sector.direction}</div>
                    <div className="flex items-center justify-center gap-2">
                      <div className="text-3xl font-bold text-blue-600">{sector.periodStar}</div>
                      <div className="text-4xl font-bold text-purple-900">{sector.annualStar}</div>
                    </div>
                  </div>
                </Card>
              ))
            ))}
          </div>
        </div>
      )}

      {/* Stars Display */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className={`p-6 ${getStarInfo(yearStar).color} border-2`}>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{yearStar}</div>
            <div className="text-sm font-semibold mb-1">Year Star</div>
            <div className="text-xs">{getStarInfo(yearStar).name}</div>
          </div>
        </Card>
        <Card className={`p-6 ${getStarInfo(monthStar).color} border-2`}>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{monthStar}</div>
            <div className="text-sm font-semibold mb-1">Month Star</div>
            <div className="text-xs">{getStarInfo(monthStar).name}</div>
          </div>
        </Card>
        <Card className={`p-6 ${getStarInfo(dayStar).color} border-2`}>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{dayStar}</div>
            <div className="text-sm font-semibold mb-1">Day Star</div>
            <div className="text-xs">{getStarInfo(dayStar).name}</div>
          </div>
        </Card>
        <Card className={`p-6 ${getStarInfo(timeStar).color} border-2`}>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{timeStar}</div>
            <div className="text-sm font-semibold mb-1">Time Star</div>
            <div className="text-xs">{getStarInfo(timeStar).name}</div>
          </div>
        </Card>
      </div>
      <CompassDiagram clashDirection={clashDirection} />
      <Card className="p-6 bg-red-50 border-2 border-red-400">
        <div className="text-center">
          <h3 className="text-2xl font-bold text-red-700 mb-2">⚠️ Clash Direction</h3>
          <div className="text-4xl font-bold text-red-600 mb-2">{clashDirection}</div>
          <div className="text-lg text-gray-700">{clashDegrees}°</div>
        </div>
      </Card>
    </div>
  );
}
