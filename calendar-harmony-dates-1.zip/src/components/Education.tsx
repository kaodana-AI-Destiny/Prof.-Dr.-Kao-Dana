import { Card } from "@/components/ui/card";
import { Sparkles, Flame, Mountain, Droplets, Wind } from "lucide-react";
export default function Education() {
  return <div className="py-16 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-bold mb-4 text-3xl">ស្វែងយល់អំពីធាតុទាំង5-Understanding the Five Elements</h2>
          <p className="text-xl text-gray-600">The foundation of Feng Shui and Eastern astrology</p>
        </div>
        
        <div className="grid md:grid-cols-5 gap-6">
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-gray-700" />
            </div>
            <h3 className="font-bold text-lg mb-2">Metal</h3>
            <p className="text-sm text-gray-600">Strength, determination, persistence</p>
          </Card>
          
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 mx-auto mb-4 bg-blue-200 rounded-full flex items-center justify-center">
              <Droplets className="w-8 h-8 text-blue-700" />
            </div>
            <h3 className="font-bold text-lg mb-2">Water</h3>
            <p className="text-sm text-gray-600">Wisdom, flexibility, intuition</p>
          </Card>
          
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 mx-auto mb-4 bg-green-200 rounded-full flex items-center justify-center">
              <Wind className="w-8 h-8 text-green-700" />
            </div>
            <h3 className="font-bold text-lg mb-2">Wood</h3>
            <p className="text-sm text-gray-600">Growth, creativity, expansion</p>
          </Card>
          
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 mx-auto mb-4 bg-red-200 rounded-full flex items-center justify-center">
              <Flame className="w-8 h-8 text-red-700" />
            </div>
            <h3 className="font-bold text-lg mb-2">Fire</h3>
            <p className="text-sm text-gray-600">Passion, energy, transformation</p>
          </Card>
          
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 mx-auto mb-4 bg-amber-200 rounded-full flex items-center justify-center">
              <Mountain className="w-8 h-8 text-amber-700" />
            </div>
            <h3 className="font-bold text-lg mb-2">Earth</h3>
            <p className="text-sm text-gray-600">Stability, nurturing, balance</p>
          </Card>
        </div>
      </div>
    </div>;
}