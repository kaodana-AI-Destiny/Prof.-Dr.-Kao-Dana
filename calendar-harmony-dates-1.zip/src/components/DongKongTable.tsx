import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DongKongDate } from '@/utils/dongKongCalculator';

interface DongKongTableProps {
  dates: DongKongDate[];
}

export default function DongKongTable({ dates }: DongKongTableProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">Dong Kong Date Selection (動空日選)</CardTitle>
        <p className="text-sm text-gray-600 mt-2">
          Void periods in the Chinese calendar - days when certain activities should be avoided
        </p>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Day Pillar</TableHead>
              <TableHead>Void Branches</TableHead>
              <TableHead>Suitable For</TableHead>
              <TableHead>Unsuitable For</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {dates.map((date, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">{date.date}</TableCell>
                <TableCell className="text-lg">{date.stem}{date.branch}</TableCell>
                <TableCell>
                  {date.voidBranches.map((branch, i) => (
                    <Badge key={i} variant="outline" className="mr-1">{branch}</Badge>
                  ))}
                </TableCell>
                <TableCell className="text-green-600 text-sm">
                  {date.suitable.join(', ')}
                </TableCell>
                <TableCell className="text-red-600 text-sm">
                  {date.unsuitable.join(', ')}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
