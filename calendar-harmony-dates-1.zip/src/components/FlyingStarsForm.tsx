import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";
import { directions } from "../data/flyingStarsData";
interface FlyingStarsFormProps {
  onCalculate: (year: number, facing: string) => void;
}
export function FlyingStarsForm({
  onCalculate
}: FlyingStarsFormProps) {
  const [year, setYear] = useState<string>("2004");
  const [facing, setFacing] = useState<string>("South");
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCalculate(parseInt(year), facing);
  };
  return <Card>
      <CardHeader>
        <CardTitle>ម៉ាស៊ីនគណនាផ្កាយហោះហើរ Flying Stars Calculator</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="constructionYear">ឆ្នាំសាងសង់ Construction Year</Label>
            <Input id="constructionYear" type="number" min="1864" max="2043" value={year} onChange={e => setYear(e.target.value)} placeholder="e.g., 2004" />
          </div>
          <div>
            <Label htmlFor="facing">ទិសមុខ Facing Direction</Label>
            <Select value={facing} onValueChange={setFacing}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {directions.map(dir => <SelectItem key={dir} value={dir}>
                    {dir}
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full text-base">មើលតារាងរាសីផ្ទះរបស់អ្នក Calculate Flying Stars</Button>
        </form>
      </CardContent>
    </Card>;
}