import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { completeAuxiliaryStars } from '@/data/auxiliaryStarsComplete';

interface AuxiliaryStarsResultProps {
  chart: any;
}

export function AuxiliaryStarsResult({ chart }: AuxiliaryStarsResultProps) {
  if (!chart) return null;

  const dayMasterElement = chart.day.stem.element;
  const dayMasterPolarity = chart.day.stem.polarity;
  const dayMasterKey = `${dayMasterElement} ${dayMasterPolarity}`;

  const starsData = completeAuxiliaryStars.find(
    (s) => s.dayMaster === dayMasterKey
  );

  if (!starsData) return null;

  const pillars = [
    { name: 'Year', stem: chart.year.stem.chinese, branch: chart.year.branch.chinese },
    { name: 'Month', stem: chart.month.stem.chinese, branch: chart.month.branch.chinese },
    { name: 'Day', stem: chart.day.stem.chinese, branch: chart.day.branch.chinese },
    { name: 'Hour', stem: chart.hour.stem.chinese, branch: chart.hour.branch.chinese }
  ];

  const checkStar = (starValue: string | string[]) => {
    const values = Array.isArray(starValue) ? starValue : [starValue];
    const found: string[] = [];
    
    pillars.forEach(pillar => {
      values.forEach(val => {
        if (pillar.stem === val || pillar.branch === val) {
          found.push(pillar.name);
        }
      });
    });
    
    return found;
  };

  const stars = [
    { name: 'ផ្កាយគេជួយ Noble Person', value: starsData.noblePerson, color: 'bg-blue-500' },
    { name: 'ផ្កាយសិក្សាឆ្លាត Academic Star', value: starsData.academicStar, color: 'bg-green-500' },
    { name: 'ផ្កាយស្នេហ៍ Peach Blossom', value: starsData.peachBlossom, color: 'bg-pink-500' },
    { name: 'ផ្កាយធ្វើដំណើរ Travelling Horse', value: starsData.travellingHorse, color: 'bg-indigo-500' },
    { name: 'ផ្កាយវិចិត្រកម្ម Artist Star', value: starsData.artistStar, color: 'bg-purple-500' },
    { name: 'ផ្កាយមរណៈ Death Star', value: starsData.deathStar, color: 'bg-gray-600' },
    { name: 'ផ្កាយឯកកោ Lonesome Star', value: starsData.lonesomeStar, color: 'bg-slate-600' },
    { name: 'ផ្កាយចោរ Robbery Star', value: starsData.robberyStar, color: 'bg-orange-600' },
    { name: 'ផ្កាយប្រយុទ្ធ Sword Star', value: starsData.swordStar, color: 'bg-red-600' },
    { name: 'ផ្កាយនាគគុណធម៌ Dragon Virtue', value: starsData.dragonVirtue, color: 'bg-emerald-500' },
    { name: 'ផ្កាយទ្រព្យ Rob Wealth', value: starsData.robWealth, color: 'bg-amber-600' },
    { name: 'ផ្កាយព្រះអាទិត្យ Sun Star', value: starsData.sunStar, color: 'bg-yellow-500' },
    { name: 'ផ្កាយព្រះចន្ទ័ Moon Star', value: starsData.moonStar, color: 'bg-blue-300' },
    { name: 'ផ្កាយសំណាងសួគ៌ Heaven Virtue', value: starsData.heavenVirtue, color: 'bg-cyan-500' },
    { name: 'ផ្កាយសុភមង្គល Sky Happiness', value: starsData.skyHappiness, color: 'bg-teal-500' }
  ];


  return (
    <Card>
      <CardHeader>
        <CardTitle>ការវិភាគផ្កាយជំនួយរបស់អ្នក Your Auxiliary Stars Analysis</CardTitle>
        <p className="text-sm text-muted-foreground">
          ថ្ងៃតួខ្លួន Day Master: {starsData.chineseName} - {dayMasterKey}

        </p>

      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left p-2">ឈ្មោះផ្កាយ Star Name</th>
                <th className="text-left p-2">មែក/ដើម Branch/Stem</th>
                <th className="text-left p-2">មានក្នុង Present In</th>
                <th className="text-left p-2">ស្ថានភាព Status</th>
              </tr>

            </thead>
            <tbody>
              {stars.map((star) => {
                const foundIn = checkStar(star.value);

                const isPresent = foundIn.length > 0;
                
                return (
                  <tr key={star.name} className={`border-b ${isPresent ? 'bg-green-50' : ''}`}>
                    <td className="p-2 font-medium">{star.name}</td>
                    <td className="p-2">
                      <Badge className={star.color}>
                        {Array.isArray(star.value) ? star.value.join(', ') : star.value}
                      </Badge>
                    </td>
                    <td className="p-2">
                      {foundIn.length > 0 ? (
                        <div className="flex gap-1 flex-wrap">
                          {foundIn.map((pillar) => (
                            <Badge key={pillar} variant="outline">{pillar}</Badge>
                          ))}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </td>
                    <td className="p-2">
                      {isPresent ? (
                        <Badge className="bg-green-600">✓ មាន Present</Badge>
                      ) : (
                        <Badge variant="outline">មិនមាន Not Present</Badge>
                      )}
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
