import { zodiacAnimals } from "@/data/zodiacData";
import { YearData } from "@/utils/calendarCalculator";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { calculateKuaNumber } from "@/utils/fengShuiCalculator";

interface YearCardProps {
  yearData: YearData;
  onClick: () => void;
}

const elementColors: Record<string, string> = {
  Metal: "bg-gray-200 text-gray-800",
  Water: "bg-blue-200 text-blue-800",
  Wood: "bg-green-200 text-green-800",
  Fire: "bg-red-200 text-red-800",
  Earth: "bg-amber-200 text-amber-800"
};

export default function YearCard({ yearData, onClick }: YearCardProps) {
  const zodiac = zodiacAnimals[yearData.zodiacIndex];
  const maleKua = calculateKuaNumber(yearData.year, 'male');
  const femaleKua = calculateKuaNumber(yearData.year, 'female');
  
  return (
    <Card 
      className="overflow-hidden cursor-pointer hover:shadow-xl transition-all transform hover:scale-105"
      onClick={onClick}
    >
      <div className="aspect-square overflow-hidden bg-gradient-to-br from-blue-900 to-purple-900">
        <img 
          src={zodiac.image} 
          alt={zodiac.name}
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-2xl font-bold">{yearData.year}</h3>
          <Badge variant="outline">{yearData.polarity}</Badge>
        </div>
        
        <p className="text-lg font-semibold mb-1">{zodiac.name}</p>
        <p className="text-sm text-gray-600 mb-3">{zodiac.khmerName}</p>
        
        <Badge className={`${elementColors[yearData.element]} mb-2`}>
          {yearData.elementType} {yearData.element}
          {yearData.element === "Metal" && (yearData.polarity === "Yang" ? " លោហៈ+" : " លោហៈ-")}
          {yearData.element === "Water" && (yearData.polarity === "Yang" ? " ទឹក+" : " ទឹក-")}
          {yearData.element === "Wood" && (yearData.polarity === "Yang" ? " ឈើ+" : " ឈើ-")}
          {yearData.element === "Fire" && (yearData.polarity === "Yang" ? " ភ្លើង+" : " ភ្លើង-")}
          {yearData.element === "Earth" && (yearData.polarity === "Yang" ? " ដី+" : " ដី-")}
        </Badge>

        <div className="flex gap-2 mt-2">
          <Badge variant="secondary" className="text-xs">
            ♂ Kua: {maleKua}
          </Badge>
          <Badge variant="secondary" className="text-xs">
            ♀ Kua: {femaleKua}
          </Badge>
        </div>
      </div>
    </Card>
  );
}

