import { useMemo } from "react";
import { calculateDailyData } from "@/utils/dailyCalculator";
import { zodiacAnimals } from "@/data/zodiacData";
import { Card } from "./ui/card";
export default function DailyZodiac() {
  const dailyData = useMemo(() => calculateDailyData(), []);
  const zodiac = zodiacAnimals[dailyData.zodiacIndex];
  const khmerDays = ['អាទិត្យ', 'ចន្ទ', 'អង្គារ', 'ពុធ', 'ព្រហស្បតិ៍', 'សុក្រ', 'សៅរ៍'];
  const dayOfWeek = dailyData.date.getDay();
  const khmerDay = khmerDays[dayOfWeek];
  const dateStr = dailyData.date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const fullDateStr = `${khmerDay} ${dateStr}`;
  return <div className="max-w-7xl mx-auto px-4 py-12">
      <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200 p-8">
        <div className="text-center mb-6">
          <h2 className="font-bold text-gray-800 mb-2 text-2xl">សត្វ-ធាតុ ប្រចាំថ្ងៃនេះ | Element & Zodiac of the Day</h2>
          <p className="text-lg text-gray-600">{fullDateStr}</p>

        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="text-center">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="text-xl font-semibold mb-4 text-amber-700">សត្វប្រចាំថ្ងៃ | Daily Zodiac</h3>
              {zodiac.image && <img src={zodiac.image} alt={zodiac.name} className="w-32 h-32 mx-auto mb-4 rounded-full object-cover" />}
              <p className="text-2xl font-bold text-gray-800">{zodiac.khmerName}</p>
              <p className="text-xl text-gray-600 mt-2">{zodiac.name}</p>
            </div>
          </div>
          
          <div className="text-center">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="text-xl font-semibold mb-4 text-amber-700">ធាតុប្រចាំថ្ងៃ | Daily Element</h3>
              <div className="py-8">
                <p className="text-2xl font-bold text-gray-800 mb-3">
                  {dailyData.khmerElement}{dailyData.polarity === 'Yang' ? '+' : '-'} {dailyData.hNumber} {dailyData.chineseChar} {dailyData.element} {dailyData.polarity}
                </p>
              </div>
            </div>
          </div>

        </div>
      </Card>
    </div>;
}