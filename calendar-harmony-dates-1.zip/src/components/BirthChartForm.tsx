import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
interface BirthChartFormProps {
  onSubmit: (date: Date, hour: number, gender: 'male' | 'female') => void;
  onClear?: () => void;
  onUseTodayBoth?: (date: Date, hour: number) => void;
}
export default function BirthChartForm({
  onSubmit,
  onClear,
  onUseTodayBoth
}: BirthChartFormProps) {
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");
  const [gender, setGender] = useState("");
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !time || !gender) return;
    const birthDate = new Date(date + "T" + time);
    const hour = birthDate.getHours();
    onSubmit(birthDate, hour, gender as 'male' | 'female');
  };
  const handleClear = () => {
    setDate("");
    setTime("");
    setLocation("");
    setGender("");
    // Call parent's onClear to clear results
    if (onClear) {
      onClear();
    }
  };
  const handleExampleDate = () => {
    // Get current time in Cambodia timezone (UTC+7)
    const now = new Date();
    const utcTime = now.getTime() + now.getTimezoneOffset() * 60000;
    const cambodiaTime = new Date(utcTime + 7 * 3600000); // UTC+7

    const todayStr = cambodiaTime.toISOString().split('T')[0];
    const timeStr = cambodiaTime.toTimeString().slice(0, 5); // HH:MM format

    setDate(todayStr);
    setTime(timeStr);

    // If onUseTodayBoth is provided, generate results for both genders
    if (onUseTodayBoth) {
      const birthDate = new Date(todayStr + "T" + timeStr);
      const hour = birthDate.getHours();
      onUseTodayBoth(birthDate, hour);
    }
  };
  return <Card className="p-8 max-w-3xl mx-auto bg-gradient-to-br from-amber-50 to-orange-50 shadow-xl">
      <h3 className="font-bold mb-2 text-center bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-[#0f56c9] text-xl">បំពេញវេលាកើត ដើម្បីមើលលទ្ធផលតារាងរាសីដំណើរជីវិតអ្នក</h3>
      <div className="flex items-center justify-center gap-3 mb-6">
        <p className="text-center text-gray-600">Generate Your BaZi Birth Chart</p>
        <button type="button" onClick={handleClear} className="text-sm text-blue-600 hover:text-blue-800 underline font-medium">
          Clear
        </button>
      </div>
      
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="date" className="text-lg font-semibold">
              បំពេញខែ-ថ្ងៃ-ឆ្នាំកើត Birth Date *
            </Label>
            <Input id="date" type="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-2 text-lg" />
          </div>
          
          <div>
            <Label htmlFor="time" className="text-lg font-semibold">
              បំពេញ ម៉ោងកើត Birth Time *
            </Label>
            <Input id="time" type="time" value={time} onChange={e => setTime(e.target.value)} required className="mt-2 text-lg" />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="location" className="text-lg font-semibold">
              ប្រទេសដែលអ្នកបានកើត Birth Location
            </Label>
            <Input id="location" type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="City, Country" className="mt-2" />
          </div>

          <div>
            <Label htmlFor="gender" className="text-lg font-semibold">Gender</Label>
            <Select value={gender} onValueChange={setGender}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex gap-4">
          <Button type="submit" className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white py-6 font-semibold text-2xl">ចុចមើលតារាងរាសីនិងលទ្ធផល Generate Chart</Button>
          <Button type="button" onClick={handleExampleDate} variant="outline" className="py-6">
            Use Today
          </Button>
        </div>
      </form>
    </Card>;
}