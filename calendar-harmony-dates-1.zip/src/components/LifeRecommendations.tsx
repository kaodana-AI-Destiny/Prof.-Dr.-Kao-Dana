import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface LifeRecommendationsProps {
  dayMasterElement: string;
  dominantElement: string;
  elements: { [key: string]: number };
}

export default function LifeRecommendations({ dayMasterElement, dominantElement, elements }: LifeRecommendationsProps) {
  const elementColors: { [key: string]: { color: string; direction: string; season: string } } = {
    Wood: { color: "បៃតង Green", direction: "ខាងកើត East", season: "រដូវផ្កា Spring" },
    Fire: { color: "ក្រហម Red", direction: "ខាងត្បូង South", season: "រដូវក្តៅ Summer" },
    Earth: { color: "លឿង/ត្នោត Yellow/Brown", direction: "កណ្តាល Center", season: "ចុងរដូវក្តៅ Late Summer" },
    Metal: { color: "ស/មាស White/Gold", direction: "ខាងលិច West", season: "រដូវស្លឹកឈើជ្រុះ Autumn" },
    Water: { color: "ខ្មៅ/ខៀវ Black/Blue", direction: "ខាងជើង North", season: "រដូវរងា Winter" }
  };


  const careerPaths: { [key: string]: string[] } = {
    Wood: ["សិល្បៈ Arts", "អប់រំ Education", "សុខាភិបាល Healthcare", "បរិស្ថាន Environmental", "ម៉ូដ Fashion", "ការរចនា Design"],
    Fire: ["កម្សាន្ត Entertainment", "លក់ Sales", "ទីផ្សារ Marketing", "ការនិយាយជាសាធារណៈ Public Speaking", "ភាពជាអ្នកដឹកនាំ Leadership", "ប្រព័ន្ធផ្សព្វផ្សាយ Media"],
    Earth: ["អចលនទ្រព្យ Real Estate", "កសិកម្ម Agriculture", "សំណង់ Construction", "គ្រប់គ្រង Management", "ហិរញ្ញវត្ថុ Finance", "ការបម្រើសេវា Hospitality"],
    Metal: ["ច្បាប់ Law", "យោធា Military", "វិស្វកម្ម Engineering", "បច្ចេកវិទ្យា Technology", "ហិរញ្ញវត្ថុ Finance", "ការវះកាត់ Surgery"],
    Water: ["ស្រាវជ្រាវ Research", "ចិត្តវិទ្យា Psychology", "ខាងវិញ្ញាណ Spirituality", "សរសេរ Writing", "ប្រឹក្សា Consulting", "ទស្សនវិជ្ជា Philosophy"]
  };


  const healthTips: { [key: string]: string } = {
    Wood: "ផ្តោតលើសុខភាពថ្លើម និងប្រមាត់។ អនុវត្តលំហាត់ភាពបត់បែន។ Focus on liver and gallbladder health. Practice flexibility exercises.",
    Fire: "រក្សាសុខភាពបេះដូង និងចរន្តឈាម។ តុល្យភាពសកម្មភាព និងសម្រាក។ Maintain heart and circulation health. Balance activity with rest.",
    Earth: "គាំទ្រប្រព័ន្ធរំលាយអាហារ។ រក្សាទម្លាប់ និងរបបអាហារឱ្យមានស្ថេរភាព។ Support digestive system. Maintain stable routines and diet.",
    Metal: "ថែទាំសួត និងប្រព័ន្ធដង្ហើម។ អនុវត្តលំហាត់ដកដង្ហើម។ Care for lungs and respiratory system. Practice breathing exercises.",
    Water: "គាំទ្រសុខភាពតម្រងនោម និងប្លោកនោម។ ផឹកទឹកឱ្យបានគ្រប់គ្រាន់ និងសម្រាកឱ្យបានល្អ។ Support kidney and bladder health. Stay hydrated and rest well."
  };


  const luckyInfo = elementColors[dayMasterElement];

  return (
    <Card className="p-6 bg-gradient-to-br from-teal-50 to-cyan-50">
      <h4 className="font-bold text-xl mb-6">អនុសាសន៍ និងការណែនាំជីវិត Life Recommendations & Guidance</h4>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="p-4 bg-white rounded-lg border-l-4 border-teal-500">
            <h5 className="font-bold text-teal-900 mb-2">ពណ៌សំណាង Lucky Colors</h5>
            <p className="text-gray-700">{luckyInfo.color}</p>
          </div>
          
          <div className="p-4 bg-white rounded-lg border-l-4 border-blue-500">
            <h5 className="font-bold text-blue-900 mb-2">ទិសមង្គល Auspicious Direction</h5>
            <p className="text-gray-700">{luckyInfo.direction}</p>
          </div>

          <div className="p-4 bg-white rounded-lg border-l-4 border-purple-500">
            <h5 className="font-bold text-purple-900 mb-2">រដូវកាលល្អ Favorable Season</h5>
            <p className="text-gray-700">{luckyInfo.season}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-white rounded-lg border-l-4 border-orange-500">
            <h5 className="font-bold text-orange-900 mb-2">ផ្លូវអាជីព Career Paths</h5>
            <div className="flex flex-wrap gap-2">
              {careerPaths[dominantElement].map(career => (
                <Badge key={career} className="bg-orange-100 text-orange-800">{career}</Badge>
              ))}
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg border-l-4 border-green-500">
            <h5 className="font-bold text-green-900 mb-2">ផ្តោតលើសុខភាព Health Focus</h5>
            <p className="text-sm text-gray-700">{healthTips[dayMasterElement]}</p>
          </div>
        </div>
      </div>
    </Card>
  );
}
