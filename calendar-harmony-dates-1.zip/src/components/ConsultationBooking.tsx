import { useState } from "react";
import ConsultantCard from "./ConsultantCard";
import BookingModal, { BookingData } from "./BookingModal";
import ReviewModal from "./ReviewModal";
import ManageBookingModal from "./ManageBookingModal";
import { consultants, Consultant } from "@/data/consultantsData";
import { reviews } from "@/data/consultantReviews";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, Calendar, Star } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
export default function ConsultationBooking() {
  const [selectedConsultant, setSelectedConsultant] = useState<Consultant | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [filterSpecialty, setFilterSpecialty] = useState("All");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [confirmedBooking, setConfirmedBooking] = useState<BookingData | null>(null);
  const [myBookings, setMyBookings] = useState<BookingData[]>([]);
  const [waitlist, setWaitlist] = useState<{
    consultant: Consultant;
    email: string;
  }[]>([]);
  const handleBookClick = (consultant: Consultant) => {
    setSelectedConsultant(consultant);
    setIsModalOpen(true);
  };
  const handleBookingConfirm = (bookingData: BookingData) => {
    setConfirmedBooking(bookingData);
    setMyBookings([...myBookings, bookingData]);
    setIsModalOpen(false);
    setShowConfirmation(true);

    // Simulate email/SMS confirmation and reminders
    console.log("Booking confirmed:", bookingData);
    console.log("Email confirmation sent to:", bookingData.email);
    if (bookingData.reminderEmail) console.log("Email reminder scheduled for 24 hours before");
    if (bookingData.reminderSMS) console.log("SMS reminder scheduled for 2 hours before");
    if (bookingData.videoPlatform === 'zoom') console.log("Zoom link will be sent:", "https://zoom.us/j/meeting-id");
    if (bookingData.videoPlatform === 'google-meet') console.log("Google Meet link will be sent:", "https://meet.google.com/meeting-id");
    setTimeout(() => setShowConfirmation(false), 10000);
  };
  const handleReviewSubmit = (rating: number, comment: string) => {
    console.log("Review submitted:", {
      consultant: selectedConsultant?.name,
      rating,
      comment
    });
    alert("Thank you for your review!");
  };
  const handleReschedule = (newDate: Date, newTime: string) => {
    console.log("Booking rescheduled to:", newDate, newTime);
    alert("Your booking has been rescheduled successfully!");
  };
  const handleCancel = () => {
    console.log("Booking cancelled with refund policy applied");
    alert("Your booking has been cancelled. Refund will be processed according to our policy.");
  };
  const handleJoinWaitlist = (consultant: Consultant, email: string) => {
    setWaitlist([...waitlist, {
      consultant,
      email
    }]);
    console.log("Added to waitlist:", consultant.name, email);
    alert(`You've been added to the waitlist for ${consultant.name}. We'll notify you when slots become available.`);
  };
  const filteredConsultants = filterSpecialty === "All" ? consultants : consultants.filter(c => c.specialty === filterSpecialty || c.specialty === 'Both');
  return <div className="bg-gradient-to-b from-purple-50 to-pink-50 py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-bold mb-4 text-[#060885] text-xl">🎯 ទំនាក់ទំនង ប្រឹក្សាយោបល់ និងសេវាកម្ម ជាមួយ សាស្ត្រាចារ្យ បណ្ឌិទ​កៅ ដាណា (ជំនាញវិទ្យាសាស្ត្រ បរិស្ថាន ហុងស៊ុយ និង ជោគជតារាសី ប៉ាត់សឺ ចិន-តេលេក្រាម 070-356-897 /085-933-365/097-999-4639) Book a Consultation</h2>
          <p className="text-xl text-gray-600 mb-6">
            Connect with expert Feng Shui and BaZi consultants for personalized guidance
          </p>
        </div>

        {showConfirmation && confirmedBooking && <Alert className="mb-8 bg-green-50 border-green-200">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <AlertDescription className="text-green-800" data-mixed-content="true">
              <strong>Booking Confirmed!</strong> Your {confirmedBooking.videoPlatform === 'zoom' ? 'Zoom' : confirmedBooking.videoPlatform === 'google-meet' ? 'Google Meet' : 'in-person'} consultation with {confirmedBooking.consultant.name} on{' '}
              {confirmedBooking.date.toLocaleDateString()} at {confirmedBooking.time} has been confirmed.
              {confirmedBooking.isGroup && ` (Group of ${confirmedBooking.groupSize})`}
              {confirmedBooking.isRecurring && ` (Recurring ${confirmedBooking.recurringFrequency})`}
              {' '}A confirmation email has been sent to {confirmedBooking.email}.
            </AlertDescription>
          </Alert>}

        {myBookings.length > 0 && <div className="mb-8 bg-white rounded-lg shadow p-4">
            <h3 className="font-bold mb-3 flex items-center gap-2"><Calendar className="w-5 h-5" />My Bookings</h3>
            <div className="space-y-2">
              {myBookings.map((booking, idx) => <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                  <div>
                    <p className="font-semibold">{booking.consultant.name}</p>
                    <p className="text-sm text-gray-600" data-mixed-content="true">{booking.date.toLocaleDateString()} at {booking.time}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => {
                setConfirmedBooking(booking);
                setIsManageModalOpen(true);
              }}>Manage</Button>
                    <Button size="sm" variant="outline" onClick={() => {
                setSelectedConsultant(booking.consultant);
                setIsReviewModalOpen(true);
              }}>Review</Button>
                  </div>
                </div>)}
            </div>
          </div>}

        <div className="flex justify-center mb-8">
          <div className="w-64">
            <Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
              <SelectTrigger><SelectValue placeholder="Filter by specialty" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Consultants</SelectItem>
                <SelectItem value="Feng Shui">Feng Shui Only</SelectItem>
                <SelectItem value="BaZi">BaZi Only</SelectItem>
                <SelectItem value="Both">Both Specialties</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredConsultants.map(consultant => <ConsultantCard key={consultant.id} consultant={consultant} onBook={handleBookClick} />)}
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2"><Star className="w-5 h-5 text-amber-500" />Recent Reviews</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reviews.slice(0, 4).map(review => <div key={review.id} className="border rounded p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex">{Array(review.rating).fill(0).map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />)}</div>
                  <span className="text-sm font-semibold">{review.userName}</span>
                </div>
                <p className="text-sm text-gray-600 mb-1">{review.comment}</p>
                <p className="text-xs text-gray-400" data-mixed-content="true">{review.sessionType} • {review.date}</p>
              </div>)}
          </div>
        </div>


        <div className="mt-12 bg-white rounded-lg shadow-lg p-8">
          <h3 className="text-2xl font-bold mb-4 text-center">How It Works</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-amber-600">1</span>
              </div>
              <h4 className="font-bold mb-2">Choose Consultant</h4>
              <p className="text-sm text-gray-600">Select from our expert consultants</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-amber-600">2</span>
              </div>
              <h4 className="font-bold mb-2">Pick Date & Time</h4>
              <p className="text-sm text-gray-600">Select your preferred slot</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-amber-600">3</span>
              </div>
              <h4 className="font-bold mb-2">Secure Payment</h4>
              <p className="text-sm text-gray-600">Complete your booking securely</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-amber-600">4</span>
              </div>
              <h4 className="font-bold mb-2">Get Confirmation</h4>
              <p className="text-sm text-gray-600">Receive email with details</p>
            </div>
          </div>
        </div>
      </div>

      <BookingModal consultant={selectedConsultant} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onConfirm={handleBookingConfirm} />
      
      <ReviewModal consultantName={selectedConsultant?.name || ''} isOpen={isReviewModalOpen} onClose={() => setIsReviewModalOpen(false)} onSubmit={handleReviewSubmit} />
      
      <ManageBookingModal booking={confirmedBooking} isOpen={isManageModalOpen} onClose={() => setIsManageModalOpen(false)} onReschedule={handleReschedule} onCancel={handleCancel} />
    </div>;
}