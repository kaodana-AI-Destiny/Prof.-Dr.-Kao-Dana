import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { supabase, PaymentVerification } from '@/lib/supabase';
import { CheckCircle, XCircle, Clock, ExternalLink } from 'lucide-react';

export function AdminVerificationPanel() {
  const [verifications, setVerifications] = useState<PaymentVerification[]>([]);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchVerifications();
    
    const subscription = supabase
      .channel('payment_verifications')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payment_verifications' }, () => {
        fetchVerifications();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchVerifications = async () => {
    try {
      const { data, error } = await supabase
        .from('payment_verifications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVerifications(data || []);
    } catch (error) {
      console.error('Error fetching verifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerification = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const { error } = await supabase
        .from('payment_verifications')
        .update({
          status,
          verified_at: new Date().toISOString(),
          admin_notes: notes[id] || ''
        })
        .eq('id', id);

      if (error) throw error;
      
      fetchVerifications();
      setNotes(prev => ({ ...prev, [id]: '' }));
    } catch (error) {
      console.error('Error updating verification:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading verifications...</div>;
  }

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Payment Verification Admin Panel</h1>
      
      <div className="grid gap-4">
        {verifications.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-gray-500">
              No payment verifications yet
            </CardContent>
          </Card>
        ) : (
          verifications.map((verification) => (
            <Card key={verification.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{verification.user_name}</CardTitle>
                    <p className="text-sm text-gray-600">{verification.user_email}</p>
                    <p className="text-sm text-gray-600">{verification.user_phone}</p>
                  </div>
                  <Badge className={
                    verification.status === 'approved' ? 'bg-green-500' :
                    verification.status === 'rejected' ? 'bg-red-500' :
                    'bg-yellow-500'
                  }>
                    {verification.status === 'approved' && <CheckCircle className="w-4 h-4 mr-1" />}
                    {verification.status === 'rejected' && <XCircle className="w-4 h-4 mr-1" />}
                    {verification.status === 'pending' && <Clock className="w-4 h-4 mr-1" />}
                    {verification.status.toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-semibold">Plan</p>
                    <p>{verification.plan_name}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Price</p>
                    <p>{verification.plan_price}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Submitted</p>
                    <p>{new Date(verification.created_at).toLocaleString()}</p>
                  </div>
                  {verification.verified_at && (
                    <div>
                      <p className="text-sm font-semibold">Verified</p>
                      <p>{new Date(verification.verified_at).toLocaleString()}</p>
                    </div>
                  )}
                </div>

                <div>
                  <p className="text-sm font-semibold mb-2">Receipt</p>
                  <a 
                    href={verification.receipt_url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-blue-600 hover:underline"
                  >
                    View Receipt <ExternalLink className="w-4 h-4" />
                  </a>
                </div>

                {verification.admin_notes && (
                  <div>
                    <p className="text-sm font-semibold mb-1">Admin Notes</p>
                    <p className="text-sm text-gray-600">{verification.admin_notes}</p>
                  </div>
                )}

                {verification.status === 'pending' && (
                  <div className="space-y-3">
                    <Textarea
                      placeholder="Add notes (optional)"
                      value={notes[verification.id] || ''}
                      onChange={(e) => setNotes(prev => ({ ...prev, [verification.id]: e.target.value }))}
                    />
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => handleVerification(verification.id, 'approved')}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                      <Button 
                        onClick={() => handleVerification(verification.id, 'rejected')}
                        variant="destructive"
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
