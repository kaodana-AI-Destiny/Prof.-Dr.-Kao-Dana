import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { extendedAuxiliaryStars } from '@/data/auxiliaryStarsExtended';

interface ExtendedAuxiliaryStarsTableProps {
  currentDayMaster?: string;
}

export function ExtendedAuxiliaryStarsTable({ currentDayMaster }: ExtendedAuxiliaryStarsTableProps) {
  const getElementColor = (element: string) => {
    switch (element) {
      case 'Wood': return 'bg-green-100 text-green-800 border-green-300';
      case 'Fire': return 'bg-red-100 text-red-800 border-red-300';
      case 'Earth': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Metal': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'Water': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">ផ្កាយជំនួយពង្រីក Extended Auxiliary Stars by ថ្ងៃតួខ្លួន Day Master</CardTitle>


        <CardDescription>
          មគ្គុទ្ទេសក៍ទូលំទូលាយអំពីផ្កាយស្នេហ៍, ផ្កាយធ្វើដំណើរ, ផ្កាយវិចិត្រកម្ម, ផ្កាយមរណៈ, ផ្កាយឯកកោ, ផ្កាយចោរ និងផ្កាយប្រយុទ្ធ
          Comprehensive guide to Peach Blossom, Travelling Horse, Artist, Death, Lonesome, Robbery, and Sword Stars
        </CardDescription>

      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[160px]">ថ្ងៃតួខ្លួន Day Master</TableHead>
                <TableHead className="w-[90px]">ធាតុ Element</TableHead>
                <TableHead className="w-[110px]">ផ្កាយស្នេហ៍<br/>Peach Blossom<br/>桃花</TableHead>
                <TableHead className="w-[110px]">ផ្កាយធ្វើដំណើរ<br/>Travel Horse<br/>驛馬</TableHead>
                <TableHead className="w-[110px]">ផ្កាយវិចិត្រកម្ម<br/>Artist Star<br/>紅艷</TableHead>
                <TableHead className="w-[110px]">ផ្កាយមរណៈ<br/>Death Star<br/>亡神</TableHead>
                <TableHead className="w-[110px]">ផ្កាយឯកកោ<br/>Lonesome<br/>孤辰</TableHead>
                <TableHead className="w-[110px]">ផ្កាយចោរ<br/>Robbery<br/>劫煞</TableHead>
                <TableHead className="w-[110px]">ផ្កាយប្រយុទ្ធ<br/>Sword Star<br/>羊刃</TableHead>
              </TableRow>

            </TableHeader>
            <TableBody>
              {extendedAuxiliaryStars.map((dm) => {
                const isCurrentDayMaster = currentDayMaster && dm.chineseName.includes(currentDayMaster);
                return (
                  <TableRow 
                    key={dm.dayMaster}
                    className={isCurrentDayMaster ? 'bg-purple-50 border-l-4 border-l-purple-500' : ''}
                  >
                    <TableCell className="font-semibold">
                      <div className="flex flex-col gap-1">
                        <span className="text-sm">{dm.dayMaster}</span>
                        <span className="text-base text-purple-700">{dm.chineseName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getElementColor(dm.element)}>
                        {dm.element}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-pink-100 text-pink-800 text-xs">
                        {dm.peachBlossom}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-indigo-100 text-indigo-800 text-xs">
                        {dm.travellingHorse}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-purple-100 text-purple-800 text-xs">
                        {dm.artistStar}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-gray-100 text-gray-800 text-xs">
                        {dm.deathStar}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-slate-100 text-slate-800 text-xs">
                        {dm.lonesomeStar}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">
                        {dm.robberyStar}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-red-100 text-red-800 text-xs">
                        {dm.swordStar}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <div className="mt-4 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-semibold text-sm mb-2">អត្ថន័យផ្កាយ Star Meanings:</h4>
          <ul className="text-xs space-y-1 text-gray-700">
            <li><strong>ផ្កាយស្នេហ៍ Peach Blossom (桃花):</strong> ស្នេហា ភាពទាក់ទាញ ការទាក់ទាញសង្គម Romance, charm, attraction, social appeal</li>
            <li><strong>ផ្កាយធ្វើដំណើរ Travelling Horse (驛馬):</strong> ចលនា ការធ្វើដំណើរ ការផ្លាស់ប្តូរ Movement, travel, relocation, changes</li>
            <li><strong>ផ្កាយវិចិត្រកម្ម Artist Star (紅艷):</strong> គំនិតច្នៃប្រឌិត ទេពកោសល្យសិល្បៈ Creativity, artistic talent, aesthetic sense</li>
            <li><strong>ផ្កាយមរណៈ Death Star (亡神):</strong> ការផ្លាស់ប្តូរ ការបញ្ចប់ ការយល់ឃើញខាងវិញ្ញាណ Transformation, endings, spiritual insight</li>
            <li><strong>ផ្កាយឯកកោ Lonesome Star (孤辰):</strong> ភាពឯកោ ឯករាជ្យភាព ការពិចារណាខាងក្នុង Solitude, independence, introspection</li>
            <li><strong>ផ្កាយចោរ Robbery Star (劫煞):</strong> បញ្ហាប្រឈម ការប្រកួតប្រជែង ការយកឈ្នះឧបសគ្គ Challenges, competition, overcoming obstacles</li>
            <li><strong>ផ្កាយប្រយុទ្ធ Sword Star (羊刃):</strong> ថាមពលស្រួច ការសម្រេចចិត្ត ការឈ្លានពានសក្តានុពល Sharp energy, decisiveness, potential aggression</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
