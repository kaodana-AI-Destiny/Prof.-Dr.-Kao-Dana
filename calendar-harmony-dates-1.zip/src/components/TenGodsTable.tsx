import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { tenGodsDetailed } from "@/data/tenGodsDetailedData";
import { BaZiChart } from "@/utils/baziCalculator";

interface TenGodsTableProps {
  chart: BaZiChart;
}

export default function TenGodsTable({ chart }: TenGodsTableProps) {
  const pillars = [
    { name: "ឆ្នាំ Year", pillar: chart.year },
    { name: "ខែ Month", pillar: chart.month },
    { name: "ថ្ងៃ Day", pillar: chart.day },
    { name: "ម៉ោង Hour", pillar: chart.hour }
  ];


  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      "Companion Star": "bg-blue-100 text-blue-800 border-blue-300",
      "Output Star": "bg-green-100 text-green-800 border-green-300",
      "Wealth Star": "bg-yellow-100 text-yellow-800 border-yellow-300",
      "Officer Star": "bg-red-100 text-red-800 border-red-300",
      "Resource Star": "bg-purple-100 text-purple-800 border-purple-300"
    };
    return colors[category] || "bg-gray-100 text-gray-800 border-gray-300";
  };

  return (
    <Card className="p-8 bg-gradient-to-br from-indigo-50 to-purple-50">
      <h3 className="text-3xl font-bold mb-6 text-center">
        ការវិភាគទាំងស្រុងនៃសមត្ថភាពទាំង១០ Ten Gods Comprehensive Analysis (十神详解)
      </h3>


      
      <div className="mb-6 p-4 bg-white rounded-lg border-2 border-purple-300">
        <h4 className="font-bold text-lg mb-2">ថ្ងៃតួខ្លួន Day Master Reference</h4>

        <div className="text-center">
          <span className="text-2xl font-bold text-purple-900">
            {chart.dayMaster.chinese} {chart.dayMaster.name}
          </span>
          <span className="ml-3 text-lg text-purple-700">
            ({chart.dayMaster.element} {chart.dayMaster.polarity})
          </span>
        </div>
      </div>

      <div className="space-y-6">
        {pillars.map((pillarData) => {
          if (!pillarData.pillar.tenGod) return null;
          
          const tenGodKey = pillarData.pillar.tenGod.english.toLowerCase().replace(/\s+/g, '').replace('/', '');
          const details = tenGodsDetailed[tenGodKey];
          
          if (!details) return null;

          return (
            <div key={pillarData.name} className="bg-white rounded-lg p-6 shadow-md border-l-4 border-purple-500">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="text-xl font-bold text-purple-900">
                    {pillarData.name} សសរ Pillar: {details.chinese} ({details.english})
                  </h4>
                  <p className="text-sm text-gray-600">{details.pinyin}</p>
                </div>
                <Badge className={getCategoryColor(details.category)}>
                  {details.category}
                </Badge>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h5 className="font-semibold text-purple-800 mb-2">👤 បុគ្គលិកលក្ខណៈ Personality</h5>
                  <p className="text-sm text-gray-700 mb-3">{details.personality}</p>
                  
                  <h5 className="font-semibold text-purple-800 mb-2">💼 អាជីព Career</h5>
                  <p className="text-sm text-gray-700">{details.career}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-purple-800 mb-2">❤️ ទំនាក់ទំនង Relationships</h5>
                  <p className="text-sm text-gray-700 mb-3">{details.relationships}</p>
                  
                  <h5 className="font-semibold text-purple-800 mb-2">💰 ទ្រព្យសម្បត្តិ Wealth</h5>
                  <p className="text-sm text-gray-700">{details.wealth}</p>

                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mt-4 pt-4 border-t">
                <div>
                  <h5 className="font-semibold text-green-700 mb-2">✓ ចំណុចខ្លាំង Strengths</h5>
                  <ul className="text-sm space-y-1">
                    {details.strengths.map((strength, idx) => (
                      <li key={idx} className="text-green-600">• {strength}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h5 className="font-semibold text-orange-700 mb-2">⚠ ចំណុចខ្សោយ Weaknesses</h5>
                  <ul className="text-sm space-y-1">
                    {details.weaknesses.map((weakness, idx) => (
                      <li key={idx} className="text-orange-600">• {weakness}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

          );
        })}
      </div>
    </Card>
  );
}
