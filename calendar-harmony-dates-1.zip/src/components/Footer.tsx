import { Calendar, Heart, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";


export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-6 h-6 text-amber-400" />
              <span className="font-bold text-lg">Khmer Calendar</span>
            </div>
            <p className="text-gray-400 text-sm">
              Explore 193 years of Khmer zodiac, feng shui elements, and astrological wisdom from 1920 to 2112.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#calendar-section" className="hover:text-amber-400 transition-colors">Calendar</a></li>
              <li><Link to="/ebooks" className="hover:text-amber-400 transition-colors flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                E-Books Library
              </Link></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Zodiac Animals</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Elements</a></li>
            </ul>
          </div>

          
          <div>
            <h4 className="font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-amber-400 transition-colors">About Feng Shui</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Khmer Culture</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Astrology Guide</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-amber-400 transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
          <p className="flex items-center justify-center gap-2">
            Made with <Heart className="w-4 h-4 text-red-500" /> for preserving cultural wisdom
          </p>
          <p className="mt-2">© 2024 Khmer Calendar & Feng Shui. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
