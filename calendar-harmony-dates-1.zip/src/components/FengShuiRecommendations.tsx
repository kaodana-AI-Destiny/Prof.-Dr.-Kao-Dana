import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import ColorPalette from './ColorPalette';
import { FengShuiProfile } from '@/utils/fengShuiCalculator';
import { Home, Briefcase, UtensilsCrossed, Sofa, DoorOpen } from 'lucide-react';

interface FengShuiRecommendationsProps {
  profile: FengShuiProfile;
}

export default function FengShuiRecommendations({ profile }: FengShuiRecommendationsProps) {
  const roomIcons = {
    bedroom: Home,
    office: Briefcase,
    kitchen: UtensilsCrossed,
    livingRoom: Sofa,
    entrance: DoorOpen
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="text-2xl">🧭</span>
            ទម្រង់ហ្វឹងស៊ុយរបស់អ្នក Your Feng Shui Profile
          </CardTitle>

        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">លេខគួ Kua Number</h3>
              <div className="text-4xl font-bold text-amber-600">{profile.kuaNumber}</div>
              <Badge className="mt-2">ក្រុម {profile.group} Group</Badge>
              <div className="mt-4 space-y-2">
                <p className="text-sm"><strong>កន្លែងអង្គុយល្អបំផុត Best Sitting:</strong> {profile.bestSittingDirection}</p>
                <p className="text-sm"><strong>ទិសមុខល្អបំផុត Best Facing:</strong> {profile.bestFacingDirection}</p>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">ទិសល្អ Favorable Directions</h3>
              <div className="bg-gradient-to-br from-green-50 to-blue-50 p-4 rounded-lg">
                <div className="mb-3">
                  <h4 className="text-sm font-semibold text-green-700 mb-2">ទិសល្អបំផុត Best Directions</h4>
                  <div className="flex flex-wrap gap-2">
                    {profile.favorableDirections.best.map(dir => (
                      <Badge key={dir} className="bg-green-500">{dir}</Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-blue-700 mb-2">ទិសល្អ Good Directions</h4>
                  <div className="flex flex-wrap gap-2">
                    {profile.favorableDirections.good.map(dir => (
                      <Badge key={dir} className="bg-blue-500">{dir}</Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ពណ៌និងលេខសំណាង Lucky Colors & Numbers</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <ColorPalette colors={profile.luckyColors} />
          <div>
            <h4 className="text-sm font-semibold mb-2 text-gray-700">លេខសំណាង Lucky Numbers</h4>
            <div className="flex gap-2">
              {profile.luckyNumbers.map(num => (
                <div key={num} className="w-12 h-12 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold text-lg shadow-lg">
                  {num}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ទីតាំងបន្ទប់ Room Placements</CardTitle>

        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {Object.entries(profile.roomPlacements).map(([room, direction]) => {
              const Icon = roomIcons[room as keyof typeof roomIcons];
              return (
                <div key={room} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Icon className="w-5 h-5 text-amber-600" />
                  <div>
                    <div className="font-semibold capitalize">{room.replace(/([A-Z])/g, ' $1').trim()}</div>
                    <div className="text-sm text-gray-600">{direction}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
