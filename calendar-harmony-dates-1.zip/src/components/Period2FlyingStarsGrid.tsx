import { Period2StarData } from '@/utils/period2FlyingStarsCalculator';
import { Card } from './ui/card';
import { analyzeThreeStars } from '@/utils/flyingStarsAnalyzer';
import FlyingStarsSectorAnalysis from './FlyingStarsSectorAnalysis';

interface Period2FlyingStarsGridProps {
  starGrid: Period2StarData[];
  year: number;
  month: number;
}

export function Period2FlyingStarsGrid({ starGrid, year, month }: Period2FlyingStarsGridProps) {
  const grid = [
    [starGrid[0], starGrid[1], starGrid[2]],
    [starGrid[3], starGrid[4], starGrid[5]],
    [starGrid[6], starGrid[7], starGrid[8]]
  ];

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3 className="text-2xl font-bold text-orange-900">Period 2 Flying Stars - {year}/{month}</h3>
        <p className="text-sm text-gray-600 mt-1">Period (blue) + Annual (purple) + Monthly (pink)</p>
      </div>
      <div className="grid grid-cols-3 gap-2 max-w-2xl mx-auto">
        {grid.map((row, rowIdx) => (
          row.map((sector, colIdx) => (
            <Card key={`${rowIdx}-${colIdx}`} className="p-4 border-2 bg-gradient-to-br from-orange-50 to-blue-50">
              <div className="text-center space-y-2">
                <div className="text-xs font-semibold text-gray-700">{sector.direction}</div>
                <div className="flex items-center justify-center gap-1">
                  <div className="text-2xl font-bold text-blue-600">{sector.periodStar}</div>
                  <div className="text-3xl font-bold text-purple-900">{sector.annualStar}</div>
                  <div className="text-2xl font-bold text-pink-600">{sector.monthlyStar}</div>
                </div>
              </div>
            </Card>
          ))
        ))}
      </div>


      {/* Detailed Sector Analysis */}
      <div className="mt-8">
        <h3 className="text-xl font-bold text-center mb-4">Detailed Sector Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {starGrid.map((sector) => {
            const analysis = analyzeThreeStars(
              sector.direction,
              sector.periodStar,
              sector.annualStar,
              sector.monthlyStar
            );
            return <FlyingStarsSectorAnalysis key={sector.direction} analysis={analysis} />;
          })}
        </div>
      </div>
    </div>
  );
}

