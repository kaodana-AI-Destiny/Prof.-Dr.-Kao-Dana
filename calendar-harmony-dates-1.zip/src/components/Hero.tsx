import { Calendar, Sparkles, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";

export default function Hero() {

  const scrollToCalendar = () => {
    document.getElementById('calendar-section')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  return <div className="relative h-[500px] overflow-hidden">
      <div className="absolute inset-0 bg-cover bg-center" style={{
      backgroundImage: `url('https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147363031_4b350521.webp')`
    }}>
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent"></div>
      </div>
      
      <div className="relative h-full max-w-7xl mx-auto px-4 flex items-center">
        <div className="max-w-2xl text-white">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-amber-400" />
            <span className="font-semibold text-center text-white text-xs">Ten Thousand Year Calendar 1920 - 2112 by Prof. Dr. KAO Dana (Environmental Feng Shui and Astrology)</span>
          </div>
          
          <h1 className="md:text-6xl font-bold mb-4 text-center text-4xl"><br />KAO AI-Destiny</h1>
          
          <p className="mb-8 text-[#f1f6a3] text-2xl text-left">ទាយវាសនាខ្លូនឯង និងមើលហុងស៊ុយផ្ទះខ្លួនឯង តាមរយៈថ្ងៃកំណើត និងមើលទិសហេង-ឆុងប្រចាំយុគ-ឆ្នាំ-ខែ-ថ្ងៃ-ម៉ោង Plot your BaZi Chart and Find Feng Shui Flying Star Direction based on your Birth Date and Finding Clash Direction in Each Period, Year, Month, Day and Time, using Khmer&Chinese Astrological Calendar (1920-2112) by Prof. Dr. KAO DANA</p>
          
          <button onClick={scrollToCalendar} className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 rounded-lg font-semibold transition-all transform hover:scale-105 flex items-center gap-2 text-base text-center">
            <Calendar className="w-5 h-5" />
            ស្វែងរកឆ្នាំកើត Explore Calendar
          </button>
        </div>
      </div>
    </div>;
}