import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { calculateDailyData, DailyData } from "@/utils/dailyCalculator";
import { zodiacAnimals } from "@/data/zodiacData";
import { getChineseMonth, getChineseYear } from "@/utils/chineseMonthCalculator";
import DayDetailModal from "./DayDetailModal";
interface MonthlyCalendarProps {
  onGenerateBazi?: (date: Date, hour: number) => void;
}
export default function MonthlyCalendar({
  onGenerateBazi
}: MonthlyCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<DailyData | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDayOfWeek = firstDay.getDay();
  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const handleDayClick = (day: number) => {
    const date = new Date(year, month, day);
    const dayData = calculateDailyData(date);
    setSelectedDay(dayData);
    setIsModalOpen(true);
  };
  const monthName = currentDate.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric'
  });
  const days = [];
  for (let i = 0; i < startingDayOfWeek; i++) {
    days.push(<div key={`empty-${i}`} />);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    const dailyData = calculateDailyData(date);
    const zodiac = zodiacAnimals[dailyData.zodiacIndex];
    const chineseMonth = getChineseMonth(date);
    const chineseYear = getChineseYear(date);
    const isToday = isCurrentMonth && today.getDate() === day;
    const elementColors: Record<string, string> = {
      Wood: 'bg-green-100 border-green-300',
      Fire: 'bg-red-100 border-red-300',
      Earth: 'bg-yellow-100 border-yellow-300',
      Metal: 'bg-gray-100 border-gray-300',
      Water: 'bg-blue-100 border-blue-300'
    };
    days.push(<Card key={day} onClick={() => handleDayClick(day)} className={`p-2 cursor-pointer hover:shadow-lg transition-all border-2 ${elementColors[chineseMonth.element] || ''} ${isToday ? 'ring-2 ring-blue-500' : ''}`}>
        <div className="text-sm font-semibold mb-1">{day}</div>
        <div className="text-xs text-center font-medium text-purple-700 mb-1">
          {chineseMonth.chineseChar} {chineseMonth.animal}
        </div>
        <img src={zodiac.image} alt={zodiac.name} className="w-8 h-8 mx-auto mb-1" />
        <div className="text-xs text-center truncate">{zodiac.name}</div>
        <div className="text-xs text-center text-gray-600">
          {dailyData.khmerElement}{dailyData.polarity === 'Yang' ? '+' : '-'} {dailyData.hNumber} {dailyData.chineseChar}
        </div>
        <div className="text-xs text-center text-gray-600">{dailyData.element} {dailyData.polarity}</div>
      </Card>);

  }
  return <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="text-center mb-8">
        <h2 className="font-bold mb-2 text-3xl">ថ្ងៃ សត្វ-ធាតុ Monthly Zodiac Calendar</h2>
        <p className="text-xl text-gray-600">ប្រតិទិនសត្វនិងធាតុប្រចាំខែ</p>
      </div>

      <div className="flex items-center justify-between mb-6">
        <Button onClick={prevMonth} variant="outline" size="lg">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h3 className="text-2xl font-bold">{monthName}</h3>
        <Button onClick={nextMonth} variant="outline" size="lg">
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>

      <div className="grid grid-cols-7 gap-2 mb-2">
        {['អាទិត្យ Sun', 'ចន្ទ Mon', 'អង្គារ Tue', 'ពុធ Wed', 'ព្រហស្បតិ៍ Thu', 'សុក្រ Fri', 'សៅរ៍ Sat'].map(day => <div key={day} className="text-center font-semibold text-gray-700 py-2 text-sm">{day}</div>)}
      </div>


      <div className="grid grid-cols-7 gap-2">{days}</div>

      <DayDetailModal dayData={selectedDay} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onGenerateBazi={onGenerateBazi} />

    </div>;
}