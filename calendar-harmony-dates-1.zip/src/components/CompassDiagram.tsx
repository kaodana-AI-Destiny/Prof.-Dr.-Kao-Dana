import { useState } from 'react';
import { Card } from './ui/card';

interface CompassDiagramProps {
  clashDirection: string;
}

const earthlyBranches = [
  { chinese: '子', english: 'Rat (Zi)', direction: 'N', degrees: 0 },
  { chinese: '丑', english: 'Ox (Chou)', direction: 'NNE', degrees: 30 },
  { chinese: '寅', english: 'Tiger (Yin)', direction: 'ENE', degrees: 60 },
  { chinese: '卯', english: 'Rabbit (Mao)', direction: 'E', degrees: 90 },
  { chinese: '辰', english: 'Dragon (Chen)', direction: 'ESE', degrees: 120 },
  { chinese: '巳', english: 'Snake (Si)', direction: 'SSE', degrees: 150 },
  { chinese: '午', english: 'Horse (Wu)', direction: 'S', degrees: 180 },
  { chinese: '未', english: 'Goat (Wei)', direction: 'SSW', degrees: 210 },
  { chinese: '申', english: 'Monkey (Shen)', direction: 'WSW', degrees: 240 },
  { chinese: '酉', english: 'Rooster (You)', direction: 'W', degrees: 270 },
  { chinese: '戌', english: 'Dog (Xu)', direction: 'WNW', degrees: 300 },
  { chinese: '亥', english: 'Pig (Hai)', direction: 'NNW', degrees: 330 },
];

export function CompassDiagram({ clashDirection }: CompassDiagramProps) {
  const [hoveredBranch, setHoveredBranch] = useState<string | null>(null);

  return (
    <Card className="p-8 bg-gradient-to-br from-slate-50 to-slate-100">
      <h3 className="text-xl font-bold text-center mb-6">Compass Rose - Earthly Branches</h3>
      <div className="relative w-full max-w-md mx-auto aspect-square">
        {/* Compass Circle */}
        <svg viewBox="0 0 400 400" className="w-full h-full">
          {/* Background circles */}
          <circle cx="200" cy="200" r="180" fill="white" stroke="#cbd5e1" strokeWidth="2" />
          <circle cx="200" cy="200" r="140" fill="none" stroke="#e2e8f0" strokeWidth="1" />
          <circle cx="200" cy="200" r="100" fill="none" stroke="#e2e8f0" strokeWidth="1" />
          
          {/* Cardinal lines */}
          <line x1="200" y1="20" x2="200" y2="380" stroke="#94a3b8" strokeWidth="1" />
          <line x1="20" y1="200" x2="380" y2="200" stroke="#94a3b8" strokeWidth="1" />
          
          {/* Earthly branches */}
          {earthlyBranches.map((branch, index) => {
            const angle = branch.degrees - 90;
            const radian = (angle * Math.PI) / 180;
            const x = 200 + 160 * Math.cos(radian);
            const y = 200 + 160 * Math.sin(radian);
            const isClash = branch.direction === clashDirection;
            
            return (
              <g key={index}>
                {/* Sector highlight for clash */}
                {isClash && (
                  <path
                    d={`M 200 200 L ${200 + 180 * Math.cos((branch.degrees - 105) * Math.PI / 180)} ${200 + 180 * Math.sin((branch.degrees - 105) * Math.PI / 180)} A 180 180 0 0 1 ${200 + 180 * Math.cos((branch.degrees - 75) * Math.PI / 180)} ${200 + 180 * Math.sin((branch.degrees - 75) * Math.PI / 180)} Z`}
                    fill="rgba(239, 68, 68, 0.2)"
                    stroke="rgb(239, 68, 68)"
                    strokeWidth="2"
                  />
                )}
                
                {/* Branch circle */}
                <circle
                  cx={x}
                  cy={y}
                  r="24"
                  fill={isClash ? '#ef4444' : hoveredBranch === branch.english ? '#3b82f6' : '#64748b'}
                  stroke="white"
                  strokeWidth="2"
                  className="cursor-pointer transition-all"
                  onMouseEnter={() => setHoveredBranch(branch.english)}
                  onMouseLeave={() => setHoveredBranch(null)}
                />
                
                {/* Chinese character */}
                <text
                  x={x}
                  y={y + 6}
                  textAnchor="middle"
                  fill="white"
                  fontSize="18"
                  fontWeight="bold"
                  className="pointer-events-none"
                >
                  {branch.chinese}
                </text>
              </g>
            );
          })}
          
          {/* Center circle */}
          <circle cx="200" cy="200" r="30" fill="#1e293b" stroke="white" strokeWidth="2" />
          <text x="200" y="210" textAnchor="middle" fill="white" fontSize="14" fontWeight="bold">
            中心
          </text>
        </svg>
        
        {/* Hover tooltip */}
        {hoveredBranch && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/80 text-white px-4 py-2 rounded-lg pointer-events-none z-10">
            <div className="text-sm font-semibold">{hoveredBranch}</div>
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div className="mt-6 flex justify-center gap-6 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-slate-600 rounded-full"></div>
          <span>Normal</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-red-500 rounded-full"></div>
          <span>Clash Direction</span>
        </div>
      </div>
    </Card>
  );
}
