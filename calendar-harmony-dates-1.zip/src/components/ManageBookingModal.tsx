import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar as CalendarIcon, Clock, AlertCircle } from "lucide-react";

interface ManageBookingModalProps {
  booking: any;
  isOpen: boolean;
  onClose: () => void;
  onReschedule: (newDate: Date, newTime: string) => void;
  onCancel: () => void;
}

export default function ManageBookingModal({ booking, isOpen, onClose, onReschedule, onCancel }: ManageBookingModalProps) {
  const [mode, setMode] = useState<'view' | 'reschedule' | 'cancel'>('view');
  const [newDate, setNewDate] = useState<Date>();
  const [newTime, setNewTime] = useState("");

  const timeSlots = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00", "17:00"];

  const handleReschedule = () => {
    if (newDate && newTime) {
      onReschedule(newDate, newTime);
      setMode('view');
      onClose();
    }
  };

  const handleCancel = () => {
    onCancel();
    onClose();
  };

  if (!booking) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Manage Your Booking</DialogTitle>
        </DialogHeader>

        {mode === 'view' && (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <p><strong>Consultant:</strong> {booking.consultant.name}</p>
              <p><strong>Date:</strong> {booking.date.toLocaleDateString()}</p>
              <p><strong>Time:</strong> {booking.time}</p>
              <p><strong>Duration:</strong> {booking.duration} hour(s)</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setMode('reschedule')} variant="outline" className="flex-1">Reschedule</Button>
              <Button onClick={() => setMode('cancel')} variant="destructive" className="flex-1">Cancel</Button>
            </div>
          </div>
        )}

        {mode === 'reschedule' && (
          <div className="space-y-4">
            <Label className="flex items-center gap-2"><CalendarIcon className="w-4 h-4" />New Date</Label>
            <Calendar mode="single" selected={newDate} onSelect={setNewDate} disabled={(date) => date < new Date()} />
            <Label className="flex items-center gap-2"><Clock className="w-4 h-4" />New Time</Label>
            <Select value={newTime} onValueChange={setNewTime}>
              <SelectTrigger><SelectValue placeholder="Choose time" /></SelectTrigger>
              <SelectContent>{timeSlots.map(slot => <SelectItem key={slot} value={slot}>{slot}</SelectItem>)}</SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setMode('view')} className="flex-1">Back</Button>
              <Button onClick={handleReschedule} disabled={!newDate || !newTime} className="flex-1">Confirm</Button>
            </div>
          </div>
        )}

        {mode === 'cancel' && (
          <div className="space-y-4">
            <Alert><AlertCircle className="h-4 w-4" /><AlertDescription>Cancellation Policy: Full refund if cancelled 24+ hours before. 50% refund if cancelled within 24 hours.</AlertDescription></Alert>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setMode('view')} className="flex-1">Back</Button>
              <Button variant="destructive" onClick={handleCancel} className="flex-1">Confirm Cancel</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
