import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";

interface ElementBalanceProps {
  elements: { [key: string]: number };
  dayMasterElement: string;
}

export default function ElementBalance({ elements, dayMasterElement }: ElementBalanceProps) {
  const total = Object.values(elements).reduce((a, b) => a + b, 0);
  const maxElement = Object.entries(elements).reduce((a, b) => a[1] > b[1] ? a : b)[0];
  const minElement = Object.entries(elements).reduce((a, b) => a[1] < b[1] ? a : b)[0];
  
  const elementColors: { [key: string]: string } = {
    Wood: "bg-green-500",
    Fire: "bg-red-500",
    Earth: "bg-yellow-500",
    Metal: "bg-gray-500",
    Water: "bg-blue-500"
  };

  const elementProduces: { [key: string]: string } = {
    Wood: "Fire", Fire: "Earth", Earth: "Metal", Metal: "Water", Water: "Wood"
  };

  const elementControls: { [key: string]: string } = {
    Wood: "Earth", Earth: "Water", Water: "Fire", Fire: "Metal", Metal: "Wood"
  };

  const beneficialElements = [
    elementProduces[dayMasterElement],
    Object.keys(elementProduces).find(k => elementProduces[k] === dayMasterElement) || ""
  ];

  const harmfulElements = [
    elementControls[dayMasterElement],
    Object.keys(elementControls).find(k => elementControls[k] === dayMasterElement) || ""
  ];

  return (
    <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50">
      <h4 className="font-bold text-xl mb-4">Element Balance & Strength</h4>
      
      <div className="space-y-3 mb-6">
        {Object.entries(elements).map(([element, count]) => (
          <div key={element}>
            <div className="flex justify-between mb-1">
              <span className="font-semibold">{element}</span>
              <span>{count} ({Math.round((count / total) * 100)}%)</span>
            </div>
            <Progress value={(count / total) * 100} className={`h-3 ${elementColors[element]}`} />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
          <h5 className="font-bold text-green-800 mb-2">Beneficial Elements</h5>
          {beneficialElements.map(el => el && (
            <Badge key={el} className="bg-green-200 text-green-900 mr-2">{el}</Badge>
          ))}
        </div>
        <div className="p-4 bg-red-50 rounded-lg border border-red-200">
          <h5 className="font-bold text-red-800 mb-2">Challenging Elements</h5>
          {harmfulElements.map(el => el && (
            <Badge key={el} className="bg-red-200 text-red-900 mr-2">{el}</Badge>
          ))}
        </div>
      </div>
    </Card>
  );
}
