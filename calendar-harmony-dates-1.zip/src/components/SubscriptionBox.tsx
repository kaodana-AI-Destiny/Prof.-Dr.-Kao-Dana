import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { QrCode } from "lucide-react";
import PaymentModal from "./PaymentModal";
import LoginModal from "./LoginModal";
export default function SubscriptionBox() {
  const [showPayment, setShowPayment] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<{
    name: string;
    price: string;
    duration: string;
  } | null>(null);
  const plans = [{
    name: "Daily",
    nameKh: "ប្រចាំថ្ងៃ",
    price: "$0.8",
    duration: "1 day",
    popular: false
  }, {
    name: "Weekly",
    nameKh: "ប្រចាំសប្តាហ៍",
    price: "$5",
    duration: "7 days",
    popular: true
  }, {
    name: "Monthly",
    nameKh: "ប្រចាំខែ",
    price: "$15",
    duration: "30 days",
    popular: false
  }, {
    name: "Yearly",
    nameKh: "ប្រចាំឆ្នាំ",
    price: "$86",
    duration: "365 days",
    popular: false
  }];
  const handleSelectPlan = (plan: typeof plans[0]) => {
    setSelectedPlan({
      name: plan.name,
      price: plan.price,
      duration: plan.duration
    });
    setShowPayment(true);
  };
  return <>
      <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">🔐 ជាវដើម្បីចូលមើលរាសីអ្នក Subscribe to Access Premium Features</h2>
            <p className="text-white/90 text-lg">
              ជ្រើសរើសគម្រោងដែលសមស្របបំផុតសម្រាប់អ្នក Choose the plan that works best for you
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            {plans.map(plan => <Card key={plan.name} className={`p-6 relative ${plan.popular ? 'border-4 border-yellow-400 shadow-2xl' : 'border-2'}`}>
                {plan.popular && <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-black">
                    ពេញនិយម Popular
                  </Badge>}
                <div className="text-center">
                  <h3 className="text-xl font-bold mb-1">{plan.nameKh}</h3>
                  <h4 className="text-lg font-semibold text-gray-600 mb-3">{plan.name}</h4>
                  <div className="text-4xl font-bold text-purple-600 mb-2">{plan.price}</div>
                  <p className="text-sm text-gray-500 mb-4">{plan.duration}</p>
                  <div className="space-y-2">
                    <Button onClick={() => handleSelectPlan(plan)} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                      ជ្រើសរើស Select
                    </Button>
                    <Button onClick={() => window.open('https://pay.ababank.com/oRF8/fka8tr6m', '_blank')} variant="outline" className="w-full border-purple-600 text-purple-600 hover:bg-purple-50">
                      <QrCode className="w-4 h-4 mr-2" />
                      បង់តាម QR Pay with QR
                    </Button>
                  </div>
                </div>

              </Card>)}
          </div>

          <div className="mt-6 text-center">
            <Button onClick={() => setShowLogin(true)} variant="outline" className="bg-white hover:bg-gray-100">
              មានគណនីរួចហើយ? ចូល Already have an account? Login
            </Button>
          </div>
        </div>
      </div>

      {selectedPlan && <PaymentModal isOpen={showPayment} onClose={() => setShowPayment(false)} plan={selectedPlan} onPaymentComplete={() => {
      setShowPayment(false);
      setShowLogin(true);
    }} />}

      <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
    </>;
}