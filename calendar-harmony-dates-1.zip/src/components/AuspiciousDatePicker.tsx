import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DateAnalysis, EventType, findAuspiciousDates } from '@/utils/auspiciousDateCalculator';
import { BaZiChart } from '@/utils/baziCalculator';
import { Calendar as CalendarIcon, Sparkles, TrendingUp, Home, Heart } from 'lucide-react';

interface Props {
  birthChart: BaZiChart;
}

const EVENT_TYPES: { value: EventType; label: string; icon: any; desc: string }[] = [
  { value: 'wedding', label: 'Wedding', icon: Heart, desc: 'Marriage ceremonies and unions' },
  { value: 'business', label: 'Business Launch', icon: TrendingUp, desc: 'Starting new ventures' },
  { value: 'moving', label: 'Moving/Relocation', icon: Home, desc: 'Changing residence' },
  { value: 'general', label: 'General Event', icon: Sparkles, desc: 'Other important occasions' }
];

const LEVEL_CONFIG = {
  excellent: { color: 'bg-green-500', border: 'border-green-500', text: 'text-green-700' },
  good: { color: 'bg-blue-500', border: 'border-blue-500', text: 'text-blue-700' },
  neutral: { color: 'bg-yellow-500', border: 'border-yellow-500', text: 'text-yellow-700' },
  poor: { color: 'bg-red-500', border: 'border-red-500', text: 'text-red-700' }
};

export default function AuspiciousDatePicker({ birthChart }: Props) {
  const [eventType, setEventType] = useState<EventType>('wedding');
  const [results, setResults] = useState<DateAnalysis[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [timeframe, setTimeframe] = useState<'3months' | '6months' | '1year'>('6months');

  const handleSearch = () => {
    setIsSearching(true);
    const startDate = new Date();
    const endDate = new Date(startDate);
    
    if (timeframe === '3months') endDate.setMonth(endDate.getMonth() + 3);
    else if (timeframe === '6months') endDate.setMonth(endDate.getMonth() + 6);
    else endDate.setFullYear(endDate.getFullYear() + 1);
    
    setTimeout(() => {
      const auspiciousDates = findAuspiciousDates(birthChart, startDate, endDate, eventType, 15);
      setResults(auspiciousDates);
      setIsSearching(false);
    }, 500);
  };

  const selectedEventType = EVENT_TYPES.find(t => t.value === eventType);

  return (
    <div className="space-y-6">
      <Card className="border-2 border-amber-200">
        <CardHeader className="bg-gradient-to-r from-amber-50 to-orange-50">
          <CardTitle className="flex items-center gap-2 text-2xl">
            <CalendarIcon className="w-7 h-7 text-amber-600" />
            Auspicious Date Finder
          </CardTitle>
          <CardDescription className="text-base">
            Find the most favorable dates for important life events based on your BaZi chart and element interactions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold">Event Type</label>
              <Select value={eventType} onValueChange={(v) => setEventType(v as EventType)}>
                <SelectTrigger className="h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EVENT_TYPES.map(type => {
                    const Icon = type.icon;
                    return (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2 py-1">
                          <Icon className="w-4 h-4" />
                          <div>
                            <div className="font-medium">{type.label}</div>
                            <div className="text-xs text-gray-500">{type.desc}</div>
                          </div>
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-semibold">Search Timeframe</label>
              <Select value={timeframe} onValueChange={(v) => setTimeframe(v as any)}>
                <SelectTrigger className="h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3months">Next 3 Months</SelectItem>
                  <SelectItem value="6months">Next 6 Months</SelectItem>
                  <SelectItem value="1year">Next Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleSearch} 
            disabled={isSearching} 
            className="w-full h-12 text-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
          >
            {isSearching ? 'Analyzing Dates...' : `Find Auspicious Dates for ${selectedEventType?.label}`}
          </Button>
        </CardContent>
      </Card>

      {results.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold">Top {results.length} Recommended Dates</h3>
            <div className="flex gap-2 text-xs">
              {Object.entries(LEVEL_CONFIG).map(([level, config]) => (
                <div key={level} className="flex items-center gap-1">
                  <div className={`w-3 h-3 rounded-full ${config.color}`} />
                  <span className="capitalize">{level}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-4">
            {results.map((result, idx) => {
              const config = LEVEL_CONFIG[result.level];
              return (
                <Card key={idx} className={`border-l-4 ${config.border} hover:shadow-lg transition-shadow`}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl">{result.dateString}</CardTitle>
                        <CardDescription className="text-base mt-1">
                          {result.baziChart.day.stem.chinese}{result.baziChart.day.branch.chinese} ({result.baziChart.day.stem.name} {result.baziChart.day.branch.name}) • 
                          {result.baziChart.day.stem.element} {result.baziChart.day.stem.polarity}
                        </CardDescription>
                      </div>
                      <div className={`px-4 py-2 rounded-full text-white text-sm font-bold ${config.color}`}>
                        {result.score}/100
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {result.favorableAspects.length > 0 && (
                      <div className="bg-green-50 p-3 rounded-lg">
                        <h4 className="font-semibold text-green-800 mb-2 flex items-center gap-1">
                          ✓ Favorable Aspects
                        </h4>
                        <ul className="space-y-1">
                          {result.favorableAspects.map((aspect, i) => (
                            <li key={i} className="text-sm text-green-700">• {aspect}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {result.challenges.length > 0 && (
                      <div className="bg-red-50 p-3 rounded-lg">
                        <h4 className="font-semibold text-red-800 mb-2 flex items-center gap-1">
                          ⚠ Challenges to Consider
                        </h4>
                        <ul className="space-y-1">
                          {result.challenges.map((challenge, i) => (
                            <li key={i} className="text-sm text-red-700">• {challenge}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    <div className="pt-3 border-t">
                      <p className="font-medium text-gray-800">{result.recommendations}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
