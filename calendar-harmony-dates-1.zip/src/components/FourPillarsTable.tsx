import { BaZiChart } from "@/utils/baziCalculator";
import { Card } from "./ui/card";

interface FourPillarsTableProps {
  chart: BaZiChart;
}

export default function FourPillarsTable({ chart }: FourPillarsTableProps) {
  const elementColors: { [key: string]: string } = {
    Wood: "bg-green-50",
    Fire: "bg-red-50",
    Earth: "bg-yellow-50",
    Metal: "bg-gray-50",
    Water: "bg-blue-50"
  };

  const pillars = [
    { name: "Hour", pillar: chart.hour },
    { name: "Day", pillar: chart.day },
    { name: "Month", pillar: chart.month },
    { name: "Year", pillar: chart.year }
  ];

  return (
    <Card className="p-6 overflow-x-auto">
      <h3 className="text-2xl font-bold mb-6 text-center">Four Pillars of Destiny (四柱命理)</h3>
      
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gradient-to-r from-purple-100 to-pink-100">
            <th className="border-2 border-gray-300 p-4 text-left font-bold">Pillar</th>
            <th className="border-2 border-gray-300 p-4 text-center font-bold">Hour (時)</th>
            <th className="border-2 border-gray-300 p-4 text-center font-bold">Day (日)</th>
            <th className="border-2 border-gray-300 p-4 text-center font-bold">Month (月)</th>
            <th className="border-2 border-gray-300 p-4 text-center font-bold">Year (年)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border-2 border-gray-300 p-4 font-bold bg-purple-50">Heavenly Stem<br/>(天干)</td>
            {pillars.map((col) => (
              <td key={`stem-${col.name}`} className={`border-2 border-gray-300 p-4 text-center ${elementColors[col.pillar.stem.element]}`}>
                <div className="font-bold text-xl mb-1">{col.pillar.stem.chinese}</div>
                <div className="text-sm font-semibold">{col.pillar.stem.name}</div>
                <div className="text-xs mt-1">{col.pillar.stem.khmer}</div>
                <div className="text-xs text-gray-600">{col.pillar.stem.element} {col.pillar.stem.polarity}</div>
              </td>
            ))}
          </tr>
          
          <tr>
            <td className="border-2 border-gray-300 p-4 font-bold bg-purple-50">Earthly Branch<br/>(地支)</td>
            {pillars.map((col) => (
              <td key={`branch-${col.name}`} className={`border-2 border-gray-300 p-4 text-center ${elementColors[col.pillar.branch.element]}`}>
                <div className="font-bold text-xl mb-1">{col.pillar.branch.chinese}</div>
                <div className="text-sm font-semibold">{col.pillar.branch.name}</div>
                <div className="text-xs mt-1">{col.pillar.branch.animal}</div>
                <div className="text-xs text-gray-600">{col.pillar.branch.element} {col.pillar.branch.polarity}</div>
              </td>
            ))}
          </tr>
          
          <tr>
            <td className="border-2 border-gray-300 p-4 font-bold bg-purple-50">Hidden Stems<br/>(藏干)</td>
            {pillars.map((col) => (
              <td key={`hidden-${col.name}`} className="border-2 border-gray-300 p-4 text-center bg-white">
                <div className="space-y-1">
                  {col.pillar.hiddenStems.map((stem, idx) => (
                    <div key={idx} className="text-xs">
                      <span className="font-bold">{stem.chinese}</span> {stem.name}
                    </div>
                  ))}
                </div>
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </Card>
  );
}
