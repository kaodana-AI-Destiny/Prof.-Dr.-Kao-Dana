import { StarAnalysis } from '../utils/flyingStarsAnalyzer';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

interface Props {
  analysis: StarAnalysis;
}

const ratingColors = {
  excellent: "bg-green-500",
  good: "bg-blue-500",
  neutral: "bg-gray-500",
  poor: "bg-orange-500",
  dangerous: "bg-red-500"
};

const ratingLabels = {
  excellent: "Excellent",
  good: "Good",
  neutral: "Neutral",
  poor: "Poor",
  dangerous: "Dangerous"
};

export default function FlyingStarsSectorAnalysis({ analysis }: Props) {
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{analysis.sector}</CardTitle>
          <Badge className={ratingColors[analysis.rating]}>
            {ratingLabels[analysis.rating]}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">{analysis.details}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <h4 className="font-semibold text-sm mb-1">Interpretation:</h4>
          <p className="text-sm">{analysis.interpretation}</p>
        </div>
        <div>
          <h4 className="font-semibold text-sm mb-1">Remedy:</h4>
          <p className="text-sm text-blue-600">{analysis.remedy}</p>
        </div>
      </CardContent>
    </Card>
  );
}
