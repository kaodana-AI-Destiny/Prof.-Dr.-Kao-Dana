import { useUser } from '@/contexts/UserContext';
import { User, LogOut, Crown } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import SubscriptionCountdown from './SubscriptionCountdown';

export default function UserProfile() {
  const { user, subscription, isPremium, logout } = useUser();

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card className="p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-purple-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">{user.email}</h2>
              {isPremium && (
                <div className="flex items-center gap-2 text-amber-600 mt-1">
                  <Crown className="w-4 h-4" />
                  <span className="font-semibold">Premium Member</span>
                </div>
              )}
            </div>
          </div>
          <Button variant="outline" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </Card>

      {subscription && <SubscriptionCountdown subscription={subscription} />}
    </div>
  );
}
