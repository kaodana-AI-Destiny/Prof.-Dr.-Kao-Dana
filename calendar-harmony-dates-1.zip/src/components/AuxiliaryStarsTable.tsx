import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { AuxiliaryStar } from '@/utils/auxiliaryStarsCalculator';

interface AuxiliaryStarsTableProps {
  stars: AuxiliaryStar[];
}

export default function AuxiliaryStarsTable({ stars }: AuxiliaryStarsTableProps) {
  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'auspicious':
        return <Badge className="bg-green-500">មង្គល Auspicious</Badge>;
      case 'inauspicious':
        return <Badge className="bg-red-500">អមង្គល Inauspicious</Badge>;
      default:
        return <Badge className="bg-blue-500">អព្យាក្រឹត Neutral</Badge>;
    }
  };


  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">ផ្កាយជំនួយ Auxiliary Stars (神煞)</CardTitle>


      </CardHeader>
      <CardContent>
        {stars.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ឈ្មោះផ្កាយ Star Name</TableHead>
                <TableHead>ឈ្មោះចិន Chinese Name</TableHead>
                <TableHead>សសរ Pillar</TableHead>
                <TableHead>ប្រភេទ Type</TableHead>
                <TableHead>ការពិពណ៌នា Description</TableHead>
              </TableRow>

            </TableHeader>
            <TableBody>
              {stars.map((star, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{star.name}</TableCell>
                  <TableCell className="text-lg">{star.chineseName}</TableCell>
                  <TableCell>{star.pillar}</TableCell>
                  <TableCell>{getTypeBadge(star.type)}</TableCell>
                  <TableCell>{star.description}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-center text-gray-500 py-4">រកមិនឃើញផ្កាយជំនួយក្នុងតារាងនេះទេ។ No auxiliary stars found in this chart.</p>


        )}
      </CardContent>
    </Card>
  );
}
