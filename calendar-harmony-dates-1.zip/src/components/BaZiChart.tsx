import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { BaZiChart as BaZiChartType } from "@/utils/baziCalculator";
import { elementPersonality, lifePredictions } from "@/data/baziAnalysis";
import { tenGodsInterpretation, tenGods } from "@/data/tenGodsData";
import ElementBalance from "./ElementBalance";
import LifeRecommendations from "./LifeRecommendations";
import ElementCycleGuide from "./ElementCycleGuide";



interface BaZiChartProps {
  chart: BaZiChartType;
}

export default function BaZiChart({ chart }: BaZiChartProps) {
  const dominantElement = Object.entries(chart.elements).reduce((a, b) => a[1] > b[1] ? a : b)[0];
  const isBalanced = Math.max(...Object.values(chart.elements)) - Math.min(...Object.values(chart.elements)) <= 2;

  // Helper function to get Khmer translation for Ten God names
  const getTenGodKhmer = (englishName: string): string => {
    const godMap: { [key: string]: string } = {
      "Friend": tenGods.friend.khmer,
      "Rob Wealth": tenGods.robWealth.khmer,
      "Eating God": tenGods.eatingGod.khmer,
      "Hurting Officer": tenGods.hurtingOfficer.khmer,
      "Indirect Wealth": tenGods.indirectWealth.khmer,
      "Direct Wealth": tenGods.directWealth.khmer,
      "Seven Killings": tenGods.sevenKillings.khmer,
      "Direct Officer": tenGods.directOfficer.khmer,
      "Indirect Resource": tenGods.indirectResource.khmer,
      "Direct Resource": tenGods.directResource.khmer
    };
    return godMap[englishName] || englishName;
  };

  const elementColors: { [key: string]: string } = {
    Wood: "bg-green-100 text-green-800 border-green-300",
    Fire: "bg-red-100 text-red-800 border-red-300",
    Earth: "bg-yellow-100 text-yellow-800 border-yellow-300",
    Metal: "bg-gray-100 text-gray-800 border-gray-300",
    Water: "bg-blue-100 text-blue-800 border-blue-300"
  };


  return (
    <div className="space-y-8">
      <Card className="p-8 bg-gradient-to-br from-purple-50 to-pink-50">
        <h3 className="text-3xl font-bold mb-6 text-center">បួនសសរនៃជោគវាសនា Four Pillars of Destiny (四柱命理)</h3>



        {/* Table Header */}
        <div className="grid grid-cols-5 gap-4 mb-4 bg-purple-100 p-3 rounded-lg">
          <div className="font-bold text-center">សសរ Pillar</div>
          <div className="font-bold text-center">ម៉ោង Hour (時)</div>
          <div className="font-bold text-center">ថ្ងៃ Day (日)</div>
          <div className="font-bold text-center">ខែ Month (月)</div>
          <div className="font-bold text-center">ឆ្នាំ Year (年)</div>
        </div>

        {/* Heavenly Stem Row */}
        <div className="grid grid-cols-5 gap-4 mb-4">
          <div className="font-bold text-center flex items-center justify-center">
            ដើមស្ថានសួគ៌ Heavenly Stem (天干)
          </div>
          {[chart.hour, chart.day, chart.month, chart.year].map((pillar, idx) => (
            <div key={idx} className={`p-4 rounded-lg border-2 ${elementColors[pillar.stem.element]}`}>
              <div className="text-2xl font-bold text-center">{pillar.stem.chinese}</div>
              <div className="text-center font-semibold">{pillar.stem.khmer} {pillar.stem.name}</div>
              <div className="text-center text-sm mt-1">{pillar.stem.khmerElement} {pillar.stem.element}</div>
              <div className="text-center text-xs">{pillar.stem.khmerPolarity} {pillar.stem.polarity}</div>
            </div>
          ))}
        </div>


        {/* Earthly Branch Row */}
        <div className="grid grid-cols-5 gap-4 mb-4">
          <div className="font-bold text-center flex items-center justify-center">
            ដើមផែនដី Earthly Branch (地支)
          </div>
          {[chart.hour, chart.day, chart.month, chart.year].map((pillar, idx) => (
            <div key={idx} className={`p-4 rounded-lg border-2 ${elementColors[pillar.branch.element]}`}>
              <div className="text-2xl font-bold text-center">{pillar.branch.chinese}</div>
              <div className="text-center font-semibold">{pillar.branch.khmerAnimal} {pillar.branch.animal}</div>
              <div className="text-center text-sm mt-1">{pillar.branch.khmerElement} {pillar.branch.element}</div>
              <div className="text-center text-xs">{pillar.branch.khmerPolarity} {pillar.branch.polarity}</div>
            </div>
          ))}
        </div>

        {/* Hidden Stems Row */}
        <div className="grid grid-cols-5 gap-4 mb-8">
          <div className="font-bold text-center flex items-center justify-center">
            ដើមលាក់ Hidden Stems (藏干)
          </div>
          {[chart.hour, chart.day, chart.month, chart.year].map((pillar, idx) => (
            <div key={idx} className="p-3 bg-gray-50 rounded-lg border border-gray-300">
              {pillar.hiddenStems.map((stem, stemIdx) => (
                <div key={stemIdx} className="text-xs text-center mb-1">
                  {stem.chinese} {stem.khmer} {stem.name}
                </div>
              ))}

            </div>
          ))}
        </div>
        {/* Ten Gods Row (optional - only shown if present) */}
        <div className="grid grid-cols-5 gap-4 mb-8">
          <div className="font-bold text-center flex items-center justify-center">
            សមត្ថភាពទាំង១០ Ten God
          </div>
          {[chart.hour, chart.day, chart.month, chart.year].map((pillar, idx) => (
            <div key={idx} className="text-center">
              {pillar.tenGod ? (
                <div className="p-3 bg-purple-100 rounded-lg border border-purple-300">
                  <div className="text-sm font-bold text-purple-800">{pillar.tenGod.chinese}</div>
                  <div className="text-xs text-purple-700">{pillar.tenGod.english}</div>
                </div>
              ) : (
                <div className="p-3 text-gray-400 text-xs">-</div>
              )}
            </div>
          ))}
        </div>




        <div className="bg-white p-6 rounded-lg mb-6">
          <h4 className="font-bold text-xl mb-4">ថ្ងៃតួខ្លួន Day Master (日主)</h4>

          <div className="text-center p-4 bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg">
            <div className="text-3xl font-bold mb-2">{chart.dayMaster.chinese} {chart.dayMaster.khmer} {chart.dayMaster.name}</div>
            <div className="text-lg">{chart.dayMaster.khmerElement} {chart.dayMaster.element} {chart.dayMaster.khmerPolarity} {chart.dayMaster.polarity}</div>

          </div>
        </div>


        <div className="bg-white p-6 rounded-lg mb-6">
          <h4 className="font-bold text-xl mb-4">ការចែកចាយសមត្ថភាពទាំង១០ Ten Gods Distribution (十神)</h4>


          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(chart.tenGodsCount).map(([god, count]) => {
              const khmerName = getTenGodKhmer(god);
              return (
                <div key={god} className="text-center p-3 bg-purple-50 rounded-lg border border-purple-200">
                  <div className="font-bold text-purple-900 text-sm">{khmerName}</div>
                  <div className="text-xs text-purple-700 mb-1">{god}</div>
                  <div className="text-2xl font-bold text-purple-600">{count}</div>
                </div>
              );
            })}
          </div>
        </div>


        <div className="bg-white p-6 rounded-lg">
          <h4 className="font-bold text-xl mb-4">ការចែកចាយធាតុ Element Distribution</h4>
          <div className="grid grid-cols-5 gap-3">
            {Object.entries(chart.elements).map(([element, count]) => (
              <div key={element} className="text-center">
                <Badge className={elementColors[element]}>{element}</Badge>
                <div className="text-2xl font-bold mt-2">{count}</div>
              </div>
            ))}
          </div>
        </div>

      </Card>

      <Card className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50">
        <h3 className="text-2xl font-bold mb-4">ការវិភាគបុគ្គលិកលក្ខណៈ Personality Analysis</h3>
        <p className="text-lg mb-4">{elementPersonality[dominantElement as keyof typeof elementPersonality].strong}</p>
        <h4 className="font-bold text-lg mb-2">ផ្លូវអាជីព Career Paths</h4>
        <p className="mb-4">{elementPersonality[dominantElement as keyof typeof elementPersonality].career}</p>
        <h4 className="font-bold text-lg mb-2">ការទស្សន៍ទាយជីវិត Life Prediction</h4>
        <p>{isBalanced ? lifePredictions.balanced : lifePredictions[`${dominantElement.toLowerCase()}Dominant` as keyof typeof lifePredictions]}</p>
      </Card>

      <Card className="p-8 bg-gradient-to-br from-amber-50 to-orange-50">
        <h3 className="text-2xl font-bold mb-6">ការវិភាគសមត្ថភាពទាំង១០ Ten Gods Analysis (十神分析)</h3>


        <div className="space-y-4">
          {Object.entries(chart.tenGodsCount).map(([god, count]) => {
            const godKey = god.toLowerCase().replace(/\s+/g, '') as keyof typeof tenGodsInterpretation;
            const interpretation = tenGodsInterpretation[godKey];
            const khmerName = getTenGodKhmer(god);
            
            if (!interpretation) return null;
            
            return (
              <div key={god} className="p-4 bg-white rounded-lg border-l-4 border-purple-500">
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <h4 className="font-bold text-lg text-purple-900">{khmerName}</h4>
                    <p className="text-sm text-purple-700">{god}</p>
                  </div>
                  <Badge className="bg-purple-100 text-purple-800">ចំនួន Count: {count}</Badge>
                </div>
                <div className="text-gray-700">
                  <p className="mb-1">{interpretation.khmer}</p>
                  <p className="text-sm text-gray-600">{interpretation.english}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Card>


      <ElementBalance elements={chart.elements} dayMasterElement={chart.dayMaster.element} />

      <LifeRecommendations 
        dayMasterElement={chart.dayMaster.element}
        dominantElement={dominantElement}
        elements={chart.elements}
      />

      <ElementCycleGuide />


    </div>
  );
}
