interface ColorPaletteProps {
  colors: {
    primary: string[];
    supporting: string[];
    avoid: string[];
  };
}

const colorClasses: Record<string, string> = {
  Green: 'bg-green-500', Teal: 'bg-teal-500', Brown: 'bg-amber-700',
  Blue: 'bg-blue-500', Black: 'bg-gray-900', Red: 'bg-red-500',
  Orange: 'bg-orange-500', Purple: 'bg-purple-500', Pink: 'bg-pink-500',
  Yellow: 'bg-yellow-400', Beige: 'bg-amber-200', Tan: 'bg-amber-300',
  White: 'bg-white border border-gray-300', Gold: 'bg-yellow-500',
  Silver: 'bg-gray-400', Gray: 'bg-gray-500', Navy: 'bg-blue-900',
  Turquoise: 'bg-cyan-500'
};

export default function ColorPalette({ colors }: ColorPaletteProps) {
  return (
    <div className="space-y-4">
      <div>
        <h4 className="text-sm font-semibold mb-2 text-gray-700">Primary Colors (Most Favorable)</h4>
        <div className="flex gap-2 flex-wrap">
          {colors.primary.map(color => (
            <div key={color} className="text-center">
              <div className={`w-12 h-12 rounded-lg ${colorClasses[color]} shadow-md`}></div>
              <span className="text-xs mt-1 block">{color}</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h4 className="text-sm font-semibold mb-2 text-gray-700">Supporting Colors</h4>
        <div className="flex gap-2 flex-wrap">
          {colors.supporting.map(color => (
            <div key={color} className="text-center">
              <div className={`w-12 h-12 rounded-lg ${colorClasses[color]} shadow-md`}></div>
              <span className="text-xs mt-1 block">{color}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
