import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface FiltersProps {
  selectedZodiac: string;
  selectedElement: string;
  onZodiacChange: (value: string) => void;
  onElementChange: (value: string) => void;
}

const zodiacs = [
  { value: "All", khmer: "ទាំងអស់", english: "All" },
  { value: "Rat", khmer: "ជូត", english: "Rat" },
  { value: "Ox", khmer: "ឆ្លូវ", english: "Ox" },
  { value: "Tiger", khmer: "ខាល", english: "Tiger" },
  { value: "Rabbit", khmer: "ថោះ", english: "Rabbit" },
  { value: "Dragon", khmer: "រោង", english: "Dragon" },
  { value: "Snake", khmer: "ម្សាញ់", english: "Snake" },
  { value: "Horse", khmer: "មមី", english: "Horse" },
  { value: "Goat", khmer: "មមែ", english: "Goat" },
  { value: "Monkey", khmer: "វក", english: "Monkey" },
  { value: "Rooster", khmer: "រកា", english: "Rooster" },
  { value: "Dog", khmer: "ជូត", english: "Dog" },
  { value: "Pig", khmer: "កុរ", english: "Pig" }
];

const elements = [
  { value: "All", khmer: "ទាំងអស់", english: "All" },
  { value: "Metal", khmer: "លោហៈ", english: "Metal" },
  { value: "Water", khmer: "ទឹក", english: "Water" },
  { value: "Wood", khmer: "ឈើ", english: "Wood" },
  { value: "Fire", khmer: "ភ្លើង", english: "Fire" },
  { value: "Earth", khmer: "ដី", english: "Earth" }
];

export default function Filters({ selectedZodiac, selectedElement, onZodiacChange, onElementChange }: FiltersProps) {
  return (
    <div className="flex flex-wrap gap-4 mb-8">
      <div className="flex-1 min-w-[200px]">
        <label className="block text-sm font-medium mb-2">ស្វែងរកសត្វក្នុងឆ្នាំកើត Filter by Zodiac</label>
        <Select value={selectedZodiac} onValueChange={onZodiacChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select zodiac" />
          </SelectTrigger>
          <SelectContent>
            {zodiacs.map(z => (
              <SelectItem key={z.value} value={z.value}>{z.khmer} {z.english}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex-1 min-w-[200px]">
        <label className="block text-sm font-medium mb-2">ស្វែងរកធាតុឆ្នាំកើត Filter by Element</label>
        <Select value={selectedElement} onValueChange={onElementChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select element" />
          </SelectTrigger>
          <SelectContent>
            {elements.map(e => (
              <SelectItem key={e.value} value={e.value}>{e.khmer} {e.english}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
