import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, Star, BookOpen, Calendar, Languages } from 'lucide-react';
import { EBook } from '@/data/ebooksData';

interface EBookDetailModalProps {
  ebook: EBook | null;
  isOpen: boolean;
  onClose: () => void;
  onDownload: (ebook: EBook) => void;
}

export default function EBookDetailModal({ ebook, isOpen, onClose, onDownload }: EBookDetailModalProps) {
  if (!ebook) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{ebook.title}</DialogTitle>
          <DialogDescription className="text-base">{ebook.titleKhmer}</DialogDescription>
        </DialogHeader>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <img
              src={ebook.coverImage}
              alt={ebook.title}
              className="w-full rounded-lg shadow-lg"
            />
          </div>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Author</h4>
              <p className="text-gray-700">{ebook.author}</p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-2">Description</h4>
              <p className="text-gray-700 mb-2">{ebook.description}</p>
              <p className="text-gray-600 text-sm">{ebook.descriptionKhmer}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-primary" />
                <span className="text-sm">{ebook.pages} pages</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-sm">{ebook.rating} rating</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <span className="text-sm">{ebook.publishYear}</span>
              </div>
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-primary" />
                <span className="text-sm">{ebook.downloads} downloads</span>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Languages className="w-4 h-4" />
                Languages
              </h4>
              <p className="text-sm text-gray-700">{ebook.language}</p>
            </div>
            
            <div className="pt-4 border-t">
              <div className="flex items-center justify-between mb-4">
                <div className="text-3xl font-bold text-primary">${ebook.price}</div>
                <Badge variant="secondary">PDF Format</Badge>
              </div>
              <Button className="w-full" size="lg" onClick={() => onDownload(ebook)}>
                <Download className="w-5 h-5 mr-2" />
                Purchase & Download
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
