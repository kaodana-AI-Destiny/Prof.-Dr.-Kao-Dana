import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LoginModal({ isOpen, onClose }: LoginModalProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login process
    setTimeout(() => {
      setIsLoading(false);
      
      if (email && password) {
        // Store login status
        localStorage.setItem("baziLoggedIn", "true");
        localStorage.setItem("baziUserEmail", email);
        
        toast({
          title: "✓ ចូលប្រើប្រាស់បានជោគជ័យ Login Successful",
          description: "អ្នកអាចចូលប្រើលក្ខណៈពិសេសទាំងអស់បានហើយ You now have access to all premium features",
        });
        
        onClose();
      } else {
        toast({
          title: "❌ កំហុស Error",
          description: "សូមបំពេញអ៊ីមែល និងពាក្យសម្ងាត់ Please fill in email and password",
          variant: "destructive",
        });
      }
    }, 1000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl text-center">
            🔐 ចូលប្រើប្រាស់ Login to Your Account
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <Label htmlFor="email">អ៊ីមែល Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="password">ពាក្យសម្ងាត់ Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
            <p className="text-sm text-blue-800">
              💡 បន្ទាប់ពីទូទាត់ អ្នកនឹងទទួលបានអ៊ីមែល និងពាក្យសម្ងាត់
              <br />
              After payment, you will receive your login credentials via email
            </p>
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              បោះបង់ Cancel
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 bg-purple-600 hover:bg-purple-700">
              {isLoading ? "កំពុងចូល..." : "ចូល Login"}
            </Button>
          </div>
        </form>

        <div className="text-center text-sm text-gray-600">
          <p>មិនទាន់មានគណនី? Don't have an account?</p>
          <Button variant="link" className="text-purple-600">
            ជាវឥឡូវនេះ Subscribe Now
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
