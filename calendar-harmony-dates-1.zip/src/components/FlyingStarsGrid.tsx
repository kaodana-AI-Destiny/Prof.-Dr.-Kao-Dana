import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { FlyingStarCell } from "../utils/flyingStarsCalculator";
import { starMeanings } from "../data/flyingStarsData";

interface FlyingStarsGridProps {
  stars: FlyingStarCell[][];
  annualStars: number[][];
}

export function FlyingStarsGrid({ stars, annualStars }: FlyingStarsGridProps) {
  return (
    <div className="grid grid-cols-3 gap-2 max-w-2xl mx-auto">
      {stars.map((row, rowIndex) =>
        row.map((cell, colIndex) => {
          const annual = annualStars[rowIndex][colIndex];
          const periodStar = starMeanings[cell.period];
          
          return (
            <Card
              key={`${rowIndex}-${colIndex}`}
              className={`p-4 ${periodStar.color} border-2 min-h-[140px]`}

            >
              <div className="text-center">
                <div className="text-xs font-semibold text-gray-600 mb-2">
                  {cell.sector}
                </div>
                <div className="grid grid-cols-3 gap-1 mb-2">
                  <div className="text-center">
                    <div className="text-xs text-gray-500">ភ្នំ M</div>
                    <div className="text-lg font-bold">{cell.mountain}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xs text-gray-500">រយៈ P</div>
                    <div className="text-xl font-bold text-purple-600">{cell.period}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xs text-gray-500">ទឹក W</div>
                    <div className="text-lg font-bold">{cell.water}</div>
                  </div>
                </div>
                <Badge variant="outline" className="text-xs">
                  ប្រចាំឆ្នាំ Annual: {annual}
                </Badge>

              </div>
            </Card>
          );
        })
      )}
    </div>
  );
}
