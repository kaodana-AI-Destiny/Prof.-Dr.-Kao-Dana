import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { auxiliaryStarsReference } from '@/data/auxiliaryStarsReference';
interface DayMasterStarsReferenceProps {
  currentDayMaster?: string;
}
export function DayMasterStarsReference({
  currentDayMaster
}: DayMasterStarsReferenceProps) {
  const getElementColor = (element: string) => {
    switch (element) {
      case 'Wood':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'Fire':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'Earth':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Metal':
        return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'Water':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  return <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">ផ្កាយជំនួយ Auxiliary Stars Reference by ថ្ងៃតួខ្លួន Day Master</CardTitle>


        <CardDescription>
          Comprehensive guide to Noble Person and Academic Stars for all 10 Heavenly Stems
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">ថ្ងៃតួខ្លួន Day Master</TableHead>

                <TableHead className="w-[100px]">Element</TableHead>
                <TableHead className="w-[100px]">Polarity</TableHead>
                <TableHead className="w-[200px]">Noble Person (天乙貴人)</TableHead>
                <TableHead className="w-[150px]">Academic Star (文昌)</TableHead>
                <TableHead>Description</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {auxiliaryStarsReference.map(dayMaster => {
              const isCurrentDayMaster = currentDayMaster && dayMaster.chineseName.includes(currentDayMaster);
              return <TableRow key={dayMaster.dayMaster} className={isCurrentDayMaster ? 'bg-purple-50 border-l-4 border-l-purple-500' : ''}>
                    <TableCell className="font-semibold">
                      <div className="flex flex-col gap-1">
                        <span>{dayMaster.dayMaster}</span>
                        <span className="text-lg text-purple-700">{dayMaster.chineseName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getElementColor(dayMaster.element)}>
                        {dayMaster.element}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {dayMaster.polarity}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {dayMaster.noblePerson.map((branch, idx) => <Badge key={idx} variant="secondary" className="bg-amber-100 text-amber-800">
                            {branch}
                          </Badge>)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        {dayMaster.academicStar}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {dayMaster.description}
                    </TableCell>
                  </TableRow>;
            })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>;
}