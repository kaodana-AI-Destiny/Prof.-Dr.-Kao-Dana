import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { TimeZodiacDetail } from "@/data/timeZodiacDetails";

interface TimeZodiacDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  detail: TimeZodiacDetail | null;
}

export function TimeZodiacDetailModal({ isOpen, onClose, detail }: TimeZodiacDetailModalProps) {
  if (!detail) return null;

  const elementColors: Record<string, string> = {
    Wood: "bg-green-100 border-green-300",
    Fire: "bg-red-100 border-red-300",
    Earth: "bg-yellow-100 border-yellow-300",
    Metal: "bg-gray-100 border-gray-300",
    Water: "bg-blue-100 border-blue-300"
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
            <span className="text-4xl">{detail.branch.split(" ")[0]}</span>
            <div>
              <div>{detail.animal} Hour</div>
              <div className="text-sm font-normal text-muted-foreground">{detail.timeRange}</div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <div className={`p-4 rounded-lg border-2 ${elementColors[detail.element]}`}>
            <div className="flex gap-4 items-center">
              <Badge variant="secondary" className="text-base">{detail.element}</Badge>
              <Badge variant="outline" className="text-base">{detail.polarity}</Badge>
            </div>
            <p className="mt-2 text-sm font-medium">{detail.energyType}</p>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-3">🍀 Lucky Activities</h3>
            <ul className="space-y-2">
              {detail.luckyActivities.map((activity, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-green-600 mt-1">✓</span>
                  <span>{activity}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-3">🔗 Compatible Elements</h3>
            <div className="flex gap-2 flex-wrap">
              {detail.compatibleElements.map((element, idx) => (
                <Badge key={idx} className={elementColors[element]}>{element}</Badge>
              ))}
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-semibold text-lg mb-3">🏥 Traditional Chinese Medicine</h3>
            <div className="space-y-3 bg-slate-50 p-4 rounded-lg">
              <div>
                <span className="font-medium">Organ:</span> {detail.tcmAssociations.organ}
              </div>
              <div>
                <span className="font-medium">Meridian:</span> {detail.tcmAssociations.meridian}
              </div>
              <div>
                <span className="font-medium">Health Focus:</span> {detail.tcmAssociations.health}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
