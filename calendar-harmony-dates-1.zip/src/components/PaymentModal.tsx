import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { CheckCircle2, Copy } from "lucide-react";
import { useState } from "react";
import { ReceiptUploadModal } from "./ReceiptUploadModal";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: {
    name: string;
    price: string;
    duration: string;
  };
  onPaymentComplete: () => void;
}

export default function PaymentModal({ isOpen, onClose, plan, onPaymentComplete }: PaymentModalProps) {
  const [copied, setCopied] = useState(false);
  const [showReceiptUpload, setShowReceiptUpload] = useState(false);
  const abaAccountNumber = "256356455";
  const abaAccountName = "KAO DANA";

  const handleCopy = () => {
    navigator.clipboard.writeText(abaAccountNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleIvePaid = () => {
    setShowReceiptUpload(true);
  };


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl text-center">
            💳 ទូទាត់តាម ABA Bank Payment via ABA Bank
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-purple-50 p-4 rounded-lg">
            <div className="text-center mb-2">
              <Badge className="bg-purple-600">{plan.name} Plan</Badge>
            </div>
            <div className="text-3xl font-bold text-center text-purple-600">{plan.price}</div>
            <div className="text-sm text-center text-gray-600">{plan.duration}</div>
          </div>

          <div className="text-center">
            <img 
              src="https://pay.ababank.com/oRF8/fka8tr6m" 
              alt="ABA QR Code" 
              className="w-64 h-64 mx-auto border-4 border-red-500 rounded-lg"
            />

            <p className="text-sm text-gray-600 mt-2">ស្កេន QR កូដនេះដើម្បីទូទាត់ Scan this QR code to pay</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-semibold">លេខគណនី Account Number:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono">{abaAccountNumber}</span>
                <Button size="sm" variant="ghost" onClick={handleCopy}>
                  {copied ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="flex justify-between">
              <span className="text-sm font-semibold">ឈ្មោះគណនី Account Name:</span>
              <span>{abaAccountName}</span>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg">
            <p className="text-sm text-yellow-800">
              ⚠️ បន្ទាប់ពីទូទាត់ សូមចុច "ខ្ញុំបានទូទាត់រួចហើយ" ដើម្បីចូលប្រើ
              <br />
              After payment, click "I've Paid" to login and access features
            </p>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1">
              បោះបង់ Cancel
            </Button>
            <Button onClick={handleIvePaid} className="flex-1 bg-green-600 hover:bg-green-700">
              ✓ ខ្ញុំបានទូទាត់រួចហើយ I've Paid
            </Button>
          </div>
        </div>
      </DialogContent>
      
      <ReceiptUploadModal
        isOpen={showReceiptUpload}
        onClose={() => {
          setShowReceiptUpload(false);
          onClose();
        }}
        planName={plan.name}
        planPrice={plan.price}
      />
    </Dialog>
  );
}
