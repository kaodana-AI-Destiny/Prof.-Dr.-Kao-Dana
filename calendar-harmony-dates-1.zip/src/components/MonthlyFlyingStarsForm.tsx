import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
interface MonthlyFlyingStarsFormProps {
  onCalculate: (year: number, month: number) => void;
}
export default function MonthlyFlyingStarsForm({
  onCalculate
}: MonthlyFlyingStarsFormProps) {
  const currentDate = new Date();
  const [year, setYear] = useState(currentDate.getFullYear());
  const [month, setMonth] = useState(currentDate.getMonth() + 1);
  const years = Array.from({
    length: 20
  }, (_, i) => 2024 + i);
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCalculate(year, month);
  };
  const handleUseNow = () => {
    const now = new Date();
    setYear(now.getFullYear());
    setMonth(now.getMonth() + 1);
    onCalculate(now.getFullYear(), now.getMonth() + 1);
  };
  return <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Year</label>
            <Select value={year.toString()} onValueChange={v => setYear(parseInt(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Month</label>
            <Select value={month.toString()} onValueChange={v => setMonth(parseInt(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((m, i) => <SelectItem key={i + 1} value={(i + 1).toString()}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex gap-2">
          <Button type="submit" className="flex-1 text-base">រកទីតាំងតារាសាស្ត្រ-យុគ9 Calculate Flying Star Period 9</Button>
          <Button type="button" variant="outline" onClick={handleUseNow}>Use Now</Button>
        </div>
      </form>
    </Card>;
}