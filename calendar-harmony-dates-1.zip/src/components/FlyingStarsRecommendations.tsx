import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { FlyingStarCell, getRecommendation } from "../utils/flyingStarsCalculator";
import { starMeanings } from "../data/flyingStarsData";

interface FlyingStarsRecommendationsProps {
  stars: FlyingStarCell[][];
}

export function FlyingStarsRecommendations({ stars }: FlyingStarsRecommendationsProps) {
  const allCells = stars.flat();

  return (
    <div className="mt-8">
      <h3 className="text-2xl font-bold text-center mb-6">អនុសាសន៍តាមតំបន់ Sector Recommendations</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {allCells.map((cell, index) => {
          const recommendation = getRecommendation(cell.mountain, cell.water, cell.period);
          const periodStar = starMeanings[cell.period];
          
          return (
            <Card key={index} className="border-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center justify-between">
                  <span>{cell.sector}</span>
                  <Badge variant="outline">{periodStar.element}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">ផ្កាយរយៈពេល Period Star:</span>
                    <span className="font-semibold">{cell.period} - {periodStar.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">ធម្មជាតិ Nature:</span>
                    <span className={periodStar.nature === "Auspicious" || periodStar.nature === "Wealth" || periodStar.nature === "Celebration" ? "text-green-600 font-semibold" : "text-gray-700"}>{periodStar.nature}</span>

                  </div>
                  <div className="mt-3 p-2 bg-gray-50 rounded text-xs">
                    {recommendation}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
