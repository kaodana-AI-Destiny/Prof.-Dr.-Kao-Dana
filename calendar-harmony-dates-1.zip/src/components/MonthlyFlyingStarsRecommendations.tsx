import { Card } from './ui/card';
import { MonthlyStarData } from '../utils/monthlyFlyingStarsCalculator';
import { Sparkles, Heart, Briefcase, TrendingUp } from 'lucide-react';

interface MonthlyFlyingStarsRecommendationsProps {
  stars: MonthlyStarData[];
}

export default function MonthlyFlyingStarsRecommendations({ stars }: MonthlyFlyingStarsRecommendationsProps) {
  const getBestSectors = (activity: string) => {
    return stars
      .filter(s => s.activities.includes(activity) && ['excellent', 'good'].includes(s.favorability))
      .sort((a, b) => {
        const order = { excellent: 0, good: 1, neutral: 2, poor: 3, bad: 4 };
        return order[a.favorability] - order[b.favorability];
      })
      .slice(0, 3);
  };

  const recommendations = [
    { activity: 'Wealth', icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
    { activity: 'Career', icon: Briefcase, color: 'text-blue-600', bg: 'bg-blue-50' },
    { activity: 'Relationships', icon: Heart, color: 'text-pink-600', bg: 'bg-pink-50' },
    { activity: 'Health', icon: Sparkles, color: 'text-purple-600', bg: 'bg-purple-50' }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {recommendations.map(({ activity, icon: Icon, color, bg }) => {
        const bestSectors = getBestSectors(activity);
        return (
          <Card key={activity} className={`p-4 ${bg} border-2`}>
            <div className="flex items-center gap-2 mb-3">
              <Icon className={`w-5 h-5 ${color}`} />
              <h4 className="font-bold text-gray-900">{activity}</h4>
            </div>
            {bestSectors.length > 0 ? (
              <div className="space-y-2">
                {bestSectors.map((sector, i) => (
                  <div key={i} className="bg-white/70 rounded p-2 text-sm">
                    <div className="font-semibold">{sector.direction}</div>
                    <div className="text-xs text-gray-600">
                      Stars: {sector.annualStar}-{sector.monthlyStar}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-600">No favorable sectors this month</p>
            )}
          </Card>
        );
      })}
    </div>
  );
}
