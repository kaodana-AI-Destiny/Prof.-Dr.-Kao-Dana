import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { zodiacAnimals } from "@/data/zodiacData";
import { YearData } from "@/utils/calendarCalculator";
import { generateYearMonths } from "@/utils/monthlyCalculator";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import MonthDetailModal from "./MonthDetailModal";
import { calculateKuaNumber, getFavorableDirections } from "@/utils/fengShuiCalculator";


interface YearModalProps {
  yearData: YearData | null;
  isOpen: boolean;
  onClose: () => void;
  onGenerateBazi?: (date: Date, hour: number, gender: 'male' | 'female') => void;
}


const elementColors: Record<string, string> = {
  Metal: "bg-gray-200 text-gray-800",
  Water: "bg-blue-200 text-blue-800",
  Wood: "bg-green-200 text-green-800",
  Fire: "bg-red-200 text-red-800",
  Earth: "bg-amber-200 text-amber-800"
};

export default function YearModal({ yearData, isOpen, onClose, onGenerateBazi }: YearModalProps) {
  const [selectedMonth, setSelectedMonth] = useState<{ month: number; name: string } | null>(null);
  const [isMonthModalOpen, setIsMonthModalOpen] = useState(false);

  if (!yearData) return null;
  
  const zodiac = zodiacAnimals[yearData.zodiacIndex];
  const months = generateYearMonths(yearData.year);
  const maleKua = calculateKuaNumber(yearData.year, 'male');
  const femaleKua = calculateKuaNumber(yearData.year, 'female');
  const maleDirections = getFavorableDirections(maleKua);
  const femaleDirections = getFavorableDirections(femaleKua);

  const handleMonthClick = (monthNumber: number, monthName: string) => {
    setSelectedMonth({ month: monthNumber, name: monthName });
    setIsMonthModalOpen(true);
  };

  const handleGenerateBaziForYear = () => {
    if (onGenerateBazi) {
      // Generate BaZi for January 1st at noon (12:00) for this year
      const date = new Date(yearData.year, 0, 1, 12, 0, 0);
      onGenerateBazi(date, 12, 'male');
      onClose(); // Close the modal after generating
    }
  };


  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-3xl font-bold">{yearData.year}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="aspect-video overflow-hidden rounded-lg bg-gradient-to-br from-blue-900 to-purple-900">
                <img src={zodiac.image} alt={zodiac.name} className="w-full h-full object-cover" />
              </div>
              
              <div>
                <h3 className="text-2xl font-bold mb-2">{zodiac.name} - {zodiac.khmerName}</h3>
                <div className="flex gap-2 mb-4">
                  <Badge className={elementColors[yearData.element]}>
                    {yearData.khmerElement} {yearData.hNumber} {yearData.chineseChar} {yearData.element} {yearData.polarity}
                  </Badge>
                </div>
                
                <div className="mb-4">
                  <h4 className="font-semibold mb-2">Personality Traits</h4>
                  <div className="flex flex-wrap gap-2">
                    {zodiac.traits.slice(0, 4).map((trait, i) => (
                      <Badge key={i} variant="secondary">{trait}</Badge>
                    ))}
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="font-semibold mb-2">Kua Numbers (Feng Shui)</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <Card className="p-3">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600 mb-1">♂ {maleKua}</div>
                        <div className="text-xs text-gray-600 mb-2">Male Kua</div>
                        <div className="text-xs">
                          <div className="font-semibold">Best: {maleDirections.best.join(', ')}</div>
                        </div>
                      </div>
                    </Card>
                    <Card className="p-3">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-pink-600 mb-1">♀ {femaleKua}</div>
                        <div className="text-xs text-gray-600 mb-2">Female Kua</div>
                        <div className="text-xs">
                          <div className="font-semibold">Best: {femaleDirections.best.join(', ')}</div>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
                
                {/* Generate BaZi Button */}
                <div className="mb-4">
                  <Button 
                    onClick={handleGenerateBaziForYear}
                    className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-semibold"
                  >
                    🔮 Generate BaZi Chart for {yearData.year}
                  </Button>
                  <p className="text-xs text-gray-500 text-center mt-2">
                    Will generate Four Pillars for Jan 1, {yearData.year} at 12:00 PM
                  </p>
                </div>
              </div>
            </div>


            <div>
              <h3 className="text-2xl font-bold mb-4">Monthly Zodiac & Elements - Click to View Days</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {months.map((month) => {
                  const monthZodiac = zodiacAnimals[month.zodiacIndex];
                  return (
                    <Card 
                      key={month.monthNumber} 
                      className="p-3 hover:shadow-lg transition-all cursor-pointer hover:scale-105"
                      onClick={() => handleMonthClick(month.monthNumber, month.monthName)}
                    >
                      <div className="text-sm font-semibold mb-2">{month.monthName}</div>
                      <img src={monthZodiac.image} alt={monthZodiac.name} className="w-16 h-16 mx-auto mb-2" />
                      <div className="text-xs text-center font-medium mb-1">{monthZodiac.name}</div>
                      <Badge className={`w-full justify-center text-xs ${elementColors[month.element]}`}>
                        {month.khmerElement} {month.hNumber} {month.chineseChar}
                      </Badge>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {selectedMonth && (
        <MonthDetailModal
          year={yearData.year}
          month={selectedMonth.month}
          monthName={selectedMonth.name}
          isOpen={isMonthModalOpen}
          onClose={() => setIsMonthModalOpen(false)}
        />
      )}
    </>
  );
}

