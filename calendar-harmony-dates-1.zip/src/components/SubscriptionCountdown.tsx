import { useEffect, useState } from 'react';
import { Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { UserSubscription } from '@/lib/subscriptionTypes';
import { calculateDaysRemaining, formatTimeRemaining, getSubscriptionStatus } from '@/utils/subscriptionChecker';

interface SubscriptionCountdownProps {
  subscription: UserSubscription;
}

export default function SubscriptionCountdown({ subscription }: SubscriptionCountdownProps) {
  const [daysRemaining, setDaysRemaining] = useState(calculateDaysRemaining(subscription.end_date));
  const status = getSubscriptionStatus(subscription);

  useEffect(() => {
    const interval = setInterval(() => {
      setDaysRemaining(calculateDaysRemaining(subscription.end_date));
    }, 1000 * 60 * 60); // Update every hour

    return () => clearInterval(interval);
  }, [subscription.end_date]);

  const totalDays = subscription.plan === 'daily' ? 1 : 
                    subscription.plan === 'weekly' ? 7 :
                    subscription.plan === 'monthly' ? 30 : 365;
  const progress = Math.max(0, (daysRemaining / totalDays) * 100);

  const getStatusColor = () => {
    if (status === 'expired') return 'text-red-600';
    if (status === 'grace_period') return 'text-orange-600';
    if (daysRemaining <= 3) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getStatusIcon = () => {
    if (status === 'expired') return <XCircle className="w-5 h-5" />;
    if (status === 'grace_period') return <AlertTriangle className="w-5 h-5" />;
    if (daysRemaining <= 3) return <AlertTriangle className="w-5 h-5" />;
    return <CheckCircle className="w-5 h-5" />;
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-purple-600" />
          <h3 className="font-semibold">Subscription Status</h3>
        </div>
        <Badge variant={status === 'active' ? 'default' : 'destructive'}>
          {subscription.plan.toUpperCase()}
        </Badge>
      </div>

      <div className={`flex items-center gap-2 mb-3 ${getStatusColor()}`}>
        {getStatusIcon()}
        <span className="font-medium">{formatTimeRemaining(daysRemaining)}</span>
      </div>

      <Progress value={progress} className="mb-3" />

      <div className="text-sm text-gray-600">
        <p>Expires: {new Date(subscription.end_date).toLocaleDateString()}</p>
        {status === 'grace_period' && subscription.grace_period_end && (
          <p className="text-orange-600 mt-1">
            Grace period ends: {new Date(subscription.grace_period_end).toLocaleDateString()}
          </p>
        )}
      </div>
    </Card>
  );
}
