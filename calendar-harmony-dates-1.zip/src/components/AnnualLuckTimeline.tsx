import React from 'react';
import { Card } from './ui/card';
import { AnnualLuck } from '../utils/annualLuckCalculator';

interface AnnualLuckTimelineProps {
  annualLucks: AnnualLuck[];
  currentYear: number;
}

const fortuneColors = {
  excellent: 'bg-green-500',
  good: 'bg-blue-500',
  neutral: 'bg-gray-400',
  challenging: 'bg-orange-500',
  difficult: 'bg-red-500'
};

const fortuneLabels = {
  excellent: '極佳',
  good: '良好',
  neutral: '平穩',
  challenging: '挑戰',
  difficult: '困難'
};

export const AnnualLuckTimeline: React.FC<AnnualLuckTimelineProps> = ({ annualLucks, currentYear }) => {
  return (
    <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50">
      <h3 className="text-2xl font-bold mb-6 text-center text-purple-900">
        បន្ទាត់ពេលវេលាសំណាងប្រចាំឆ្នាំ Annual Fortune Timeline (流年運勢時間軸)
      </h3>

      
      <div className="space-y-4">
        {annualLucks.map((luck, index) => (
          <div key={luck.year} className="relative">
            {/* Timeline connector */}
            {index < annualLucks.length - 1 && (
              <div className="absolute left-6 top-12 w-0.5 h-full bg-gray-300 z-0" />
            )}
            
            <div className={`flex items-start gap-4 ${luck.year === currentYear ? 'ring-4 ring-purple-500 rounded-lg p-2 bg-white' : ''}`}>
              {/* Year indicator */}
              <div className="flex-shrink-0 z-10">
                <div className={`w-12 h-12 rounded-full ${fortuneColors[luck.fortuneLevel]} flex items-center justify-center text-white font-bold shadow-lg`}>
                  {luck.year % 100}
                </div>
              </div>
              
              {/* Content */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h4 className="text-lg font-bold text-gray-900">{luck.year}年</h4>
                  <span className="text-2xl">{luck.stemChinese}{luck.branchChinese}</span>
                  <span className="text-sm text-gray-600">{luck.stemKhmer} {luck.stemEnglish} - {luck.branchKhmer} {luck.branchEnglish}</span>
                  <span className="text-sm text-gray-600">{luck.element} {luck.polarity}</span>
                  <span className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${fortuneColors[luck.fortuneLevel]}`}>
                    {fortuneLabels[luck.fortuneLevel]}
                  </span>
                </div>

                
                {luck.significantEvents.length > 0 && (
                  <div className="mb-2">
                    {luck.significantEvents.map((event, i) => (
                      <p key={i} className="text-sm text-purple-700 font-medium">{event}</p>
                    ))}
                  </div>
                )}
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  <div className="bg-white p-2 rounded shadow-sm">
                    <span className="font-semibold text-blue-600">អាជីព Career 事業:</span> {luck.predictions.career}
                  </div>
                  <div className="bg-white p-2 rounded shadow-sm">
                    <span className="font-semibold text-green-600">ទ្រព្យសម្បត្តិ Wealth 財運:</span> {luck.predictions.wealth}
                  </div>
                  <div className="bg-white p-2 rounded shadow-sm">
                    <span className="font-semibold text-pink-600">ទំនាក់ទំនង Relationships 感情:</span> {luck.predictions.relationships}
                  </div>
                  <div className="bg-white p-2 rounded shadow-sm">
                    <span className="font-semibold text-orange-600">សុខភាព Health 健康:</span> {luck.predictions.health}
                  </div>
                </div>

              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Legend */}
      <div className="mt-6 pt-6 border-t border-gray-300">
        <h4 className="text-sm font-semibold mb-3 text-gray-700">運勢等級 (Fortune Levels):</h4>
        <div className="flex flex-wrap gap-3">
          {Object.entries(fortuneLabels).map(([key, label]) => (
            <div key={key} className="flex items-center gap-2">
              <div className={`w-4 h-4 rounded-full ${fortuneColors[key as keyof typeof fortuneColors]}`} />
              <span className="text-sm text-gray-700">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};
