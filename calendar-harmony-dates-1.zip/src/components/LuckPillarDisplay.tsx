import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { TrendingUp, TrendingDown, Sparkles, AlertTriangle } from 'lucide-react';
import type { LuckPillar } from '@/utils/luckPillarCalculator';

interface LuckPillarDisplayProps {
  pillars: LuckPillar[];
  startingAge: number;
  currentAge?: number;
}

const elementColors: { [key: string]: string } = {
  Wood: 'bg-green-500',
  Fire: 'bg-red-500',
  Earth: 'bg-yellow-600',
  Metal: 'bg-gray-400',
  Water: 'bg-blue-500'
};

export const LuckPillarDisplay: React.FC<LuckPillarDisplayProps> = ({ 
  pillars, 
  startingAge,
  currentAge 
}) => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-purple-500" />
          សសរសំណាង១០ឆ្នាំ 10-Year Luck Pillars (大運 - Da Yun)
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          ចាប់ផ្តើមនៅអាយុ Starting at age {startingAge}, សសរនីមួយៗមានឥទ្ធិពលលើជីវិតរយៈពេលមួយទសវត្សរ៍ each pillar influences a decade of your life
        </p>

      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pillars.map((pillar, index) => {
            const isCurrentPeriod = currentAge && 
              currentAge >= pillar.startAge && 
              currentAge <= pillar.endAge;
            
            return (
              <div
                key={index}
                className={`border rounded-lg p-4 transition-all ${
                  isCurrentPeriod ? 'border-purple-500 bg-purple-50 dark:bg-purple-950' : 'border-border'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-bold">
                        {pillar.stem.chinese}{pillar.branch.chinese} 
                        <span className="ml-2 text-sm text-muted-foreground">
                          {pillar.stem.khmer} {pillar.stem.name} - {pillar.branch.khmerAnimal} {pillar.branch.name}
                        </span>
                      </h3>

                      {isCurrentPeriod && (
                        <Badge variant="default" className="bg-purple-500">បច្ចុប្បន្ន Current</Badge>
                      )}
                    </div>
                    <p className="text-sm font-medium">
                      អាយុ Ages {pillar.startAge} - {pillar.endAge}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Badge className={elementColors[pillar.element]}>
                      {pillar.element} {pillar.polarity}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm font-medium text-green-600 dark:text-green-400">
                      <TrendingUp className="h-4 w-4" />
                      ឥទ្ធិពលល្អ Favorable Influences
                    </div>
                    {pillar.interactions.favorable.length > 0 ? (
                      <ul className="text-sm space-y-1 ml-6">
                        {pillar.interactions.favorable.map((item, i) => (
                          <li key={i} className="list-disc">{item}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-muted-foreground ml-6">រយៈពេលអព្យាក្រឹត Neutral period</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm font-medium text-red-600 dark:text-red-400">
                      <TrendingDown className="h-4 w-4" />
                      តំបន់លំបាក Challenging Areas
                    </div>
                    {pillar.interactions.challenging.length > 0 ? (
                      <ul className="text-sm space-y-1 ml-6">
                        {pillar.interactions.challenging.map((item, i) => (
                          <li key={i} className="list-disc">{item}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-muted-foreground ml-6">គ្មានបញ្ហាធំ No major challenges</p>
                    )}
                  </div>
                </div>

                <Separator className="my-2" />

                <div className="text-sm">
                  <span className="font-medium">សមត្ថភាពទាំង១០ Ten God: </span>
                  <span className="text-muted-foreground">
                    {pillar.tenGod.chinese} ({pillar.tenGod.pinyin}) - {pillar.tenGod.english}
                  </span>

                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
