import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Consultant } from "@/data/consultantsData";
import { CreditCard, Calendar as CalendarIcon, Clock, Video, Users, RefreshCw } from "lucide-react";

interface BookingModalProps {
  consultant: Consultant | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (bookingData: BookingData) => void;
}

export interface BookingData {
  consultant: Consultant;
  date: Date;
  time: string;
  duration: string;
  name: string;
  email: string;
  phone: string;
  notes: string;
  videoPlatform: string;
  isGroup: boolean;
  groupSize: number;
  isRecurring: boolean;
  recurringFrequency: string;
  recurringEndDate?: Date;
  reminderEmail: boolean;
  reminderSMS: boolean;
}


export default function BookingModal({ consultant, isOpen, onClose, onConfirm }: BookingModalProps) {
  const [step, setStep] = useState(1);
  const [date, setDate] = useState<Date>();
  const [time, setTime] = useState("");
  const [duration, setDuration] = useState("1");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [videoPlatform, setVideoPlatform] = useState("zoom");
  const [isGroup, setIsGroup] = useState(false);
  const [groupSize, setGroupSize] = useState(2);
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringFrequency, setRecurringFrequency] = useState("weekly");
  const [recurringEndDate, setRecurringEndDate] = useState<Date>();
  const [reminderEmail, setReminderEmail] = useState(true);
  const [reminderSMS, setReminderSMS] = useState(false);

  const timeSlots = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00", "17:00"];

  const handleNext = () => {
    if (step === 1 && date && time) setStep(2);
    else if (step === 2 && name && email && phone) setStep(3);
  };

  const handleConfirm = () => {
    if (consultant && date) {
      onConfirm({
        consultant, date, time, duration, name, email, phone, notes,
        videoPlatform, isGroup, groupSize, isRecurring, recurringFrequency,
        recurringEndDate, reminderEmail, reminderSMS
      });
      resetForm();
    }
  };

  const resetForm = () => {
    setStep(1); setDate(undefined); setTime(""); setDuration("1");
    setName(""); setEmail(""); setPhone(""); setNotes("");
    setVideoPlatform("zoom"); setIsGroup(false); setGroupSize(2);
    setIsRecurring(false); setRecurringFrequency("weekly");
    setRecurringEndDate(undefined); setReminderEmail(true); setReminderSMS(false);
  };

  const groupMultiplier = isGroup ? groupSize : 1;
  const recurringMultiplier = isRecurring && recurringEndDate ? 
    Math.ceil((recurringEndDate.getTime() - (date?.getTime() || 0)) / (recurringFrequency === 'weekly' ? 604800000 : 2592000000)) : 1;
  const totalCost = consultant ? consultant.hourlyRate * parseFloat(duration) * groupMultiplier * recurringMultiplier : 0;


  if (!consultant) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) { resetForm(); onClose(); } }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Book Consultation with {consultant.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex justify-between mb-6">
            {[1, 2, 3].map((s) => (
              <div key={s} className={`flex-1 h-2 rounded ${s <= step ? 'bg-amber-500' : 'bg-gray-200'} ${s < 3 ? 'mr-2' : ''}`} />
            ))}
          </div>

          {step === 1 && (
            <div className="space-y-4">
              <div><Label className="flex items-center gap-2 mb-2"><CalendarIcon className="w-4 h-4" />Select Date</Label>
                <Calendar mode="single" selected={date} onSelect={setDate} disabled={(date) => date < new Date()} className="rounded-md border" />
              </div>
              <div><Label className="flex items-center gap-2 mb-2"><Clock className="w-4 h-4" />Select Time</Label>
                <Select value={time} onValueChange={setTime}>
                  <SelectTrigger><SelectValue placeholder="Choose time slot" /></SelectTrigger>
                  <SelectContent>{timeSlots.map((slot) => <SelectItem key={slot} value={slot}>{slot}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Duration (hours)</Label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hour</SelectItem>
                    <SelectItem value="1.5">1.5 hours</SelectItem>
                    <SelectItem value="2">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label className="flex items-center gap-2"><Video className="w-4 h-4" />Video Platform</Label>
                <Select value={videoPlatform} onValueChange={setVideoPlatform}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="zoom">Zoom</SelectItem>
                    <SelectItem value="google-meet">Google Meet</SelectItem>
                    <SelectItem value="in-person">In-Person</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="group" checked={isGroup} onCheckedChange={(checked) => setIsGroup(checked as boolean)} />
                <Label htmlFor="group" className="flex items-center gap-2"><Users className="w-4 h-4" />Group Consultation</Label>
              </div>
              {isGroup && (
                <div><Label>Group Size</Label>
                  <Select value={groupSize.toString()} onValueChange={(v) => setGroupSize(parseInt(v))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{[2,3,4,5].map(n => <SelectItem key={n} value={n.toString()}>{n} people</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <Checkbox id="recurring" checked={isRecurring} onCheckedChange={(checked) => setIsRecurring(checked as boolean)} />
                <Label htmlFor="recurring" className="flex items-center gap-2"><RefreshCw className="w-4 h-4" />Recurring Appointment</Label>
              </div>
              {isRecurring && (
                <>
                  <div><Label>Frequency</Label>
                    <Select value={recurringFrequency} onValueChange={setRecurringFrequency}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>End Date</Label>
                    <Calendar mode="single" selected={recurringEndDate} onSelect={setRecurringEndDate} disabled={(d) => !date || d <= date} className="rounded-md border" />
                  </div>
                </>
              )}
              <Button onClick={handleNext} disabled={!date || !time} className="w-full">Next</Button>
            </div>
           )}

          {step === 2 && (
            <div className="space-y-4">
              <div><Label>Full Name *</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter your name" />
              </div>
              <div><Label>Email *</Label>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" />
              </div>
              <div><Label>Phone *</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+855 12 345 678" />
              </div>
              <div><Label>Notes (Optional)</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Any specific questions or concerns?" rows={3} />
              </div>
              <div className="border-t pt-3 mt-3">
                <Label className="mb-2 block">Reminder Preferences</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="emailReminder" checked={reminderEmail} onCheckedChange={(checked) => setReminderEmail(checked as boolean)} />
                    <Label htmlFor="emailReminder" className="text-sm">Email reminder 24 hours before</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="smsReminder" checked={reminderSMS} onCheckedChange={(checked) => setReminderSMS(checked as boolean)} />
                    <Label htmlFor="smsReminder" className="text-sm">SMS reminder 2 hours before</Label>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">Back</Button>
                <Button onClick={handleNext} disabled={!name || !email || !phone} className="flex-1">Next</Button>
              </div>
            </div>
           )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="bg-amber-50 p-4 rounded-lg space-y-2">
                <h3 className="font-bold text-lg mb-3">Booking Summary</h3>
                <p><strong>Consultant:</strong> {consultant.name}</p>
                <p><strong>Date:</strong> {date?.toLocaleDateString()}</p>
                <p><strong>Time:</strong> {time}</p>
                <p><strong>Duration:</strong> {duration} hour(s)</p>
                <p><strong>Platform:</strong> {videoPlatform === 'zoom' ? 'Zoom' : videoPlatform === 'google-meet' ? 'Google Meet' : 'In-Person'}</p>
                {isGroup && <p><strong>Group Size:</strong> {groupSize} people</p>}
                {isRecurring && <p><strong>Recurring:</strong> {recurringFrequency} until {recurringEndDate?.toLocaleDateString()}</p>}
                <p className="text-2xl font-bold text-amber-600 mt-4">Total: ${totalCost.toFixed(2)}</p>
              </div>

              <div className="border-t pt-4">
                <Label className="flex items-center gap-2 mb-2"><CreditCard className="w-4 h-4" />Payment Method</Label>
                <p className="text-sm text-gray-600 mb-3">Secure payment processing</p>
                <Input placeholder="Card Number" className="mb-2" />
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="MM/YY" />
                  <Input placeholder="CVV" />
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(2)} className="flex-1">Back</Button>
                <Button onClick={handleConfirm} className="flex-1 bg-green-600 hover:bg-green-700">Confirm & Pay</Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
