import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { calculateDailyData, DailyData } from "@/utils/dailyCalculator";
import { zodiacAnimals } from "@/data/zodiacData";
import DayDetailModal from "./DayDetailModal";
import { Badge } from "@/components/ui/badge";

interface MonthDetailModalProps {
  year: number;
  month: number;
  monthName: string;
  isOpen: boolean;
  onClose: () => void;
}

export default function MonthDetailModal({ year, month, monthName, isOpen, onClose }: MonthDetailModalProps) {
  const [selectedDay, setSelectedDay] = useState<DailyData | null>(null);
  const [isDayModalOpen, setIsDayModalOpen] = useState(false);

  const firstDay = new Date(year, month - 1, 1);
  const lastDay = new Date(year, month, 0);
  const daysInMonth = lastDay.getDate();
  const startingDayOfWeek = firstDay.getDay();

  const handleDayClick = (day: number) => {
    const date = new Date(year, month - 1, day);
    const dayData = calculateDailyData(date);
    setSelectedDay(dayData);
    setIsDayModalOpen(true);
  };

  const days = [];
  for (let i = 0; i < startingDayOfWeek; i++) {
    days.push(<div key={`empty-${i}`} />);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month - 1, day);
    const dailyData = calculateDailyData(date);
    const zodiac = zodiacAnimals[dailyData.zodiacIndex];

    days.push(
      <Card
        key={day}
        onClick={() => handleDayClick(day)}
        className="p-2 cursor-pointer hover:shadow-lg transition-all hover:scale-105"
      >
        <div className="text-sm font-semibold mb-1">{day}</div>
        <img src={zodiac.image} alt={zodiac.name} className="w-8 h-8 mx-auto mb-1" />
        <div className="text-xs text-center truncate">{zodiac.name}</div>
        <Badge className="text-xs w-full justify-center mt-1" variant="outline">
          {dailyData.khmerElement}{dailyData.polarity === 'Yang' ? '+' : '-'} {dailyData.hNumber} {dailyData.chineseChar}
        </Badge>
        <div className="text-xs text-center text-gray-600 mt-1">
          {dailyData.element} {dailyData.polarity}
        </div>
      </Card>
    );

  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">{monthName} {year}</DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-7 gap-2 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center font-semibold text-gray-700 py-2 text-sm">{day}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">{days}</div>
        </DialogContent>
      </Dialog>

      <DayDetailModal dayData={selectedDay} isOpen={isDayModalOpen} onClose={() => setIsDayModalOpen(false)} />
    </>
  );
}
