import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DailyData } from "@/utils/dailyCalculator";
import { zodiacAnimals } from "@/data/zodiacData";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { earthlyBranches, heavenlyStems } from "@/utils/baziCalculator";
import { getChineseMonth, getChineseYear } from "@/utils/chineseMonthCalculator";
import { Clock, Calendar, CalendarDays } from "lucide-react";



interface DayDetailModalProps {
  dayData: DailyData | null;
  isOpen: boolean;
  onClose: () => void;
  onGenerateBazi?: (date: Date, hour: number) => void;
}

export default function DayDetailModal({ dayData, isOpen, onClose, onGenerateBazi }: DayDetailModalProps) {
  const [time, setTime] = useState("12:00");
  
  if (!dayData) return null;

  const zodiac = zodiacAnimals[dayData.zodiacIndex];
  const chineseMonth = getChineseMonth(dayData.date);
  const chineseYear = getChineseYear(dayData.date);

  
  const khmerDays = ['អាទិត្យ', 'ចន្ទ', 'អង្គារ', 'ពុធ', 'ព្រហស្បតិ៍', 'សុក្រ', 'សៅរ៍'];
  const dayOfWeek = dayData.date.getDay();
  const khmerDay = khmerDays[dayOfWeek];
  
  const formattedDate = dayData.date.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  const fullFormattedDate = `${khmerDay} ${formattedDate}`;


  const handleGenerateBazi = () => {
    if (onGenerateBazi && time) {
      const [hours, minutes] = time.split(':').map(Number);
      const baziDate = new Date(dayData.date);
      baziDate.setHours(hours, minutes, 0, 0);
      onGenerateBazi(baziDate, hours);
      onClose();
    }
  };

  // Calculate hour stems based on day stem (Five Rats Escape formula)
  const dayStemIndex = heavenlyStems.findIndex(
    stem => stem.element === dayData.element && stem.polarity === dayData.polarity
  );

  const getHourStem = (hourBranchIndex: number) => {
    const fiveRatsBase = [0, 2, 4, 6, 8];
    const dayStemGroup = dayStemIndex % 5;
    const ziHourStem = fiveRatsBase[dayStemGroup];
    const hourStemIndex = (ziHourStem + hourBranchIndex) % 10;
    return heavenlyStems[hourStemIndex];
  };

  const timeRanges = [
    "11PM - 1AM", "1AM - 3AM", "3AM - 5AM", "5AM - 7AM",
    "7AM - 9AM", "9AM - 11AM", "11AM - 1PM", "1PM - 3PM",
    "3PM - 5PM", "5PM - 7PM", "7PM - 9PM", "9PM - 11PM"
  ];

  const elementColors: { [key: string]: string } = {
    Wood: "bg-green-100 border-green-300",
    Fire: "bg-red-100 border-red-300",
    Earth: "bg-yellow-100 border-yellow-300",
    Metal: "bg-gray-100 border-gray-300",
    Water: "bg-blue-100 border-blue-300"
  };


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{fullFormattedDate}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="flex items-center gap-6">
            <img src={zodiac.image} alt={zodiac.name} className="w-48 h-48 object-cover rounded-lg shadow-lg" />
            <div>
              <h3 className="text-3xl font-bold">{zodiac.name}</h3>
              <p className="text-xl text-gray-600 mt-1">{zodiac.khmerName}</p>
              <div className="mt-3">
                <p className="text-lg font-semibold text-gray-800">
                  {dayData.khmerElement}{dayData.polarity === 'Yang' ? '+' : '-'} {dayData.hNumber} {dayData.chineseChar} {dayData.element} {dayData.polarity}
                </p>
              </div>
            </div>
          </div>


          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Traits</h4>
              <div className="flex flex-wrap gap-2">
                {zodiac.traits.map(trait => <Badge key={trait}>{trait}</Badge>)}
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Lucky Colors</h4>
              <div className="flex flex-wrap gap-2">
                {zodiac.luckyColors.map(color => <Badge key={color} variant="secondary">{color}</Badge>)}
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Lucky Numbers</h4>
            <div className="flex gap-2">
              {zodiac.luckyNumbers.map(num => <Badge key={num} variant="outline">{num}</Badge>)}
            </div>
          </div>

          {/* Chinese Year Section */}
          <div className="bg-gradient-to-br from-rose-50 to-pink-50 p-6 rounded-lg border-2 border-rose-200">
            <div className="flex items-center gap-2 mb-3">
              <CalendarDays className="w-6 h-6 text-rose-600" />
              <h4 className="font-bold text-lg">ឆ្នាំចិន Chinese Zodiac Year</h4>
            </div>
            <div className="flex items-center gap-4">
              <div className={`px-6 py-4 rounded-lg ${elementColors[chineseYear.element]} border-2`}>
                <div className="text-3xl font-bold text-center">{chineseYear.chineseChar}</div>
                <div className="text-lg font-semibold text-center mt-1">{chineseYear.animal}</div>
                <div className="text-sm text-center text-gray-700 mt-1">{chineseYear.year}</div>
              </div>
              <div>
                <p className="text-sm"><span className="font-semibold">Year:</span> {chineseYear.year}</p>
                <p className="text-sm"><span className="font-semibold">Element:</span> {chineseYear.element}</p>
                <p className="text-sm"><span className="font-semibold">Polarity:</span> {chineseYear.polarity}</p>
                <p className="text-xs text-gray-600 mt-2">Chinese New Year starts on February 4th (Tiger month)</p>
              </div>
            </div>
          </div>

          {/* Chinese Month Section */}
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-lg border-2 border-indigo-200">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-6 h-6 text-indigo-600" />
              <h4 className="font-bold text-lg">ខែចិន Chinese Zodiac Month</h4>
            </div>
            <div className="flex items-center gap-4">
              <div className={`px-6 py-4 rounded-lg ${elementColors[chineseMonth.element]} border-2`}>
                <div className="text-3xl font-bold text-center">{chineseMonth.chineseChar}</div>
                <div className="text-lg font-semibold text-center mt-1">{chineseMonth.animal}</div>
              </div>
              <div>
                <p className="text-sm"><span className="font-semibold">Element:</span> {chineseMonth.element}</p>
                <p className="text-sm"><span className="font-semibold">Polarity:</span> {chineseMonth.polarity}</p>
                <p className="text-xs text-gray-600 mt-2">This day belongs to the {chineseMonth.animal} month in the Chinese solar calendar</p>
              </div>
            </div>
          </div>



          {/* Time Zodiac Section */}
          <div className="bg-gradient-to-br from-purple-50 to-blue-50 p-6 rounded-lg border-2 border-purple-200">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-6 h-6 text-purple-600" />
              <h4 className="font-bold text-lg">ពេលវេលា និងធាតុ Time & Elements for This Day</h4>
            </div>
            <p className="text-sm text-gray-600 mb-4">12 Two-Hour Periods - Based on Day Element: {dayData.element} {dayData.polarity}</p>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {earthlyBranches.map((branch, index) => {
                const hourStem = getHourStem(index);
                return (
                  <Card 
                    key={index}
                    className={`p-3 ${elementColors[hourStem.element]} border-2 hover:shadow-md transition-all`}
                  >
                    <div className="text-center">
                      <div className="text-lg font-bold">{hourStem.chinese}{branch.chinese}</div>
                      <div className="text-sm font-semibold text-gray-800">{branch.animal}</div>
                      <div className="text-xs text-gray-600">{timeRanges[index]}</div>
                      <div className="text-xs font-semibold text-gray-800 mt-1">
                        {hourStem.element} {hourStem.polarity}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          {onGenerateBazi && (
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-lg border-2 border-amber-200">
              <h4 className="font-bold text-lg mb-4">បង្កើតតារាង BaZi សម្រាប់ថ្ងៃនេះ Generate BaZi Chart for This Date</h4>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="bazi-time" className="text-base">ជ្រើសរើសម៉ោង Select Birth Time</Label>
                  <Input 
                    id="bazi-time" 
                    type="time" 
                    value={time} 
                    onChange={(e) => setTime(e.target.value)} 
                    className="mt-2"
                  />
                </div>
                <Button 
                  onClick={handleGenerateBazi}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
                >
                  បង្កើតតារាង BaZi Generate BaZi Chart
                </Button>
              </div>
            </div>
          )}

        </div>
      </DialogContent>
    </Dialog>
  );
}
