import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
interface Period2FlyingStarsFormProps {
  onCalculate: (date: Date, hour: number) => void;
}
export function Period2FlyingStarsForm({
  onCalculate
}: Period2FlyingStarsFormProps) {
  const [date, setDate] = useState('2064-02-04');
  const [hour, setHour] = useState('12');
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedDate = new Date(date);
    onCalculate(selectedDate, parseInt(hour));
  };
  const handleUseNow = () => {
    const now = new Date();
    setDate(now.toISOString().split('T')[0]);
    setHour(now.getHours().toString());
    onCalculate(now, now.getHours());
  };
  return <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-lg">
      <div className="space-y-4">
        <div>
          <Label htmlFor="date">Select Date (Period 2: 2064-2083)</Label>
          <Input id="date" type="date" value={date} onChange={e => setDate(e.target.value)} min="2064-02-04" max="2083-02-03" className="mt-1" />
        </div>
        
        <div>
          <Label htmlFor="hour">Hour (0-23)</Label>
          <Input id="hour" type="number" min="0" max="23" value={hour} onChange={e => setHour(e.target.value)} className="mt-1" />
        </div>

        <div className="flex gap-2">
          <Button type="submit" className="flex-1 text-[#c5c90e]">រកទីតាំងតារាសាស្ត្រ-យុគ2 Calculate Flying Star Period 2</Button>
          <Button type="button" onClick={handleUseNow} variant="outline">Use Now</Button>
        </div>
      </div>
    </form>;
}