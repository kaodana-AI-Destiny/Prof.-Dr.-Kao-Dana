import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { calculateMonthData } from "@/utils/monthlyCalculator";
import { zodiacAnimals } from "@/data/zodiacData";
import MonthDetailModal from "./MonthDetailModal";
export default function MonthlyZodiacOverview() {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<{
    year: number;
    month: number;
    monthName: string;
  } | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const months = Array.from({
    length: 12
  }, (_, i) => {
    const monthData = calculateMonthData(selectedYear, i + 1);
    const zodiac = zodiacAnimals[monthData.zodiacIndex];
    return {
      ...monthData,
      zodiac
    };
  });
  const handleMonthClick = (monthData: any) => {
    setSelectedMonth({
      year: selectedYear,
      month: monthData.monthNumber,
      monthName: monthData.monthName
    });
    setIsModalOpen(true);
  };
  const elementColors: Record<string, string> = {
    Fire: "bg-red-100 text-red-800",
    Earth: "bg-yellow-100 text-yellow-800",
    Metal: "bg-gray-100 text-gray-800",
    Water: "bg-blue-100 text-blue-800",
    Wood: "bg-green-100 text-green-800"
  };
  return <div className="max-w-7xl mx-auto px-4 py-16 bg-gradient-to-b from-purple-50 to-pink-50"><div className="text-center mb-8">
        <h2 className="text-4xl font-bold mb-2">ខែ សត្វ-ធាតុ Monthly Zodiac & Elements</h2>
        <p className="text-xl text-gray-600">ធាតុនិងសត្វប្រចាំខែ - Discover each month's zodiac and element</p>
      </div>{/* Reference Guide */}<div className="max-w-3xl mx-auto mb-12 p-6 bg-white rounded-lg shadow-md">
        <h3 className="text-xl font-bold mb-4 text-center text-gray-800">Monthly Cycle Reference</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
          <div className="flex justify-between items-center p-2 bg-red-50 rounded">
            <span className="font-semibold">October 2025:</span>
            <span className="text-red-700 font-bold">Dog Fire Yang</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-red-50 rounded">
            <span className="font-semibold">November 2025:</span>
            <span className="text-red-700 font-bold">Pig Fire Yin</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-yellow-50 rounded">
            <span className="font-semibold">December 2025:</span>
            <span className="text-yellow-700 font-bold">Rat Earth Yang</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-yellow-50 rounded">
            <span className="font-semibold">January 2026:</span>
            <span className="text-yellow-700 font-bold">Ox Earth Yin</span>
          </div>
        </div>
      </div><div className="flex items-center justify-center gap-4 mb-8">
        <Button onClick={() => setSelectedYear(selectedYear - 1)} variant="outline" size="lg">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h3 className="font-bold text-2xl">ចុចព្រួញឆ្វេង-ស្តាំ មើលខែក្នុងឆ្នាំ {selectedYear}</h3>


        <Button onClick={() => setSelectedYear(selectedYear + 1)} variant="outline" size="lg">
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div><div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {months.map(month => <Card key={month.monthNumber} onClick={() => handleMonthClick(month)} className="p-6 cursor-pointer hover:shadow-xl transition-all hover:scale-105 bg-white">
            <div className="text-center space-y-3">
              <h3 className="text-xl font-bold text-gray-800">{month.monthName} {selectedYear}</h3>
              <img src={month.zodiac.image} alt={month.zodiac.name} className="w-24 h-24 mx-auto" />
              <p className="font-bold text-lg text-gray-900">{month.zodiacName}</p>
              <div className="space-y-2">
                <Badge className={`text-base px-4 py-2 font-bold ${elementColors[month.element]}`}>
                  {month.element} {month.polarity}
                </Badge>
              </div>
            </div>
          </Card>)}
      </div>{selectedMonth && <MonthDetailModal year={selectedMonth.year} month={selectedMonth.month} monthName={selectedMonth.monthName} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />}Monthly Zodiac & Elements</div>;
}