import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, Languages } from "lucide-react";
import { Consultant } from "@/data/consultantsData";

interface ConsultantCardProps {
  consultant: Consultant;
  onBook: (consultant: Consultant) => void;
}

export default function ConsultantCard({ consultant, onBook }: ConsultantCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center">
          <img
            src={consultant.image}
            alt={consultant.name}
            className="w-32 h-32 rounded-full object-cover mb-4 border-4 border-amber-200"
          />
          <h3 className="text-xl font-bold mb-1">{consultant.name}</h3>
          <p className="text-lg text-gray-600 mb-3">{consultant.chineseName}</p>
          
          <Badge className="mb-3" variant={consultant.specialty === 'Both' ? 'default' : 'secondary'}>
            {consultant.specialty}
          </Badge>

          <div className="flex items-center gap-1 mb-2">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="font-semibold">{consultant.rating}</span>
            <span className="text-sm text-gray-500">({consultant.reviewCount} reviews)</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
            <Clock className="w-4 h-4" />
            <span>{consultant.experience} years experience</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
            <Languages className="w-4 h-4" />
            <span>{consultant.languages.join(', ')}</span>
          </div>

          <p className="text-sm text-gray-600 mb-4 line-clamp-3">{consultant.bio}</p>

          <div className="text-2xl font-bold text-amber-600 mb-4">
            ${consultant.hourlyRate}/hour
          </div>

          <Button 
            onClick={() => onBook(consultant)}
            className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
          >
            Book Consultation
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
