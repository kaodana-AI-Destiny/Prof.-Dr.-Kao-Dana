import { useState, useEffect } from "react";
import { Card } from "./ui/card";
import { earthlyBranches, heavenlyStems } from "@/utils/baziCalculator";
import { timeZodiacDetails } from "@/data/timeZodiacDetails";
import { TimeZodiacDetailModal } from "./TimeZodiacDetailModal";
import { calculateDailyData } from "@/utils/dailyCalculator";
import { Button } from "./ui/button";
const timeRanges = ["11PM - 1AM", "1AM - 3AM", "3AM - 5AM", "5AM - 7AM", "7AM - 9AM", "9AM - 11AM", "11AM - 1PM", "1PM - 3PM", "3PM - 5PM", "5PM - 7PM", "7PM - 9PM", "9PM - 11PM"];
const elementColors: {
  [key: string]: string;
} = {
  Wood: "bg-green-100 border-green-300",
  Fire: "bg-red-100 border-red-300",
  Earth: "bg-yellow-100 border-yellow-300",
  Metal: "bg-gray-100 border-gray-300",
  Water: "bg-blue-100 border-blue-300"
};
function getCurrentTimePeriod(): number {
  const now = new Date();
  const hour = now.getHours();
  if (hour >= 23 || hour < 1) return 0;
  if (hour >= 1 && hour < 3) return 1;
  if (hour >= 3 && hour < 5) return 2;
  if (hour >= 5 && hour < 7) return 3;
  if (hour >= 7 && hour < 9) return 4;
  if (hour >= 9 && hour < 11) return 5;
  if (hour >= 11 && hour < 13) return 6;
  if (hour >= 13 && hour < 15) return 7;
  if (hour >= 15 && hour < 17) return 8;
  if (hour >= 17 && hour < 19) return 9;
  if (hour >= 19 && hour < 21) return 10;
  return 11;
}

// Calculate hour stem based on day stem (Five Rats Escape formula)
function getHourStem(dayStemIndex: number, hourBranchIndex: number) {
  const fiveRatsBase = [0, 2, 4, 6, 8];
  const dayStemGroup = dayStemIndex % 5;
  const ziHourStem = fiveRatsBase[dayStemGroup];
  const hourStemIndex = (ziHourStem + hourBranchIndex) % 10;
  return heavenlyStems[hourStemIndex];
}
export default function TimeZodiacChart() {
  const [selectedPeriod, setSelectedPeriod] = useState<number | null>(null);
  const [currentPeriod, setCurrentPeriod] = useState<number>(getCurrentTimePeriod());
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const dailyData = calculateDailyData(selectedDate);
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPeriod(getCurrentTimePeriod());
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  // Find the day stem index based on daily data
  const dayStemIndex = heavenlyStems.findIndex(stem => stem.element === dailyData.element && stem.polarity === dailyData.polarity);
  return <div className="max-w-7xl mx-auto px-4 py-12">
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200 p-8 mb-6">
        <div className="text-center mb-6">
          <h3 className="font-bold mb-3 text-purple-500 text-2xl">រើសម៉ោងក្នុងថ្ងៃរបស់អ្នក Select Day to See Hour Elements</h3>
          <div className="flex justify-center gap-4 items-center flex-wrap">
            <Button onClick={() => setSelectedDate(new Date(selectedDate.getTime() - 86400000))}>
              Previous Day
            </Button>
            <div className="text-center">
              <div className="text-lg font-semibold">{selectedDate.toLocaleDateString()}</div>
              <div className="text-sm text-gray-600">
                Day Element: <span className="font-bold">{dailyData.element} {dailyData.polarity}</span>
              </div>
            </div>
            <Button onClick={() => setSelectedDate(new Date(selectedDate.getTime() + 86400000))}>
              Next Day
            </Button>
            <Button variant="outline" onClick={() => setSelectedDate(new Date())}>
              Today
            </Button>
          </div>
        </div>
      </Card>

      <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200 p-8">
        <div className="text-center mb-8">
          <h2 className="font-bold text-gray-800 mb-2 text-2xl">ម៉ោង សត្វ-ធាតុ ថ្ងៃនេះ | Time, Zodiac & Element</h2>
          <p className="text-lg text-gray-600" data-mixed-content="true" data-mixed-content="true">12 Two-Hour Periods - Elements Based on Day {dailyData.element} {dailyData.polarity}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {earthlyBranches.map((branch, index) => {
          const hourStem = getHourStem(dayStemIndex, index);
          const isCurrent = index === currentPeriod && selectedDate.toDateString() === new Date().toDateString();
          return <Card key={index} onClick={() => setSelectedPeriod(index)} className={`p-4 ${elementColors[hourStem.element]} border-2 hover:shadow-lg transition-all cursor-pointer
                  ${isCurrent ? 'ring-4 ring-purple-500 ring-offset-2 scale-105' : 'hover:scale-102'}`}>
                <div className="text-center">
                  {isCurrent && <div className="text-xs font-bold text-purple-600 mb-1 animate-pulse">
                      ● CURRENT TIME
                    </div>}
                  <div className="text-2xl font-bold mb-1">{hourStem.chinese}{branch.chinese}</div>
                  <div className="text-lg font-semibold text-gray-800">{branch.animal}</div>
                  <div className="text-sm text-gray-600 mb-2">{hourStem.name} {branch.name}</div>
                  <div className="text-xs font-medium text-gray-700 mb-2">{timeRanges[index]}</div>
                  <div className="text-sm font-semibold text-gray-800">
                    {hourStem.element} {hourStem.polarity}
                  </div>
                </div>
              </Card>;
        })}
        </div>
      </Card>

      <TimeZodiacDetailModal isOpen={selectedPeriod !== null} onClose={() => setSelectedPeriod(null)} detail={selectedPeriod !== null ? timeZodiacDetails[selectedPeriod] : null} />
    </div>;
}