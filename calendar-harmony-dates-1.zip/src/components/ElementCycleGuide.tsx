import { Card } from "./ui/card";

export default function ElementCycleGuide() {
  return (
    <Card className="p-6 bg-gradient-to-br from-slate-50 to-gray-50">
      <h4 className="font-bold text-xl mb-6 text-center">វដ្តធាតុទាំងប្រាំ Five Elements Cycle (五行)</h4>

      
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h5 className="font-bold text-green-800 text-lg">វដ្តផលិត Production Cycle (生)</h5>
          <p className="text-sm text-gray-600 mb-3">ធាតុដែលគាំទ្រនិងចិញ្ចឹមគ្នាទៅវិញទៅមក Elements that support and nourish each other</p>

          
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-green-500">
              <span className="font-semibold">ឈើ Wood →</span>
              <span>បង្កើតភ្លើង Produces Fire (燃木生火)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-red-500">
              <span className="font-semibold">ភ្លើង Fire →</span>
              <span>បង្កើតដី Produces Earth (火焚成土)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-yellow-500">
              <span className="font-semibold">ដី Earth →</span>
              <span>បង្កើតលោហៈ Produces Metal (土生金)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-gray-500">
              <span className="font-semibold">លោហៈ Metal →</span>
              <span>បង្កើតទឹក Produces Water (金生水)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-blue-500">
              <span className="font-semibold">ទឹក Water →</span>
              <span>បង្កើតឈើ Produces Wood (水生木)</span>
            </div>

          </div>
        </div>

        <div className="space-y-4">
          <h5 className="font-bold text-red-800 text-lg">វដ្តគ្រប់គ្រង Control Cycle (克)</h5>
          <p className="text-sm text-gray-600 mb-3">ធាតុដែលគ្រប់គ្រងនិងដាក់កម្រិតគ្នាទៅវិញទៅមក Elements that control and restrict each other</p>

          
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-green-500">
              <span className="font-semibold">ឈើ Wood →</span>
              <span>គ្រប់គ្រងដី Controls Earth (木克土)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-yellow-500">
              <span className="font-semibold">ដី Earth →</span>
              <span>គ្រប់គ្រងទឹក Controls Water (土克水)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-blue-500">
              <span className="font-semibold">ទឹក Water →</span>
              <span>គ្រប់គ្រងភ្លើង Controls Fire (水克火)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-red-500">
              <span className="font-semibold">ភ្លើង Fire →</span>
              <span>គ្រប់គ្រងលោហៈ Controls Metal (火克金)</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border-l-4 border-gray-500">
              <span className="font-semibold">លោហៈ Metal →</span>
              <span>គ្រប់គ្រងឈើ Controls Wood (金克木)</span>
            </div>

          </div>
        </div>
      </div>
    </Card>
  );
}
