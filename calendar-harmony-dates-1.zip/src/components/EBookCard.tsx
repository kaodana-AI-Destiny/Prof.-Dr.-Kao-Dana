import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, Star, BookOpen, DollarSign } from 'lucide-react';
import { EBook } from '@/data/ebooksData';

interface EBookCardProps {
  ebook: EBook;
  onDownload: (ebook: EBook) => void;
  onViewDetails: (ebook: EBook) => void;
}

export default function EBookCard({ ebook, onDownload, onViewDetails }: EBookCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
      <div className="relative overflow-hidden">
        <img
          src={ebook.coverImage}
          alt={ebook.title}
          className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-white/90">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 mr-1" />
            {ebook.rating}
          </Badge>
        </div>
      </div>
      <CardContent className="p-4">
        <h3 className="font-bold text-lg mb-1 line-clamp-2">{ebook.title}</h3>
        <p className="text-sm text-muted-foreground mb-2">{ebook.titleKhmer}</p>
        <p className="text-sm text-gray-600 mb-2">by {ebook.author}</p>
        <p className="text-sm text-gray-500 line-clamp-2 mb-3">{ebook.description}</p>
        <div className="flex items-center gap-4 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <BookOpen className="w-3 h-3" />
            {ebook.pages} pages
          </span>
          <span className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            {ebook.downloads}
          </span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex items-center justify-between">
        <div className="flex items-center gap-1 text-xl font-bold text-primary">
          <DollarSign className="w-5 h-5" />
          {ebook.price}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => onViewDetails(ebook)}>
            Details
          </Button>
          <Button size="sm" onClick={() => onDownload(ebook)}>
            <Download className="w-4 h-4 mr-1" />
            Buy
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
