import { useState, useMemo } from "react";
import SubscriptionBox from "./SubscriptionBox";
import Hero from "./Hero";
import UserProfile from "./UserProfile";
import DailyZodiac from "./DailyZodiac";
import MonthlyCalendar from "./MonthlyCalendar";
import MonthlyZodiacOverview from "./MonthlyZodiacOverview";
import YearSearch from "./YearSearch";
import Filters from "./Filters";
import YearGrid from "./YearGrid";
import YearModal from "./YearModal";
import Education from "./Education";
import Footer from "./Footer";
import BirthChartForm from "./BirthChartForm";
import BaZiChart from "./BaZiChart";
import TimeZodiacChart from "./TimeZodiacChart";
import FourPillarsTable from "./FourPillarsTable";
import AuxiliaryStarsTable from "./AuxiliaryStarsTable";
import DongKongTable from "./DongKongTable";
import TenGodsTable from "./TenGodsTable";
import { DayMasterStarsReference } from "./DayMasterStarsReference";
import { ExtendedAuxiliaryStarsTable } from "./ExtendedAuxiliaryStarsTable";
import { AuxiliaryStarsResult } from "./AuxiliaryStarsResult";
import { FlyingStarsForm } from "./FlyingStarsForm";
import { FlyingStarsGrid } from "./FlyingStarsGrid";
import { FlyingStarsRecommendations } from "./FlyingStarsRecommendations";
import { Period9FlyingStarsForm } from "./Period9FlyingStarsForm";
import { Period9FlyingStarsGrid } from "./Period9FlyingStarsGrid";
import MonthlyFlyingStarsForm from "./MonthlyFlyingStarsForm";
import MonthlyFlyingStarsGrid from "./MonthlyFlyingStarsGrid";
import MonthlyFlyingStarsRecommendations from "./MonthlyFlyingStarsRecommendations";
import { Period1FlyingStarsForm } from "./Period1FlyingStarsForm";
import { Period1FlyingStarsGrid } from "./Period1FlyingStarsGrid";
import { Period2FlyingStarsForm } from "./Period2FlyingStarsForm";
import { Period2FlyingStarsGrid } from "./Period2FlyingStarsGrid";
import { LuckPillarDisplay } from "./LuckPillarDisplay";
import { AnnualLuckTimeline } from "./AnnualLuckTimeline";
import AuspiciousDatePicker from "./AuspiciousDatePicker";
import FengShuiRecommendations from "./FengShuiRecommendations";
import { generateYearsData, YearData } from "@/utils/calendarCalculator";
import { zodiacAnimals } from "@/data/zodiacData";
import { calculateBaZi, BaZiChart as BaZiChartType } from "@/utils/baziCalculator";
import { generateFengShuiProfile, type FengShuiProfile } from "@/utils/fengShuiCalculator";
import { calculateLuckPillars, type LuckPillar } from "@/utils/luckPillarCalculator";
import { calculateAnnualLuck, type AnnualLuck } from "@/utils/annualLuckCalculator";
import { calculateAuxiliaryStars, type AuxiliaryStar } from "@/utils/auxiliaryStarsCalculator";
import { calculateDongKongDates, type DongKongDate } from "@/utils/dongKongCalculator";
import { calculateFlyingStars, type FlyingStarCell } from "@/utils/flyingStarsCalculator";
import { calculatePeriod9FlyingStars, type Period9FlyingStars, calculatePeriod9StarGrid, type Period9StarData } from "@/utils/period9FlyingStarsCalculator";
import { calculateMonthlyFlyingStars, type MonthlyStarData } from "@/utils/monthlyFlyingStarsCalculator";
import { calculatePeriod1StarGrid, type Period1StarData } from "@/utils/period1FlyingStarsCalculator";
import { calculatePeriod2StarGrid, type Period2StarData } from "@/utils/period2FlyingStarsCalculator";
import { annualStars2025 } from "@/data/flyingStarsData";
export default function AppLayout() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedZodiac, setSelectedZodiac] = useState("All");
  const [selectedElement, setSelectedElement] = useState("All");
  const [selectedYear, setSelectedYear] = useState<YearData | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [baziChart, setBaziChart] = useState<BaZiChartType | null>(null);
  const [luckPillars, setLuckPillars] = useState<{
    pillars: LuckPillar[];
    startingAge: number;
  } | null>(null);
  const [annualLucks, setAnnualLucks] = useState<AnnualLuck[] | null>(null);
  const [birthDate, setBirthDate] = useState<Date | null>(null);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [fengShuiProfile, setFengShuiProfile] = useState<FengShuiProfile | null>(null);
  const [auxiliaryStars, setAuxiliaryStars] = useState<AuxiliaryStar[]>([]);
  const [dongKongDates, setDongKongDates] = useState<DongKongDate[]>([]);

  // State for female results
  const [baziChartFemale, setBaziChartFemale] = useState<BaZiChartType | null>(null);
  const [luckPillarsFemale, setLuckPillarsFemale] = useState<{
    pillars: LuckPillar[];
    startingAge: number;
  } | null>(null);
  const [annualLucksFemale, setAnnualLucksFemale] = useState<AnnualLuck[] | null>(null);
  const [fengShuiProfileFemale, setFengShuiProfileFemale] = useState<FengShuiProfile | null>(null);
  const [auxiliaryStarsFemale, setAuxiliaryStarsFemale] = useState<AuxiliaryStar[]>([]);
  const [dongKongDatesFemale, setDongKongDatesFemale] = useState<DongKongDate[]>([]);
  const [showBothGenders, setShowBothGenders] = useState(false);

  // Flying Stars state
  const [flyingStars, setFlyingStars] = useState<FlyingStarCell[][] | null>(null);
  const [showFlyingStars, setShowFlyingStars] = useState(false);

  // Period 9 Flying Stars state
  const [period9Stars, setPeriod9Stars] = useState<Period9FlyingStars | null>(null);
  const [showPeriod9Stars, setShowPeriod9Stars] = useState(false);

  // Monthly Flying Stars state
  const [monthlyStars, setMonthlyStars] = useState<MonthlyStarData[] | null>(null);
  const [selectedMonthYear, setSelectedMonthYear] = useState<{
    year: number;
    month: number;
  } | null>(null);
  const [showMonthlyStars, setShowMonthlyStars] = useState(false);

  // Period 1 Flying Stars state
  const [period1Stars, setPeriod1Stars] = useState<Period1StarData[] | null>(null);
  const [selectedPeriod1Date, setSelectedPeriod1Date] = useState<{
    year: number;
    month: number;
  } | null>(null);
  const [showPeriod1Stars, setShowPeriod1Stars] = useState(false);

  // Period 2 Flying Stars state
  const [period2Stars, setPeriod2Stars] = useState<Period2StarData[] | null>(null);
  const [selectedPeriod2Date, setSelectedPeriod2Date] = useState<{
    year: number;
    month: number;
  } | null>(null);
  const [showPeriod2Stars, setShowPeriod2Stars] = useState(false);
  const allYears = useMemo(() => generateYearsData(1920, 2112), []);
  const filteredYears = useMemo(() => {
    return allYears.filter(year => {
      const matchesSearch = searchTerm === "" || year.year.toString().includes(searchTerm);
      const zodiac = zodiacAnimals[year.zodiacIndex];
      const matchesZodiac = selectedZodiac === "All" || zodiac.name === selectedZodiac;
      const matchesElement = selectedElement === "All" || year.element === selectedElement;
      return matchesSearch && matchesZodiac && matchesElement;
    });
  }, [allYears, searchTerm, selectedZodiac, selectedElement]);
  const handleYearClick = (yearData: YearData) => {
    setSelectedYear(yearData);
    setIsModalOpen(true);
  };
  const handleBirthChartSubmit = (date: Date, hour: number, selectedGender: 'male' | 'female') => {
    // Clear both genders mode when submitting with specific gender
    setShowBothGenders(false);
    setBaziChartFemale(null);
    setLuckPillarsFemale(null);
    setAnnualLucksFemale(null);
    setFengShuiProfileFemale(null);
    setAuxiliaryStarsFemale([]);
    setDongKongDatesFemale([]);
    const chart = calculateBaZi(date, hour);
    setBaziChart(chart);
    setBirthDate(date);
    setGender(selectedGender);

    // Calculate Auxiliary Stars
    const stars = calculateAuxiliaryStars(chart.year.stem.chinese, chart.year.branch.chinese, chart.month.stem.chinese, chart.month.branch.chinese, chart.day.stem.chinese, chart.day.branch.chinese, chart.hour.stem.chinese, chart.hour.branch.chinese);
    setAuxiliaryStars(stars);

    // Calculate Dong Kong Dates
    const dongKong = calculateDongKongDates(chart.day.stem.chinese, chart.day.branch.chinese);
    setDongKongDates(dongKong);

    // Calculate Luck Pillars
    const luckPillarData = calculateLuckPillars(date, selectedGender, chart);
    setLuckPillars(luckPillarData);

    // Calculate Annual Luck for next 10 years
    const currentYear = new Date().getFullYear();
    const currentAge = currentYear - date.getFullYear();
    const currentLuckPillar = luckPillarData.pillars.find(pillar => currentAge >= pillar.startAge && currentAge < pillar.endAge);
    if (currentLuckPillar) {
      const annualLuckData = calculateAnnualLuck(date.getFullYear(), chart, currentLuckPillar, currentYear, 10);
      setAnnualLucks(annualLuckData);
    }

    // Generate Feng Shui Profile
    const fengShui = generateFengShuiProfile(date.getFullYear(), selectedGender, chart.day.stem.element);
    setFengShuiProfile(fengShui);

    // Scroll to chart
    setTimeout(() => {
      document.getElementById('bazi-chart')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  const handleClearAll = () => {
    setBaziChart(null);
    setLuckPillars(null);
    setAnnualLucks(null);
    setBirthDate(null);
    setGender('male');
    setFengShuiProfile(null);
    setBaziChartFemale(null);
    setLuckPillarsFemale(null);
    setAnnualLucksFemale(null);
    setFengShuiProfileFemale(null);
    setShowBothGenders(false);
  };
  const handleUseTodayBoth = (date: Date, hour: number) => {
    // Generate results for Male
    const chartMale = calculateBaZi(date, hour);
    setBaziChart(chartMale);
    setBirthDate(date);
    setGender('male');

    // Calculate Auxiliary Stars for Male
    const starsMale = calculateAuxiliaryStars(chartMale.year.stem.chinese, chartMale.year.branch.chinese, chartMale.month.stem.chinese, chartMale.month.branch.chinese, chartMale.day.stem.chinese, chartMale.day.branch.chinese, chartMale.hour.stem.chinese, chartMale.hour.branch.chinese);
    setAuxiliaryStars(starsMale);

    // Calculate Dong Kong Dates for Male
    const dongKongMale = calculateDongKongDates(chartMale.day.stem.chinese, chartMale.day.branch.chinese);
    setDongKongDates(dongKongMale);
    const luckPillarDataMale = calculateLuckPillars(date, 'male', chartMale);
    setLuckPillars(luckPillarDataMale);
    const currentYear = new Date().getFullYear();
    const currentAge = currentYear - date.getFullYear();
    const currentLuckPillarMale = luckPillarDataMale.pillars.find(pillar => currentAge >= pillar.startAge && currentAge < pillar.endAge);
    if (currentLuckPillarMale) {
      const annualLuckDataMale = calculateAnnualLuck(date.getFullYear(), chartMale, currentLuckPillarMale, currentYear, 10);
      setAnnualLucks(annualLuckDataMale);
    }
    const fengShuiMale = generateFengShuiProfile(date.getFullYear(), 'male', chartMale.day.stem.element);
    setFengShuiProfile(fengShuiMale);

    // Generate results for Female
    const chartFemale = calculateBaZi(date, hour);
    setBaziChartFemale(chartFemale);

    // Calculate Auxiliary Stars for Female
    const starsFemale = calculateAuxiliaryStars(chartFemale.year.stem.chinese, chartFemale.year.branch.chinese, chartFemale.month.stem.chinese, chartFemale.month.branch.chinese, chartFemale.day.stem.chinese, chartFemale.day.branch.chinese, chartFemale.hour.stem.chinese, chartFemale.hour.branch.chinese);
    setAuxiliaryStarsFemale(starsFemale);

    // Calculate Dong Kong Dates for Female
    const dongKongFemale = calculateDongKongDates(chartFemale.day.stem.chinese, chartFemale.day.branch.chinese);
    setDongKongDatesFemale(dongKongFemale);
    const luckPillarDataFemale = calculateLuckPillars(date, 'female', chartFemale);
    setLuckPillarsFemale(luckPillarDataFemale);
    const currentLuckPillarFemale = luckPillarDataFemale.pillars.find(pillar => currentAge >= pillar.startAge && currentAge < pillar.endAge);
    if (currentLuckPillarFemale) {
      const annualLuckDataFemale = calculateAnnualLuck(date.getFullYear(), chartFemale, currentLuckPillarFemale, currentYear, 10);
      setAnnualLucksFemale(annualLuckDataFemale);
    }
    const fengShuiFemale = generateFengShuiProfile(date.getFullYear(), 'female', chartFemale.day.stem.element);
    setFengShuiProfileFemale(fengShuiFemale);
    setShowBothGenders(true);

    // Scroll to chart
    setTimeout(() => {
      document.getElementById('bazi-chart')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  const handleFlyingStarsCalculate = (year: number, facing: string) => {
    const stars = calculateFlyingStars(year, facing);
    setFlyingStars(stars);
    setShowFlyingStars(true);
    setTimeout(() => {
      document.getElementById('flying-stars-result')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  const handlePeriod9Calculate = (date: Date, hour: number) => {
    const stars = calculatePeriod9FlyingStars(date, hour);
    setPeriod9Stars(stars);
    setShowPeriod9Stars(true);
    setTimeout(() => {
      document.getElementById('period9-stars-result')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  const handleMonthlyStarsCalculate = (year: number, month: number) => {
    const stars = calculateMonthlyFlyingStars(year, month);
    setMonthlyStars(stars);
    setSelectedMonthYear({
      year,
      month
    });
    setShowMonthlyStars(true);
    setTimeout(() => {
      document.getElementById('monthly-stars-result')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  const handlePeriod1Calculate = (date: Date, hour: number) => {
    const stars = calculatePeriod1StarGrid(date.getFullYear(), date.getMonth() + 1);
    setPeriod1Stars(stars);
    setSelectedPeriod1Date({
      year: date.getFullYear(),
      month: date.getMonth() + 1
    });
    setShowPeriod1Stars(true);
    setTimeout(() => {
      document.getElementById('period1-stars-result')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  const handlePeriod2Calculate = (date: Date, hour: number) => {
    const stars = calculatePeriod2StarGrid(date.getFullYear(), date.getMonth() + 1);
    setPeriod2Stars(stars);
    setSelectedPeriod2Date({
      year: date.getFullYear(),
      month: date.getMonth() + 1
    });
    setShowPeriod2Stars(true);
    setTimeout(() => {
      document.getElementById('period2-stars-result')?.scrollIntoView({
        behavior: 'smooth'
      });
    }, 100);
  };
  return <div className="min-h-screen bg-white">

      <Hero />
      
      <SubscriptionBox />
      
      <DailyZodiac />

      
      <TimeZodiacChart />
      
      <MonthlyZodiacOverview />
      
      <MonthlyCalendar onGenerateBazi={handleBirthChartSubmit} />

      {/* BaZi Birth Chart Section */}
      <div className="bg-gradient-to-b from-amber-50 to-orange-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-3xl">បង្កើតតារាងរាសី និងមើលដំណើរជីវិតរបស់អ្នក Generate Your BaZi Birth Chart</h2>
            <p className="text-xl text-gray-600">ស្វែងយល់ពីជោគជតារបស់អ្នកតាមរយៈជូរឈរទាំង បួន Discover your destiny through the Four Pillars of Destiny</p>
          </div>
          
          <BirthChartForm onSubmit={handleBirthChartSubmit} onClear={handleClearAll} onUseTodayBoth={handleUseTodayBoth} />

          
          {showBothGenders ? <div id="bazi-chart" className="mt-12 space-y-12">
              {/* Male Results */}
              <div className="border-4 border-blue-400 rounded-lg p-6 bg-blue-50">
                <h3 className="text-3xl font-bold text-center mb-6 text-blue-700">♂ Male Results</h3>
                {baziChart && <div className="space-y-8">
                    <FourPillarsTable chart={baziChart} />
                    <BaZiChart chart={baziChart} />
                    <TenGodsTable chart={baziChart} />
                    <AuxiliaryStarsResult chart={baziChart} />
                    <AuxiliaryStarsTable stars={auxiliaryStars} />
                    <DongKongTable dates={dongKongDates} />

                    {luckPillars && birthDate && <LuckPillarDisplay pillars={luckPillars.pillars} startingAge={luckPillars.startingAge} currentAge={new Date().getFullYear() - birthDate.getFullYear()} />}
                    {annualLucks && <AnnualLuckTimeline annualLucks={annualLucks} currentYear={new Date().getFullYear()} />}
                    <AuspiciousDatePicker birthChart={baziChart} />
                    {fengShuiProfile && <div className="mt-8">
                        <div className="text-center mb-8">
                          <h3 className="text-3xl font-bold mb-2">🏠 Personalized Feng Shui Guide</h3>
                          <p className="text-gray-600">Harmonize your environment based on your BaZi chart</p>
                        </div>
                        <FengShuiRecommendations profile={fengShuiProfile} />
                      </div>}
                  </div>}
              </div>

              {/* Female Results */}
              <div className="border-4 border-pink-400 rounded-lg p-6 bg-pink-50">
                <h3 className="text-3xl font-bold text-center mb-6 text-pink-700">♀ Female Results</h3>
                {baziChartFemale && <div className="space-y-8">
                    <BaZiChart chart={baziChartFemale} />
                    <TenGodsTable chart={baziChartFemale} />
                    <AuxiliaryStarsResult chart={baziChartFemale} />
                    <AuxiliaryStarsTable stars={auxiliaryStarsFemale} />
                    <DongKongTable dates={dongKongDatesFemale} />

                    {luckPillarsFemale && birthDate && <LuckPillarDisplay pillars={luckPillarsFemale.pillars} startingAge={luckPillarsFemale.startingAge} currentAge={new Date().getFullYear() - birthDate.getFullYear()} />}
                    {annualLucksFemale && <AnnualLuckTimeline annualLucks={annualLucksFemale} currentYear={new Date().getFullYear()} />}
                    <AuspiciousDatePicker birthChart={baziChartFemale} />
                    {fengShuiProfileFemale && <div className="mt-8">
                        <div className="text-center mb-8">
                          <h3 className="text-3xl font-bold mb-2">🏠 Personalized Feng Shui Guide</h3>
                          <p className="text-gray-600">Harmonize your environment based on your BaZi chart</p>
                        </div>
                        <FengShuiRecommendations profile={fengShuiProfileFemale} />
                      </div>}
                  </div>}
              </div>
            </div> : baziChart && <div id="bazi-chart" className="mt-12 space-y-8">
              <FourPillarsTable chart={baziChart} />
              <BaZiChart chart={baziChart} />
              <TenGodsTable chart={baziChart} />
              <AuxiliaryStarsResult chart={baziChart} />
              <AuxiliaryStarsTable stars={auxiliaryStars} />
              <DongKongTable dates={dongKongDates} />
              
              {luckPillars && birthDate && <LuckPillarDisplay pillars={luckPillars.pillars} startingAge={luckPillars.startingAge} currentAge={new Date().getFullYear() - birthDate.getFullYear()} />}
              
              {annualLucks && <AnnualLuckTimeline annualLucks={annualLucks} currentYear={new Date().getFullYear()} />}
              
              <AuspiciousDatePicker birthChart={baziChart} />
              
              {fengShuiProfile && <div className="mt-8">
                  <div className="text-center mb-8">
                    <h3 className="text-3xl font-bold mb-2">🏠 Personalized Feng Shui Guide</h3>
                    <p className="text-gray-600">Harmonize your environment based on your BaZi chart</p>
                  </div>
                  <FengShuiRecommendations profile={fengShuiProfile} />
                </div>}
            </div>}
        </div>
      </div>

      {/* Flying Stars Section */}
      <div className="bg-gradient-to-b from-cyan-50 to-blue-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-2xl">🧭 តារាសាស្ត្រអចិន្ត្រៃយ៍ ស៊នកុងហ្វេស៊ីង Flying Stars (Xuan Kong Fei Xing)</h2>
            <p className="text-xl text-gray-600">Discover the energy patterns of your property based on construction year and facing direction</p>
          </div>
          
          <div className="max-w-md mx-auto mb-8">
            <FlyingStarsForm onCalculate={handleFlyingStarsCalculate} />
          </div>

          {showFlyingStars && flyingStars && <div id="flying-stars-result" className="mt-12">
              <FlyingStarsGrid stars={flyingStars} annualStars={annualStars2025} />
              <FlyingStarsRecommendations stars={flyingStars} />
              <div className="mt-8 text-center text-sm text-gray-600">
                <p className="mb-2">Legend: M = Mountain Star | P = Period Star | W = Water Star</p>
                <p>Period 8 (2004-2023) | Annual Stars for 2025</p>
              </div>
            </div>}
        </div>
      </div>

      {/* Period 9 Flying Stars Section */}
      <div className="bg-gradient-to-b from-indigo-50 to-purple-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-2xl">🔮 ទិសឆុងយុគ 9 Period 9 Flying Stars (2024-2043)</h2>
            <p className="text-xl text-gray-600">Year, Month, Day, and Time Flying Stars with Clash Direction Highlight</p>
          </div>
          
          <div className="max-w-md mx-auto mb-8">
            <Period9FlyingStarsForm onCalculate={handlePeriod9Calculate} />
          </div>

          {showPeriod9Stars && period9Stars && <div id="period9-stars-result" className="mt-12">
              <Period9FlyingStarsGrid stars={period9Stars} />
              <div className="mt-8 text-center text-sm text-gray-600">
                <p className="mb-2">Period 9 (2024-2043) - Fire Element</p>
                <p>Flying Stars calculated for Year, Month, Day, and Time</p>
              </div>
            </div>}
        </div>
      </div>

      {/* Monthly Flying Stars Overlay Section */}
      <div className="bg-gradient-to-b from-rose-50 to-pink-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-red-500 text-2xl">🌙 គណនា តារាសាស្ត្រ យុគ9-ឆ្នាំ-ខែ Period 9 Flying Stars Overlay (2024-2043)</h2>
            <p className="text-xl text-gray-600">Annual + Monthly Stars Combined with Activity Recommendations</p>
          </div>
          
          <div className="max-w-md mx-auto mb-8">
            <MonthlyFlyingStarsForm onCalculate={handleMonthlyStarsCalculate} />
          </div>

          {showMonthlyStars && monthlyStars && selectedMonthYear && <div id="monthly-stars-result" className="mt-12 space-y-8">
              <MonthlyFlyingStarsGrid stars={monthlyStars} year={selectedMonthYear.year} month={selectedMonthYear.month} />
              <MonthlyFlyingStarsRecommendations stars={monthlyStars} />
              <div className="mt-8 text-center text-sm text-gray-600">
                <p className="mb-2">Period 9 (2024-2043) - Monthly Overlay Analysis</p>
                <p>Large number = Annual Star | Small number = Monthly Star</p>
              </div>
            </div>}
        </div>
      </div>

      {/* Period 1 Flying Stars Section (2044-2063) */}
      <div className="bg-gradient-to-b from-green-50 to-teal-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-[#144da9] text-2xl">🌟 គណនា តារាសាស្ត្រ យុគ1-ឆ្នាំ-ខែ Period 1 Flying Stars Overlay (2044-2063)</h2>
            <p className="text-xl text-gray-600">Monthly Flying Stars Overlay for Period 1</p>
          </div>
          
          <div className="max-w-md mx-auto mb-8">
            <Period1FlyingStarsForm onCalculate={handlePeriod1Calculate} />
          </div>

          {showPeriod1Stars && period1Stars && selectedPeriod1Date && <div id="period1-stars-result" className="mt-12">
              <Period1FlyingStarsGrid starGrid={period1Stars} year={selectedPeriod1Date.year} month={selectedPeriod1Date.month} />
            </div>}
        </div>
      </div>

      {/* Period 2 Flying Stars Section (2064-2083) */}
      <div className="bg-gradient-to-b from-orange-50 to-yellow-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-[#a97506] text-2xl">✨ គណនា តារាសាស្ត្រប្រចាំ យុគ2-ឆ្នាំ-ខែ Period 2 Flying Stars Overlay (2064-2083)</h2>
            <p className="text-xl text-gray-600">Monthly Flying Stars Overlay for Period 2</p>
          </div>
          
          <div className="max-w-md mx-auto mb-8">
            <Period2FlyingStarsForm onCalculate={handlePeriod2Calculate} />
          </div>

          {showPeriod2Stars && period2Stars && selectedPeriod2Date && <div id="period2-stars-result" className="mt-12">
              <Period2FlyingStarsGrid starGrid={period2Stars} year={selectedPeriod2Date.year} month={selectedPeriod2Date.month} />
            </div>}
        </div>
      </div>




      {/* Auxiliary Stars Reference Section */}


      {/* Auxiliary Stars Reference Section */}
      <div className="bg-gradient-to-b from-purple-50 to-indigo-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-bold mb-4 text-3xl">📚 មគ្គុទ្ទេសក៍ផ្កាយជំនួយ Auxiliary Stars Reference Guide</h2>
            <p className="text-xl text-gray-600">Complete reference for all ផ្កាយជំនួយ auxiliary stars based on ថ្ងៃតួខ្លួន Day Master</p>


          </div>
          
          <div className="space-y-8">
            <DayMasterStarsReference currentDayMaster={baziChart?.day.stem.chinese} />
            <ExtendedAuxiliaryStarsTable currentDayMaster={baziChart?.day.stem.chinese} />
          </div>
        </div>
      </div>


      <div id="calendar-section" className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="font-bold mb-4 text-4xl">ស្វែងរកធាតុ-សត្វ ក្នុងឆ្នាំ-ខែ-ថ្ងៃកើត និងជ្រើសរើសវេលានៅឆ្នាំអនាគត Explore Years of Wisdom</h2>
          <p className="text-xl text-gray-600">ចាប់ពីឆ្នាំ 1920-2112 (From 1920 to 2112 - Discover your year's zodiac and elements)</p>
        </div>

        <YearSearch searchTerm={searchTerm} onSearchChange={setSearchTerm} />
        
        <Filters selectedZodiac={selectedZodiac} selectedElement={selectedElement} onZodiacChange={setSelectedZodiac} onElementChange={setSelectedElement} />

        <div className="mb-4 text-sm text-gray-600" data-mixed-content="true">Showing {filteredYears.length} of {allYears.length} years</div>



        <YearGrid years={filteredYears} onYearClick={handleYearClick} />
      </div>



      <Education />

      
      <Footer />

      <YearModal yearData={selectedYear} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onGenerateBazi={handleBirthChartSubmit} />

    </div>;
}