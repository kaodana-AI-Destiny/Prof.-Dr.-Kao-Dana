export type SubscriptionPlan = 'daily' | 'weekly' | 'monthly' | 'yearly';

export type SubscriptionStatus = 'active' | 'expired' | 'grace_period' | 'cancelled';

export interface UserSubscription {
  id: string;
  user_id: string;
  user_email: string;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  start_date: string;
  end_date: string;
  grace_period_end?: string;
  auto_renew: boolean;
  payment_method?: string;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionWarning {
  id: string;
  user_id: string;
  subscription_id: string;
  warning_sent_at: string;
  days_remaining: number;
  email_sent: boolean;
}
