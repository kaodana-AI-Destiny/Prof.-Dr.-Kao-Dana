import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type PaymentVerification = {
  id: string;
  user_name: string;
  user_email: string;
  user_phone: string;
  plan_name: string;
  plan_price: string;
  receipt_url: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  verified_at?: string;
  admin_notes?: string;
};

export type UserSubscription = {
  id: string;
  user_id: string;
  user_email: string;
  plan: 'daily' | 'weekly' | 'monthly' | 'yearly';
  status: 'active' | 'expired' | 'grace_period' | 'cancelled';
  start_date: string;
  end_date: string;
  grace_period_end?: string;
  auto_renew: boolean;
  payment_method?: string;
  created_at: string;
  updated_at: string;
};

export type SubscriptionWarning = {
  id: string;
  user_id: string;
  subscription_id: string;
  warning_sent_at: string;
  days_remaining: number;
  email_sent: boolean;
};
