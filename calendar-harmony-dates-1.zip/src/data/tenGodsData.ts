// Ten Gods (十神) System
export const tenGods = {
  friend: { 
    khmer: "មិត្តភក្តិ",
    chinese: "比肩", 
    pinyin: "Bǐ Jiān", 
    english: "Friend" 
  },
  robWealth: { 
    khmer: "ប្លន់ទ្រព្យ",
    chinese: "劫财", 
    pinyin: "Jié Cái", 
    english: "Rob Wealth" 
  },
  eatingGod: { 
    khmer: "ព្រះហូបបាយ",
    chinese: "食神", 
    pinyin: "Shí Shén", 
    english: "Eating God" 
  },
  hurtingOfficer: { 
    khmer: "មន្ត្រីរងរបួស",
    chinese: "伤官", 
    pinyin: "Shāng Guān", 
    english: "Hurting Officer" 
  },
  indirectWealth: { 
    khmer: "ទ្រព្យសម្បត្តិប្រយោល",
    chinese: "偏财", 
    pinyin: "Piān Cái", 
    english: "Indirect Wealth" 
  },
  directWealth: { 
    khmer: "ទ្រព្យសម្បត្តិផ្ទាល់",
    chinese: "正财", 
    pinyin: "Zhèng Cái", 
    english: "Direct Wealth" 
  },
  sevenKillings: { 
    khmer: "ការសម្លាប់ប្រាំពីរ",
    chinese: "七杀", 
    pinyin: "Qī Shā", 
    english: "Seven Killings" 
  },
  directOfficer: { 
    khmer: "មន្ត្រីផ្ទាល់",
    chinese: "正官", 
    pinyin: "Zhèng Guān", 
    english: "Direct Officer" 
  },
  indirectResource: { 
    khmer: "ធនធានប្រយោល",
    chinese: "偏印", 
    pinyin: "Piān Yìn", 
    english: "Indirect Resource" 
  },
  directResource: { 
    khmer: "ធនធានផ្ទាល់",
    chinese: "正印", 
    pinyin: "Zhèng Yìn", 
    english: "Direct Resource" 
  }
};

export const tenGodsInterpretation = {
  friend: {
    khmer: "ឯករាជ្យ ពឹងខ្លួនឯង ប្រកួតប្រជែង។ មានឆន្ទៈ និងការតាំងចិត្តខ្លាំង។",
    english: "Independent, self-reliant, competitive. Strong willpower and determination."
  },
  robWealth: {
    khmer: "មានមហិច្ឆតា ស្វាហាប់ ចាប់ផ្តើមគំនិត។ អាចប្រឈមមុខនឹងការប្រកួតប្រជែងសម្រាប់ធនធាន។",
    english: "Ambitious, assertive, takes initiative. May face competition for resources."
  },
  eatingGod: {
    khmer: "មានភាពច្នៃប្រឌិត បង្ហាញមតិ រីករាយជីវិត។ ពូកែក្នុងការបង្កើតប្រាក់ចំណូល និងគំនិត។",
    english: "Creative, expressive, enjoys life. Good at generating income and ideas."
  },
  hurtingOfficer: {
    khmer: "ឆ្លាតវៃ បះបោរ និយាយត្រង់។ ប្រឈមមុខនឹងអំណាច និងទម្លាប់។",
    english: "Intelligent, rebellious, outspoken. Challenges authority and conventions."
  },
  indirectWealth: {
    khmer: "ជាអ្នកសហគ្រាស ហ៊ានប្រថុយ រួសរាយរាក់ទាក់។ មានប្រភពប្រាក់ចំណូលច្រើន។",
    english: "Entrepreneurial, risk-taking, sociable. Multiple income sources."
  },
  directWealth: {
    khmer: "ប្រាក់ចំណូលស្ថិរភាព ជាក់ស្តែង មានទំនួលខុសត្រូវ។ ពូកែក្នុងការគ្រប់គ្រងហិរញ្ញវត្ថុ។",
    english: "Stable income, practical, responsible. Good at managing finances."
  },
  sevenKillings: {
    khmer: "មានអំណាច ធ្វើការសម្រេចចិត្ត ប្រឈមមុខនឹងបញ្ហាប្រឈម។ សម្ពាធ និងការប្រកួតប្រជែងខ្លាំង។",
    english: "Powerful, decisive, faces challenges. Strong pressure and competition."
  },
  directOfficer: {
    khmer: "មានវិន័យ មានកិត្តិយស គោរពច្បាប់។ ជោគជ័យក្នុងអាជីព និងការទទួលស្គាល់។",
    english: "Disciplined, honorable, respects rules. Career success and recognition."
  },
  indirectResource: {
    khmer: "មានវិចារណញាណ ការរៀនសូត្រមិនធម្មតា។ ខាងវិញ្ញាណ និងទស្សនវិជ្ជា។",
    english: "Intuitive, unconventional learning. Spiritual and philosophical."
  },
  directResource: {
    khmer: "ការអប់រំបែបប្រពៃណី មេត្តា អត់ធ្មត់។ ការគាំទ្រពីមនុស្សចាស់ និងគ្រូបង្រៀន។",
    english: "Traditional education, kind, patient. Support from elders and mentors."
  }
};
