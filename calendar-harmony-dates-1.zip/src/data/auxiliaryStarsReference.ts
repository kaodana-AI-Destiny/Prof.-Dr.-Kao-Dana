// Comprehensive Auxiliary Stars Reference for all 10 Day Masters
export interface DayMasterStars {
  dayMaster: string;
  khmerDayMaster: string;
  chineseName: string;
  element: string;
  khmerElement: string;
  polarity: string;
  khmerPolarity: string;
  noblePerson: string[];
  khmerNoblePerson: string[];
  academicStar: string;
  khmerAcademicStar: string;
  description: string;
  khmerDescription: string;
}

export const auxiliaryStarsReference: DayMasterStars[] = [
  {
    dayMaster: 'Water Yang',
    khmerDayMaster: 'ទឹកយ៉ាំង',
    chineseName: '壬 (Ren)',
    element: 'Water',
    khmerElement: 'ទឹក',
    polarity: 'Yang',
    khmerPolarity: 'យ៉ាំង',
    noblePerson: ['卯 (Rabbit)', '巳 (Snake)'],
    khmerNoblePerson: ['ថោះ', 'ម្សាញ់'],
    academicStar: '寅 (Tiger)',
    khmerAcademicStar: 'ខាល',
    description: 'Dynamic water, like ocean or river. Noble helpers in Rabbit and Snake years/hours.',
    khmerDescription: 'ទឹកស្វាហាប់ ដូចជាមហាសមុទ្រ ឬទន្លេ។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងថោះ និងម្សាញ់។'
  },
  {
    dayMaster: 'Water Yin',
    khmerDayMaster: 'ទឹកយិន',
    chineseName: '癸 (Gui)',
    element: 'Water',
    khmerElement: 'ទឹក',
    polarity: 'Yin',
    khmerPolarity: 'យិន',
    noblePerson: ['卯 (Rabbit)', '巳 (Snake)'],
    khmerNoblePerson: ['ថោះ', 'ម្សាញ់'],
    academicStar: '卯 (Rabbit)',
    khmerAcademicStar: 'ថោះ',
    description: 'Gentle water, like rain or dew. Noble helpers in Rabbit and Snake years/hours.',
    khmerDescription: 'ទឹកទន់ភ្លន់ ដូចជាភ្លៀង ឬសន្សើម។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងថោះ និងម្សាញ់។'
  },
  {
    dayMaster: 'Wood Yang',
    khmerDayMaster: 'ឈើយ៉ាំង',
    chineseName: '甲 (Jia)',
    element: 'Wood',
    khmerElement: 'ឈើ',
    polarity: 'Yang',
    khmerPolarity: 'យ៉ាំង',
    noblePerson: ['丑 (Ox)', '未 (Goat)'],
    khmerNoblePerson: ['ឆ្លូវ', 'មមែ'],
    academicStar: '巳 (Snake)',
    khmerAcademicStar: 'ម្សាញ់',
    description: 'Strong wood, like tall tree. Noble helpers in Ox and Goat years/hours.',
    khmerDescription: 'ឈើរឹងមាំ ដូចជាដើមឈើខ្ពស់។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងឆ្លូវ និងមមែ។'
  },
  {
    dayMaster: 'Wood Yin',
    khmerDayMaster: 'ឈើយិន',
    chineseName: '乙 (Yi)',
    element: 'Wood',
    khmerElement: 'ឈើ',
    polarity: 'Yin',
    khmerPolarity: 'យិន',
    noblePerson: ['申 (Monkey)', '子 (Rat)'],
    khmerNoblePerson: ['វក', 'ជូត'],
    academicStar: '午 (Horse)',
    khmerAcademicStar: 'មមី',
    description: 'Flexible wood, like vine or flower. Noble helpers in Monkey and Rat years/hours.',
    khmerDescription: 'ឈើបត់បែន ដូចជាវល្លិ៍ ឬផ្កា។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងវក និងជូត។'
  },
  {
    dayMaster: 'Fire Yang',
    khmerDayMaster: 'ភ្លើងយ៉ាំង',
    chineseName: '丙 (Bing)',
    element: 'Fire',
    khmerElement: 'ភ្លើង',
    polarity: 'Yang',
    khmerPolarity: 'យ៉ាំង',
    noblePerson: ['酉 (Rooster)', '亥 (Pig)'],
    khmerNoblePerson: ['រកា', 'កុរ'],
    academicStar: '申 (Monkey)',
    khmerAcademicStar: 'វក',
    description: 'Bright fire, like sun. Noble helpers in Rooster and Pig years/hours.',
    khmerDescription: 'ភ្លើងភ្លឺ ដូចជាព្រះអាទិត្យ។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងរកា និងកុរ។'
  },
  {
    dayMaster: 'Fire Yin',
    khmerDayMaster: 'ភ្លើងយិន',
    chineseName: '丁 (Ding)',
    element: 'Fire',
    khmerElement: 'ភ្លើង',
    polarity: 'Yin',
    khmerPolarity: 'យិន',
    noblePerson: ['酉 (Rooster)', '亥 (Pig)'],
    khmerNoblePerson: ['រកា', 'កុរ'],
    academicStar: '酉 (Rooster)',
    khmerAcademicStar: 'រកា',
    description: 'Gentle fire, like candle. Noble helpers in Rooster and Pig years/hours.',
    khmerDescription: 'ភ្លើងទន់ភ្លន់ ដូចជាទៀន។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងរកា និងកុរ។'
  },
  {
    dayMaster: 'Earth Yang',
    khmerDayMaster: 'ដីយ៉ាំង',
    chineseName: '戊 (Wu)',
    element: 'Earth',
    khmerElement: 'ដី',
    polarity: 'Yang',
    khmerPolarity: 'យ៉ាំង',
    noblePerson: ['丑 (Ox)', '未 (Goat)'],
    khmerNoblePerson: ['ឆ្លូវ', 'មមែ'],
    academicStar: '申 (Monkey)',
    khmerAcademicStar: 'វក',
    description: 'Solid earth, like mountain. Noble helpers in Ox and Goat years/hours.',
    khmerDescription: 'ដីរឹង ដូចជាភ្នំ។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងឆ្លូវ និងមមែ។'
  },
  {
    dayMaster: 'Earth Yin',
    khmerDayMaster: 'ដីយិន',
    chineseName: '己 (Ji)',
    element: 'Earth',
    khmerElement: 'ដី',
    polarity: 'Yin',
    khmerPolarity: 'យិន',
    noblePerson: ['申 (Monkey)', '子 (Rat)'],
    khmerNoblePerson: ['វក', 'ជូត'],
    academicStar: '酉 (Rooster)',
    khmerAcademicStar: 'រកា',
    description: 'Soft earth, like soil. Noble helpers in Monkey and Rat years/hours.',
    khmerDescription: 'ដីទន់ ដូចជាដីស្រែ។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងវក និងជូត។'
  },
  {
    dayMaster: 'Metal Yang',
    khmerDayMaster: 'ដែកយ៉ាំង',
    chineseName: '庚 (Geng)',
    element: 'Metal',
    khmerElement: 'ដែក',
    polarity: 'Yang',
    khmerPolarity: 'យ៉ាំង',
    noblePerson: ['丑 (Ox)', '未 (Goat)'],
    khmerNoblePerson: ['ឆ្លូវ', 'មមែ'],
    academicStar: '亥 (Pig)',
    khmerAcademicStar: 'កុរ',
    description: 'Hard metal, like sword. Noble helpers in Ox and Goat years/hours.',
    khmerDescription: 'ដែករឹង ដូចជាដាវ។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងឆ្លូវ និងមមែ។'
  },
  {
    dayMaster: 'Metal Yin',
    khmerDayMaster: 'ដែកយិន',
    chineseName: '辛 (Xin)',
    element: 'Metal',
    khmerElement: 'ដែក',
    polarity: 'Yin',
    khmerPolarity: 'យិន',
    noblePerson: ['寅 (Tiger)', '午 (Horse)'],
    khmerNoblePerson: ['ខាល', 'មមី'],
    academicStar: '子 (Rat)',
    khmerAcademicStar: 'ជូត',
    description: 'Refined metal, like jewelry. Noble helpers in Tiger and Horse years/hours.',
    khmerDescription: 'ដែកស្អាត ដូចជាគ្រឿងអលង្ការ។ អ្នកជួយជ្រោមជ្រែងក្នុងឆ្នាំ/ម៉ោងខាល និងមមី។'
  }
];
