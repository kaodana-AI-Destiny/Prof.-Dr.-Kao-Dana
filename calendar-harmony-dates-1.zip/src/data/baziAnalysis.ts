export const elementPersonality = {
  Wood: {
    strong: "ច្នៃប្រឌិត ទន់ភ្លន់ ផ្តោតលើការរីកចម្រើន Creative, flexible, growth-oriented. ជាអ្នកដឹកនាំធម្មជាតិដែលមានចក្ខុវិស័យនិងក្តីមេត្តា Natural leader with vision and compassion.",
    weak: "អាចខ្វះទិសដៅឬទំនុកចិត្ត May lack direction or confidence. ត្រូវការអភិវឌ្ឍភាពអះអាងនិងស្ថិរភាព Need to develop assertiveness and stability.",
    career: "សិល្បៈ ការអប់រំ សុខាភិបាល ការងារបរិស្ថាន សហគ្រិនភាព Arts, education, healthcare, environmental work, entrepreneurship"
  },
  Fire: {
    strong: "ក្លៀវក្លា ទាក់ទាញ ស្វាហាប់ Passionate, charismatic, energetic. អ្នកទំនាក់ទំនងធម្មជាតិដែលមានវត្តមានខ្លាំង Natural communicator with strong presence.",
    weak: "អាចខ្វះភាពកក់ក្តៅឬភាពរីករាយ May lack warmth or enthusiasm. ត្រូវការអភិវឌ្ឍក្តីក្លៀវក្លានិងទំនាក់ទំនងសង្គម Need to develop passion and social connections.",
    career: "ការកម្សាន្ត ការលក់ ទីផ្សារ ការនិយាយជាសាធារណៈ តួនាទីដឹកនាំ Entertainment, sales, marketing, public speaking, leadership roles"
  },
  Earth: {
    strong: "ស្ថិរភាព អាចទុកចិត្តបាន ជាក់ស្តែង Stable, reliable, practical. អ្នករៀបចំធម្មជាតិដែលមានក្រមការងារខ្លាំង Natural organizer with strong work ethic.",
    weak: "អាចខ្វះមូលដ្ឋានឬស្ថិរភាព May lack grounding or stability. ត្រូវការអភិវឌ្ឍភាពអត់ធ្មត់និងភាពស៊ីសង្វាក់គ្នា Need to develop patience and consistency.",
    career: "អចលនទ្រព្យ កសិកម្ម សំណង់ ការគ្រប់គ្រង ហិរញ្ញវត្ថុ Real estate, agriculture, construction, management, finance"
  },
  Metal: {
    strong: "មានការតាំងចិត្ត មានវិន័យ មានរចនាសម្ព័ន្ធ Determined, disciplined, structured. អ្នកយុទ្ធសាស្ត្រធម្មជាតិដែលមានស្តង់ដារខ្ពស់ Natural strategist with high standards.",
    weak: "អាចខ្វះរចនាសម្ព័ន្ធឬវិន័យ May lack structure or discipline. ត្រូវការអភិវឌ្ឍការផ្តោតអារម្មណ៍និងការតាំងចិត្ត Need to develop focus and determination.",
    career: "ច្បាប់ យោធា វិស្វកម្ម បច្ចេកវិទ្យា ហិរញ្ញវត្ថុ ការវះកាត់ Law, military, engineering, technology, finance, surgery"
  },
  Water: {
    strong: "ប្រាជ្ញា ទន់ភ្លន់ វិចារណញាណ Wise, adaptable, intuitive. ទស្សនវិទូធម្មជាតិដែលមានការយល់ដឹងជ្រៅ Natural philosopher with deep insight.",
    weak: "អាចខ្វះប្រាជ្ញាឬភាពទន់ភ្លន់ May lack wisdom or adaptability. ត្រូវការអភិវឌ្ឍភាពបត់បែននិងវិចារណញាណ Need to develop flexibility and intuition.",
    career: "ការស្រាវជ្រាវ ចិត្តវិទ្យា ខាងវិញ្ញាណ ការសរសេរ ការប្រឹក្សា Research, psychology, spirituality, writing, consulting"
  }
};

export const lifePredictions = {
  balanced: "ធាតុរបស់អ្នកមានតុល្យភាពល្អ បង្ហាញពីភាពសុខដុមនៅក្នុងជីវិត Your elements are well-balanced, indicating harmony in life. អ្នកមានភាពបត់បែនដើម្បីទទួលបានជោគជ័យក្នុងវិស័យផ្សេងៗ You have the flexibility to succeed in various fields.",
  woodDominant: "ថាមពលឈើខ្លាំងនាំមកនូវការរីកចម្រើននិងការច្នៃប្រឌិត Strong Wood energy brings growth and creativity. ផ្តោតលើការចិញ្ចឹមទំនាក់ទំនងនិងជៀសវាងភាពរឹងរូស Focus on nurturing relationships and avoiding rigidity.",
  fireDominant: "ថាមពលភ្លើងខ្លាំងនាំមកនូវក្តីក្លៀវក្លានិងការទទួលស្គាល់ Strong Fire energy brings passion and recognition. តុល្យភាពជាមួយការសម្រាកដើម្បីជៀសវាងការហត់នឿយ Balance with rest to avoid burnout.",
  earthDominant: "ថាមពលដីខ្លាំងនាំមកនូវស្ថិរភាពនិងទ្រព្យសម្បត្តិ Strong Earth energy brings stability and wealth. ជៀសវាងការក្លាយជាអ្នករក្សាទុកខ្លាំងពេកឬជាប់គាំង Avoid becoming too conservative or stuck.",
  metalDominant: "ថាមពលលោហៈខ្លាំងនាំមកនូវរចនាសម្ព័ន្ធនិងជោគជ័យ Strong Metal energy brings structure and success. តុល្យភាពជាមួយភាពបត់បែននិងក្តីមេត្តា Balance with flexibility and compassion.",
  waterDominant: "ថាមពលទឹកខ្លាំងនាំមកនូវប្រាជ្ញានិងភាពទន់ភ្លន់ Strong Water energy brings wisdom and adaptability. ធ្វើឱ្យខ្លួនអ្នកមានមូលដ្ឋានដើម្បីជៀសវាងការរសាត Ground yourself to avoid drifting."
};
