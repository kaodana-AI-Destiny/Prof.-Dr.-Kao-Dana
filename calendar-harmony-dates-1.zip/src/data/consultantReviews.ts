export interface Review {
  id: string;
  consultantId: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  sessionType: string;
}

export const reviews: Review[] = [
  {
    id: 'r1',
    consultantId: '1',
    userName: 'Sarah Johnson',
    rating: 5,
    date: '2025-10-01',
    comment: 'Master Li Wei provided incredible insights into my BaZi chart. His advice has been transformative for my career decisions.',
    sessionType: 'BaZi Analysis'
  },
  {
    id: 'r2',
    consultantId: '1',
    userName: 'David Chen',
    rating: 5,
    date: '2025-09-28',
    comment: 'Excellent Feng Shui consultation for my new office. Business has improved significantly since implementing his recommendations.',
    sessionType: 'Feng Shui Consultation'
  },
  {
    id: 'r3',
    consultantId: '2',
    userName: 'Emily Wong',
    rating: 5,
    date: '2025-10-05',
    comment: 'Master Chen Mei transformed my home energy completely. Very professional and knowledgeable.',
    sessionType: 'Residential Feng Shui'
  },
  {
    id: 'r4',
    consultantId: '3',
    userName: 'Michael Lee',
    rating: 5,
    date: '2025-09-30',
    comment: 'Amazing BaZi reading! Master Zhang Hong was spot-on about my personality and life path.',
    sessionType: 'BaZi Analysis'
  }
];
