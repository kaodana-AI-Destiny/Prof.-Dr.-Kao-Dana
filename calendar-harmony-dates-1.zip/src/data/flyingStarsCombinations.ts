export const starMeanings: Record<number, { name: string; element: string; nature: string }> = {
  1: { name: "White", element: "Water", nature: "Auspicious - Career, Wisdom" },
  2: { name: "Black", element: "Earth", nature: "Inauspicious - Illness" },
  3: { name: "Jade", element: "Wood", nature: "Inauspicious - Quarrels, Legal" },
  4: { name: "Green", element: "Wood", nature: "Auspicious - Romance, Academics" },
  5: { name: "Yellow", element: "Earth", nature: "Most Inauspicious - Misfortune" },
  6: { name: "White", element: "Metal", nature: "Auspicious - Authority, Wealth" },
  7: { name: "Red", element: "Metal", nature: "Inauspicious - Violence, Theft" },
  8: { name: "White", element: "Earth", nature: "Most Auspicious - Wealth, Prosperity" },
  9: { name: "Purple", element: "Fire", nature: "Auspicious - Future Prosperity" }
};

export const combinations: Record<string, { interpretation: string; remedy: string; rating: "excellent" | "good" | "neutral" | "poor" | "dangerous" }> = {
  "1-4": { interpretation: "Romance & Academic Success", remedy: "Place plants or water feature", rating: "excellent" },
  "1-6": { interpretation: "Career Advancement & Authority", remedy: "Metal wind chimes", rating: "excellent" },
  "2-5": { interpretation: "Severe Illness & Misfortune", remedy: "6-rod metal wind chime, salt water cure", rating: "dangerous" },
  "2-3": { interpretation: "Disputes & Health Issues", remedy: "Red items, fire element", rating: "poor" },
  "6-8": { interpretation: "Wealth & Success", remedy: "Enhance with crystals", rating: "excellent" },
  "7-9": { interpretation: "Fire at Heaven's Gate - Danger", remedy: "Earth elements, avoid red", rating: "dangerous" },
  "8-9": { interpretation: "Future Wealth Multiplied", remedy: "Red items to enhance", rating: "excellent" },
  "3-5": { interpretation: "Legal Issues & Disasters", remedy: "Red paper, fire colors", rating: "dangerous" },
  "4-1": { interpretation: "Wisdom & Romance Combined", remedy: "Water features", rating: "excellent" }
};
