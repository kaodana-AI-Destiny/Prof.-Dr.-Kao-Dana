// Extended Auxiliary Stars Reference based on Earthly Branches and Day Masters
export interface ExtendedAuxiliaryStars {
  dayMaster: string;
  chineseName: string;
  element: string;
  polarity: string;
  peachBlossom: string;
  travellingHorse: string;
  artistStar: string;
  deathStar: string;
  lonesomeStar: string;
  robberyStar: string;
  swordStar: string;
  description: string;
}

export const extendedAuxiliaryStars: ExtendedAuxiliaryStars[] = [
  {
    dayMaster: 'Water Yang',
    chineseName: '壬 (Ren)',
    element: 'Water',
    polarity: 'Yang',
    peachBlossom: '酉 (Rooster)',
    travellingHorse: '寅 (Tiger)',
    artistStar: '午 (Horse)',
    deathStar: '巳 (Snake)',
    lonesomeStar: '亥 (Pig)',
    robberyStar: '申 (Monkey)',
    swordStar: '卯 (Rabbit)',
    description: 'Dynamic water element with strong creative and travel potential.'
  },
  {
    dayMaster: 'Water Yin',
    chineseName: '癸 (Gui)',
    element: 'Water',
    polarity: 'Yin',
    peachBlossom: '酉 (Rooster)',
    travellingHorse: '寅 (Tiger)',
    artistStar: '巳 (Snake)',
    deathStar: '午 (Horse)',
    lonesomeStar: '戌 (Dog)',
    robberyStar: '申 (Monkey)',
    swordStar: '辰 (Dragon)',
    description: 'Gentle water with artistic sensitivity and intuitive nature.'
  },
  {
    dayMaster: 'Wood Yang',
    chineseName: '甲 (Jia)',
    element: 'Wood',
    polarity: 'Yang',
    peachBlossom: '午 (Horse)',
    travellingHorse: '申 (Monkey)',
    artistStar: '子 (Rat)',
    deathStar: '未 (Goat)',
    lonesomeStar: '寅 (Tiger)',
    robberyStar: '亥 (Pig)',
    swordStar: '卯 (Rabbit)',
    description: 'Strong wood with leadership and pioneering spirit.'
  },
  {
    dayMaster: 'Wood Yin',
    chineseName: '乙 (Yi)',
    element: 'Wood',
    polarity: 'Yin',
    peachBlossom: '午 (Horse)',
    travellingHorse: '申 (Monkey)',
    artistStar: '亥 (Pig)',
    deathStar: '申 (Monkey)',
    lonesomeStar: '丑 (Ox)',
    robberyStar: '亥 (Pig)',
    swordStar: '辰 (Dragon)',
    description: 'Flexible wood with adaptability and artistic expression.'
  },
  {
    dayMaster: 'Fire Yang',
    chineseName: '丙 (Bing)',
    element: 'Fire',
    polarity: 'Yang',
    peachBlossom: '卯 (Rabbit)',
    travellingHorse: '亥 (Pig)',
    artistStar: '寅 (Tiger)',
    deathStar: '酉 (Rooster)',
    lonesomeStar: '巳 (Snake)',
    robberyStar: '寅 (Tiger)',
    swordStar: '午 (Horse)',
    description: 'Bright fire with charisma and strong presence.'
  },
  {
    dayMaster: 'Fire Yin',
    chineseName: '丁 (Ding)',
    element: 'Fire',
    polarity: 'Yin',
    peachBlossom: '卯 (Rabbit)',
    travellingHorse: '亥 (Pig)',
    artistStar: '丑 (Ox)',
    deathStar: '戌 (Dog)',
    lonesomeStar: '辰 (Dragon)',
    robberyStar: '寅 (Tiger)',
    swordStar: '未 (Goat)',
    description: 'Gentle fire with refinement and cultural appreciation.'
  },
  {
    dayMaster: 'Earth Yang',
    chineseName: '戊 (Wu)',
    element: 'Earth',
    polarity: 'Yang',
    peachBlossom: '卯 (Rabbit)',
    travellingHorse: '亥 (Pig)',
    artistStar: '寅 (Tiger)',
    deathStar: '酉 (Rooster)',
    lonesomeStar: '巳 (Snake)',
    robberyStar: '寅 (Tiger)',
    swordStar: '午 (Horse)',
    description: 'Solid earth with stability and nurturing qualities.'
  },
  {
    dayMaster: 'Earth Yin',
    chineseName: '己 (Ji)',
    element: 'Earth',
    polarity: 'Yin',
    peachBlossom: '午 (Horse)',
    travellingHorse: '申 (Monkey)',
    artistStar: '亥 (Pig)',
    deathStar: '申 (Monkey)',
    lonesomeStar: '丑 (Ox)',
    robberyStar: '亥 (Pig)',
    swordStar: '未 (Goat)',
    description: 'Soft earth with patience and practical wisdom.'
  },
  {
    dayMaster: 'Metal Yang',
    chineseName: '庚 (Geng)',
    element: 'Metal',
    polarity: 'Yang',
    peachBlossom: '子 (Rat)',
    travellingHorse: '巳 (Snake)',
    artistStar: '辰 (Dragon)',
    deathStar: '亥 (Pig)',
    lonesomeStar: '申 (Monkey)',
    robberyStar: '巳 (Snake)',
    swordStar: '酉 (Rooster)',
    description: 'Hard metal with determination and strong will.'
  },
  {
    dayMaster: 'Metal Yin',
    chineseName: '辛 (Xin)',
    element: 'Metal',
    polarity: 'Yin',
    peachBlossom: '子 (Rat)',
    travellingHorse: '巳 (Snake)',
    artistStar: '卯 (Rabbit)',
    deathStar: '子 (Rat)',
    lonesomeStar: '未 (Goat)',
    robberyStar: '巳 (Snake)',
    swordStar: '戌 (Dog)',
    description: 'Refined metal with precision and attention to detail.'
  }
];
