export const zodiacImages: Record<string, string> = {
  Rat: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134610557_e5fbdf7f.webp',
  Ox: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134611634_7b57d68f.webp',
  Tiger: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134612549_3825381b.webp',
  Rabbit: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134613635_8b5613bc.webp',
  Dragon: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134614421_4965a451.webp',
  Snake: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134615178_0e4b2618.webp',
  Horse: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134624388_0fc329bf.webp',
  Goat: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134625658_e7151dcc.webp',
  Monkey: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134627701_83cbf3ba.webp',
  Rooster: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134628717_a9c6211d.webp',
  Dog: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134630359_53717aeb.webp',
  Pig: 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134631270_1a08b42f.webp'
};

export const heroImage = 'https://d64gsuwffb70l.cloudfront.net/68e9859dd38fd7627d1c5b39_1760134608845_fb85d406.webp';
