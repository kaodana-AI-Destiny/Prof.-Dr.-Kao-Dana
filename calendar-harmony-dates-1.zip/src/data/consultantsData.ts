export interface Consultant {
  id: string;
  name: string;
  chineseName: string;
  specialty: 'Feng Shui' | 'BaZi' | 'Both';
  experience: number;
  rating: number;
  reviewCount: number;
  hourlyRate: number;
  image: string;
  languages: string[];
  bio: string;
  availability: string[];
}

export const consultants: Consultant[] = [
  {
    id: '1',
    name: 'Master Li Wei',
    chineseName: '李偉大師',
    specialty: 'Both',
    experience: 25,
    rating: 4.9,
    reviewCount: 342,
    hourlyRate: 150,
    image: 'https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760353869200_f7950973.webp',
    languages: ['English', 'Chinese', 'Khmer'],
    bio: 'Renowned master with 25 years of experience in BaZi analysis and Feng Shui consultation. Specializes in business and residential Feng Shui.',
    availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
  },
  {
    id: '2',
    name: 'Master Chen Mei',
    chineseName: '陳美大師',
    specialty: 'Feng Shui',
    experience: 18,
    rating: 4.8,
    reviewCount: 256,
    hourlyRate: 120,
    image: 'https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760353864613_514a3514.webp',
    languages: ['English', 'Chinese'],
    bio: 'Expert in residential and commercial Feng Shui. Known for transforming spaces to enhance prosperity and harmony.',
    availability: ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  },
  {
    id: '3',
    name: 'Master Zhang Hong',
    chineseName: '張紅大師',
    specialty: 'BaZi',
    experience: 20,
    rating: 4.9,
    reviewCount: 298,
    hourlyRate: 130,
    image: 'https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760353871899_2b9d8072.webp',
    languages: ['English', 'Chinese', 'Khmer'],
    bio: 'BaZi specialist focusing on career guidance, relationship compatibility, and life path analysis.',
    availability: ['Monday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  },
  {
    id: '4',
    name: 'Master Wang Ling',
    chineseName: '王玲大師',
    specialty: 'Feng Shui',
    experience: 15,
    rating: 4.7,
    reviewCount: 189,
    hourlyRate: 100,
    image: 'https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760353866354_d2aa07c7.webp',
    languages: ['English', 'Chinese'],
    bio: 'Specializes in modern Feng Shui applications for contemporary homes and offices.',
    availability: ['Monday', 'Tuesday', 'Thursday', 'Friday', 'Saturday']
  },
  {
    id: '5',
    name: 'Master Liu Jun',
    chineseName: '劉俊大師',
    specialty: 'Both',
    experience: 22,
    rating: 4.8,
    reviewCount: 312,
    hourlyRate: 140,
    image: 'https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760353873665_7861bc4e.webp',
    languages: ['English', 'Chinese', 'Khmer'],
    bio: 'Comprehensive consultant offering integrated BaZi and Feng Shui solutions for holistic life improvement.',
    availability: ['Monday', 'Tuesday', 'Wednesday', 'Friday', 'Saturday']
  },
  {
    id: '6',
    name: 'Master Yang Xiu',
    chineseName: '楊秀大師',
    specialty: 'BaZi',
    experience: 16,
    rating: 4.8,
    reviewCount: 223,
    hourlyRate: 110,
    image: 'https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760353868167_f1d20019.webp',
    languages: ['English', 'Chinese'],
    bio: 'Expert in destiny analysis and timing selection for important life events.',
    availability: ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  }
];
