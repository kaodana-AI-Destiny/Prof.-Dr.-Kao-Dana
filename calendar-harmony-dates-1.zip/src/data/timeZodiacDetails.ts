export interface TimeZodiacDetail {
  branch: string;
  animal: string;
  timeRange: string;
  element: string;
  polarity: string;
  luckyActivities: string[];
  compatibleElements: string[];
  tcmAssociations: {
    organ: string;
    meridian: string;
    health: string;
  };
  energyType: string;
}

export const timeZodiacDetails: TimeZodiacDetail[] = [
  {
    branch: "子 (Zi)",
    animal: "Rat",
    timeRange: "11 PM - 1 AM",
    element: "Water",
    polarity: "Yang",
    luckyActivities: ["Meditation", "Rest", "Deep sleep", "Spiritual practices"],
    compatibleElements: ["Metal", "Water"],
    tcmAssociations: {
      organ: "Gallbladder",
      meridian: "Gallbladder Meridian",
      health: "Decision making, courage, detoxification"
    },
    energyType: "Peak Yin - transition to Yang"
  },
  {
    branch: "丑 (Chou)",
    animal: "Ox",
    timeRange: "1 AM - 3 AM",
    element: "Earth",
    polarity: "Yin",
    luckyActivities: ["Deep sleep", "Liver detox", "Dream work"],
    compatibleElements: ["Fire", "Earth"],
    tcmAssociations: {
      organ: "Liver",
      meridian: "Liver Meridian",
      health: "Blood purification, emotional processing"
    },
    energyType: "Deep Yin energy"
  },
  {
    branch: "寅 (Yin)",
    animal: "Tiger",
    timeRange: "3 AM - 5 AM",
    element: "Wood",
    polarity: "Yang",
    luckyActivities: ["Early meditation", "Breathing exercises", "Waking up"],
    compatibleElements: ["Water", "Wood"],
    tcmAssociations: {
      organ: "Lungs",
      meridian: "Lung Meridian",
      health: "Oxygen distribution, immune system"
    },
    energyType: "Rising Yang energy"
  },
  {
    branch: "卯 (Mao)",
    animal: "Rabbit",
    timeRange: "5 AM - 7 AM",
    element: "Wood",
    polarity: "Yin",
    luckyActivities: ["Morning exercise", "Bowel movement", "Light breakfast"],
    compatibleElements: ["Water", "Wood"],
    tcmAssociations: {
      organ: "Large Intestine",
      meridian: "Large Intestine Meridian",
      health: "Elimination, releasing what's not needed"
    },
    energyType: "Morning vitality"
  },
  {
    branch: "辰 (Chen)",
    animal: "Dragon",
    timeRange: "7 AM - 9 AM",
    element: "Earth",
    polarity: "Yang",
    luckyActivities: ["Eating breakfast", "Planning", "Important meetings"],
    compatibleElements: ["Fire", "Earth"],
    tcmAssociations: {
      organ: "Stomach",
      meridian: "Stomach Meridian",
      health: "Digestion, nourishment, energy absorption"
    },
    energyType: "Peak morning energy"
  },
  {
    branch: "巳 (Si)",
    animal: "Snake",
    timeRange: "9 AM - 11 AM",
    element: "Fire",
    polarity: "Yin",
    luckyActivities: ["Work", "Study", "Mental tasks", "Creative work"],
    compatibleElements: ["Wood", "Fire"],
    tcmAssociations: {
      organ: "Spleen",
      meridian: "Spleen Meridian",
      health: "Energy transformation, blood sugar regulation"
    },
    energyType: "Active Yang energy"
  },
  {
    branch: "午 (Wu)",
    animal: "Horse",
    timeRange: "11 AM - 1 PM",
    element: "Fire",
    polarity: "Yang",
    luckyActivities: ["Lunch", "Socializing", "Peak performance tasks"],
    compatibleElements: ["Wood", "Fire"],
    tcmAssociations: {
      organ: "Heart",
      meridian: "Heart Meridian",
      health: "Circulation, joy, mental clarity"
    },
    energyType: "Peak Yang - highest energy"
  },
  {
    branch: "未 (Wei)",
    animal: "Goat",
    timeRange: "1 PM - 3 PM",
    element: "Earth",
    polarity: "Yin",
    luckyActivities: ["Light work", "Digestion", "Short rest"],
    compatibleElements: ["Fire", "Earth"],
    tcmAssociations: {
      organ: "Small Intestine",
      meridian: "Small Intestine Meridian",
      health: "Nutrient absorption, sorting pure from impure"
    },
    energyType: "Declining Yang"
  },
  {
    branch: "申 (Shen)",
    animal: "Monkey",
    timeRange: "3 PM - 5 PM",
    element: "Metal",
    polarity: "Yang",
    luckyActivities: ["Hydration", "Study", "Afternoon tasks"],
    compatibleElements: ["Earth", "Metal"],
    tcmAssociations: {
      organ: "Bladder",
      meridian: "Bladder Meridian",
      health: "Fluid regulation, toxin removal"
    },
    energyType: "Afternoon vitality"
  },
  {
    branch: "酉 (You)",
    animal: "Rooster",
    timeRange: "5 PM - 7 PM",
    element: "Metal",
    polarity: "Yin",
    luckyActivities: ["Dinner", "Family time", "Relaxation"],
    compatibleElements: ["Earth", "Metal"],
    tcmAssociations: {
      organ: "Kidneys",
      meridian: "Kidney Meridian",
      health: "Vital essence, bone health, willpower"
    },
    energyType: "Transition to Yin"
  },
  {
    branch: "戌 (Xu)",
    animal: "Dog",
    timeRange: "7 PM - 9 PM",
    element: "Earth",
    polarity: "Yang",
    luckyActivities: ["Light activities", "Reading", "Preparing for rest"],
    compatibleElements: ["Fire", "Earth"],
    tcmAssociations: {
      organ: "Pericardium",
      meridian: "Pericardium Meridian",
      health: "Heart protection, circulation, relationships"
    },
    energyType: "Evening calm"
  },
  {
    branch: "亥 (Hai)",
    animal: "Pig",
    timeRange: "9 PM - 11 PM",
    element: "Water",
    polarity: "Yin",
    luckyActivities: ["Sleep preparation", "Gentle activities", "Reflection"],
    compatibleElements: ["Metal", "Water"],
    tcmAssociations: {
      organ: "Triple Burner",
      meridian: "Triple Burner Meridian",
      health: "Temperature regulation, overall energy flow"
    },
    energyType: "Deep Yin preparation"
  }
];
