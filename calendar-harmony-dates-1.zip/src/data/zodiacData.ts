export interface ZodiacAnimal {
  id: number;
  name: string;
  khmerName: string;
  image: string;
  element: string;
  khmerElement: string;
  polarity: string;
  khmerPolarity: string;
  traits: string[];
  khmerTraits: string[];
  luckyColors: string[];
  khmerLuckyColors: string[];
  luckyNumbers: number[];
}

export const zodiacAnimals: ZodiacAnimal[] = [
  {
    id: 0,
    name: "Monkey",
    khmerName: "វក ឆុង ខាល (50% ម្សាញ់ កុរ ឆ្លូវ និងថោះ)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760167788413_5c2062d4.webp",
    element: "Metal",
    khmerElement: "ដែក",
    polarity: "Yang",
    khmerPolarity: "យ៉ាំង",
    traits: ["Sharp", "Smart", "Curious", "Mischievous"],
    khmerTraits: ["ស្រួច", "ឆ្លាតវៃ", "ចង់ដឹង", "រវល់"],
    luckyColors: ["White", "Blue", "Gold"],
    khmerLuckyColors: ["ស", "ខៀវ", "មាស"],
    luckyNumbers: [4, 9]
  },
  {
    id: 1,
    name: "Rooster",
    khmerName: "រកា ឆុង ថោះ (50% មមី ជូត រោង និងខាល)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147355334_46cffd60.webp",
    element: "Metal",
    khmerElement: "ដែក",
    polarity: "Yin",
    khmerPolarity: "យិន",
    traits: ["Observant", "Hardworking", "Courageous", "Talented"],
    khmerTraits: ["ចាប់អារម្មណ៍", "ឧស្សាហ៍", "ក្លាហាន", "មានទេពកោសល្យ"],
    luckyColors: ["Gold", "Brown", "Yellow"],
    khmerLuckyColors: ["មាស", "ត្នោត", "លឿង"],
    luckyNumbers: [5, 7, 8]
  },
  {
    id: 2,
    name: "Dog",
    khmerName: "ច ឆុង រោង (50% មមែ ឆ្លូវ ម្សាញ់ និងថោះ)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147356097_7a10a160.webp",
    element: "Earth",
    khmerElement: "ដី",
    polarity: "Yang",
    khmerPolarity: "យ៉ាំង",
    traits: ["Loyal", "Honest", "Friendly", "Faithful"],
    khmerTraits: ["ស្មោះត្រង់", "ត្រង់", "រួសរាយ", "ជឿជាក់"],
    luckyColors: ["Red", "Green", "Purple"],
    khmerLuckyColors: ["ក្រហម", "បៃតង", "ស្វាយ"],
    luckyNumbers: [3, 4, 9]
  },
  {
    id: 3,
    name: "Pig",
    khmerName: "កុរ ឆុង ម្សាញ់ (50% មមែ ឆ្លូវ ម្សាញ់ និងថោះ)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147356831_cc9b533d.webp",
    element: "Water",
    khmerElement: "ទឹក",
    polarity: "Yin",
    khmerPolarity: "យិន",
    traits: ["Compassionate", "Generous", "Diligent", "Honest"],
    khmerTraits: ["មេត្តាករុណា", "សប្បុរស", "ឧស្សាហ៍", "ត្រង់"],
    luckyColors: ["Yellow", "Gray", "Brown"],
    khmerLuckyColors: ["លឿង", "ប្រផេះ", "ត្នោត"],
    luckyNumbers: [2, 5, 8]
  },
  {
    id: 4,
    name: "Rat",
    khmerName: "ជូត ឆុង មមី (50% ខាល និងច មមែ និងម្សាញ់)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147334198_a3361d56.webp",
    element: "Water",
    khmerElement: "ទឹក",
    polarity: "Yang",
    khmerPolarity: "យ៉ាំង",
    traits: ["Intelligent", "Adaptable", "Quick-witted", "Charming"],
    khmerTraits: ["ឆ្លាតវៃ", "សម្របខ្លួន", "ឆាប់យល់", "ទាក់ទាញ"],
    luckyColors: ["Blue", "Gold", "Green"],
    khmerLuckyColors: ["ខៀវ", "មាស", "បៃតង"],
    luckyNumbers: [2, 3]
  },
  {
    id: 5,
    name: "Ox",
    khmerName: "ឆ្លូវ ឆុង មមែ (50% រោង ច មមី និងវក)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147334934_e5455d65.webp",
    element: "Earth",
    khmerElement: "ដី",
    polarity: "Yin",
    khmerPolarity: "យិន",
    traits: ["Diligent", "Dependable", "Strong", "Determined"],
    khmerTraits: ["ឧស្សាហ៍", "អាចជឿទុកចិត្ត", "រឹងមាំ", "តាំងចិត្ត"],
    luckyColors: ["White", "Yellow", "Green"],
    khmerLuckyColors: ["ស", "លឿង", "បៃតង"],
    luckyNumbers: [1, 4]
  },
  {
    id: 6,
    name: "Tiger",
    khmerName: "ខាល ឆុង វក (50% កុរ ម្សាញ់ មមែ និងរកា)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147335715_ef852b66.webp",
    element: "Wood",
    khmerElement: "ឈើ",
    polarity: "Yang",
    khmerPolarity: "យ៉ាំង",
    traits: ["Brave", "Confident", "Competitive", "Unpredictable"],
    khmerTraits: ["ក្លាហាន", "ទុកចិត្ត", "ប្រកួតប្រជែង", "មិនអាចទាយ"],
    luckyColors: ["Blue", "Gray", "Orange"],
    khmerLuckyColors: ["ខៀវ", "ប្រផេះ", "ទឹកក្រូច"],
    luckyNumbers: [1, 3, 4]
  },
  {
    id: 7,
    name: "Rabbit",
    khmerName: "ថោះ ឆុង រកា (50% មមី ជូត វក និងច)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147338139_c21f5c16.webp",
    element: "Wood",
    khmerElement: "ឈើ",
    polarity: "Yin",
    khmerPolarity: "យិន",
    traits: ["Gentle", "Quiet", "Elegant", "Alert"],
    khmerTraits: ["ទន់ភ្លន់", "ស្ងាត់", "ស្រស់ស្អាត", "ប្រុងប្រយ័ត្ន"],
    luckyColors: ["Red", "Pink", "Purple", "Blue"],
    khmerLuckyColors: ["ក្រហម", "ផ្កាឈូក", "ស្វាយ", "ខៀវ"],
    luckyNumbers: [3, 4, 6]
  },
  {
    id: 8,
    name: "Dragon",
    khmerName: "រោង ឆុង ច (50% មមែ ឆ្លូវ កុរ និងរកា)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147344543_84380219.webp",
    element: "Earth",
    khmerElement: "ដី",
    polarity: "Yang",
    khmerPolarity: "យ៉ាំង",
    traits: ["Confident", "Intelligent", "Enthusiastic", "Charismatic"],
    khmerTraits: ["ទុកចិត្ត", "ឆ្លាតវៃ", "ក្លៀវក្លា", "ទាក់ទាញ"],
    luckyColors: ["Gold", "Silver", "Gray"],
    khmerLuckyColors: ["មាស", "ប្រាក់", "ប្រផេះ"],
    luckyNumbers: [1, 6, 7]
  },
  {
    id: 9,
    name: "Snake",
    khmerName: "ម្សាញ់ ឆុង កុរ (50% វក ខាល ជូត និងច)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147345333_66d5a0dd.webp",
    element: "Fire",
    khmerElement: "ភ្លើង",
    polarity: "Yin",
    khmerPolarity: "យិន",
    traits: ["Wise", "Enigmatic", "Intuitive", "Graceful"],
    khmerTraits: ["ប្រាជ្ញា", "អាថ៌កំបាំង", "វិចារណញាណ", "ស្រស់ស្អាត"],
    luckyColors: ["Black", "Red", "Yellow"],
    khmerLuckyColors: ["ខ្មៅ", "ក្រហម", "លឿង"],
    luckyNumbers: [2, 8, 9]
  },
  {
    id: 10,
    name: "Horse",
    khmerName: "មមី ឆុង ជូត (50% រកា ថោះ កុរ និងឆ្លូវ)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147346064_47ef9093.webp",
    element: "Fire",
    khmerElement: "ភ្លើង",
    polarity: "Yang",
    khmerPolarity: "យ៉ាំង",
    traits: ["Energetic", "Independent", "Warm-hearted", "Cheerful"],
    khmerTraits: ["ស្វាហាប់", "ឯករាជ្យ", "ចិត្តក្តៅ", "រីករាយ"],
    luckyColors: ["Yellow", "Green"],
    khmerLuckyColors: ["លឿង", "បៃតង"],
    luckyNumbers: [2, 3, 7]
  },
  {
    id: 11,
    name: "Goat",
    khmerName: "មមែ ឆុង ឆ្លូវ (50% ច រោង ជូត និងខាល)",
    image: "https://d64gsuwffb70l.cloudfront.net/68e99607bb0a965d745162b3_1760147347169_d34c9342.webp",
    element: "Earth",
    khmerElement: "ដី",
    polarity: "Yin",
    khmerPolarity: "យិន",
    traits: ["Calm", "Gentle", "Creative", "Sympathetic"],
    khmerTraits: ["ស្ងប់", "ទន់ភ្លន់", "ច្នៃប្រឌិត", "អាណិត"],
    luckyColors: ["Brown", "Red", "Purple"],
    khmerLuckyColors: ["ត្នោត", "ក្រហម", "ស្វាយ"],
    luckyNumbers: [2, 7]
  }
];
