// Complete Auxiliary Stars Reference for all 10 Day Masters
export interface CompleteAuxiliaryStars {
  dayMaster: string;
  chineseName: string;
  element: string;
  polarity: string;
  noblePerson: string[];
  academicStar: string;
  peachBlossom: string;
  travellingHorse: string;
  artistStar: string;
  deathStar: string;
  lonesomeStar: string;
  robberyStar: string;
  swordStar: string;
  dragonVirtue: string;
  robWealth: string;
  sunStar: string;
  moonStar: string;
  heavenVirtue: string;
  skyHappiness: string;
}

export const completeAuxiliaryStars: CompleteAuxiliaryStars[] = [
  {
    dayMaster: 'Water Yang',
    chineseName: '壬 (Ren)',
    element: 'Water',
    polarity: 'Yang',
    noblePerson: ['卯 (Rabbit)', '巳 (Snake)'],
    academicStar: '寅 (Tiger)',
    peachBlossom: '酉 (Rooster)',
    travellingHorse: '寅 (Tiger)',
    artistStar: '午 (Horse)',
    deathStar: '巳 (Snake)',
    lonesomeStar: '亥 (Pig)',
    robberyStar: '申 (Monkey)',
    swordStar: '卯 (Rabbit)',
    dragonVirtue: '辰 (Dragon)',
    robWealth: '壬 (Ren)',
    sunStar: '巳 (Snake)',
    moonStar: '亥 (Pig)',
    heavenVirtue: '丁 (Ding)',
    skyHappiness: '子 (Rat)'
  },
  {
    dayMaster: 'Wood Yang',
    chineseName: '甲 (Jia)',
    element: 'Wood',
    polarity: 'Yang',
    noblePerson: ['丑 (Ox)', '未 (Goat)'],
    academicStar: '巳 (Snake)',
    peachBlossom: '午 (Horse)',
    travellingHorse: '申 (Monkey)',
    artistStar: '子 (Rat)',
    deathStar: '未 (Goat)',
    lonesomeStar: '寅 (Tiger)',
    robberyStar: '亥 (Pig)',
    swordStar: '卯 (Rabbit)',
    dragonVirtue: '辰 (Dragon)',
    robWealth: '甲 (Jia)',
    sunStar: '寅 (Tiger)',
    moonStar: '申 (Monkey)',
    heavenVirtue: '己 (Ji)',
    skyHappiness: '寅 (Tiger)'
  },
  {
    dayMaster: 'Wood Yin',
    chineseName: '乙 (Yi)',
    element: 'Wood',
    polarity: 'Yin',
    noblePerson: ['申 (Monkey)', '子 (Rat)'],
    academicStar: '午 (Horse)',
    peachBlossom: '午 (Horse)',
    travellingHorse: '申 (Monkey)',
    artistStar: '亥 (Pig)',
    deathStar: '申 (Monkey)',
    lonesomeStar: '丑 (Ox)',
    robberyStar: '亥 (Pig)',
    swordStar: '辰 (Dragon)',
    dragonVirtue: '巳 (Snake)',
    robWealth: '乙 (Yi)',
    sunStar: '卯 (Rabbit)',
    moonStar: '酉 (Rooster)',
    heavenVirtue: '戊 (Wu)',
    skyHappiness: '卯 (Rabbit)'
  },
  {
    dayMaster: 'Fire Yang',
    chineseName: '丙 (Bing)',
    element: 'Fire',
    polarity: 'Yang',
    noblePerson: ['酉 (Rooster)', '亥 (Pig)'],
    academicStar: '申 (Monkey)',
    peachBlossom: '卯 (Rabbit)',
    travellingHorse: '亥 (Pig)',
    artistStar: '寅 (Tiger)',
    deathStar: '酉 (Rooster)',
    lonesomeStar: '巳 (Snake)',
    robberyStar: '寅 (Tiger)',
    swordStar: '午 (Horse)',
    dragonVirtue: '午 (Horse)',
    robWealth: '丙 (Bing)',
    sunStar: '巳 (Snake)',
    moonStar: '亥 (Pig)',
    heavenVirtue: '辛 (Xin)',
    skyHappiness: '巳 (Snake)'
  },
  {
    dayMaster: 'Fire Yin',
    chineseName: '丁 (Ding)',
    element: 'Fire',
    polarity: 'Yin',
    noblePerson: ['酉 (Rooster)', '亥 (Pig)'],
    academicStar: '酉 (Rooster)',
    peachBlossom: '卯 (Rabbit)',
    travellingHorse: '亥 (Pig)',
    artistStar: '丑 (Ox)',
    deathStar: '戌 (Dog)',
    lonesomeStar: '辰 (Dragon)',
    robberyStar: '寅 (Tiger)',
    swordStar: '未 (Goat)',
    dragonVirtue: '未 (Goat)',
    robWealth: '丁 (Ding)',
    sunStar: '午 (Horse)',
    moonStar: '子 (Rat)',
    heavenVirtue: '庚 (Geng)',
    skyHappiness: '午 (Horse)'
  },
  {
    dayMaster: 'Earth Yang',
    chineseName: '戊 (Wu)',
    element: 'Earth',
    polarity: 'Yang',
    noblePerson: ['丑 (Ox)', '未 (Goat)'],
    academicStar: '申 (Monkey)',
    peachBlossom: '卯 (Rabbit)',
    travellingHorse: '亥 (Pig)',
    artistStar: '寅 (Tiger)',
    deathStar: '酉 (Rooster)',
    lonesomeStar: '巳 (Snake)',
    robberyStar: '寅 (Tiger)',
    swordStar: '午 (Horse)',
    dragonVirtue: '午 (Horse)',
    robWealth: '戊 (Wu)',
    sunStar: '辰 (Dragon)',
    moonStar: '戌 (Dog)',
    heavenVirtue: '癸 (Gui)',
    skyHappiness: '未 (Goat)'
  },
  {
    dayMaster: 'Earth Yin',
    chineseName: '己 (Ji)',
    element: 'Earth',
    polarity: 'Yin',
    noblePerson: ['申 (Monkey)', '子 (Rat)'],
    academicStar: '酉 (Rooster)',
    peachBlossom: '午 (Horse)',
    travellingHorse: '申 (Monkey)',
    artistStar: '亥 (Pig)',
    deathStar: '申 (Monkey)',
    lonesomeStar: '丑 (Ox)',
    robberyStar: '亥 (Pig)',
    swordStar: '未 (Goat)',
    dragonVirtue: '未 (Goat)',
    robWealth: '己 (Ji)',
    sunStar: '未 (Goat)',
    moonStar: '丑 (Ox)',
    heavenVirtue: '壬 (Ren)',
    skyHappiness: '申 (Monkey)'
  },
  {
    dayMaster: 'Metal Yang',
    chineseName: '庚 (Geng)',
    element: 'Metal',
    polarity: 'Yang',
    noblePerson: ['丑 (Ox)', '未 (Goat)'],
    academicStar: '亥 (Pig)',
    peachBlossom: '子 (Rat)',
    travellingHorse: '巳 (Snake)',
    artistStar: '辰 (Dragon)',
    deathStar: '亥 (Pig)',
    lonesomeStar: '申 (Monkey)',
    robberyStar: '巳 (Snake)',
    swordStar: '酉 (Rooster)',
    dragonVirtue: '申 (Monkey)',
    robWealth: '庚 (Geng)',
    sunStar: '申 (Monkey)',
    moonStar: '寅 (Tiger)',
    heavenVirtue: '乙 (Yi)',
    skyHappiness: '酉 (Rooster)'
  },
  {
    dayMaster: 'Metal Yin',
    chineseName: '辛 (Xin)',
    element: 'Metal',
    polarity: 'Yin',
    noblePerson: ['寅 (Tiger)', '午 (Horse)'],
    academicStar: '子 (Rat)',
    peachBlossom: '子 (Rat)',
    travellingHorse: '巳 (Snake)',
    artistStar: '卯 (Rabbit)',
    deathStar: '子 (Rat)',
    lonesomeStar: '未 (Goat)',
    robberyStar: '巳 (Snake)',
    swordStar: '戌 (Dog)',
    dragonVirtue: '酉 (Rooster)',
    robWealth: '辛 (Xin)',
    sunStar: '酉 (Rooster)',
    moonStar: '卯 (Rabbit)',
    heavenVirtue: '甲 (Jia)',
    skyHappiness: '戌 (Dog)'
  },

  {
    dayMaster: 'Water Yin',
    chineseName: '癸 (Gui)',
    element: 'Water',
    polarity: 'Yin',
    noblePerson: ['卯 (Rabbit)', '巳 (Snake)'],
    academicStar: '卯 (Rabbit)',
    peachBlossom: '酉 (Rooster)',
    travellingHorse: '寅 (Tiger)',
    artistStar: '巳 (Snake)',
    deathStar: '午 (Horse)',
    lonesomeStar: '戌 (Dog)',
    robberyStar: '申 (Monkey)',
    swordStar: '辰 (Dragon)',
    dragonVirtue: '辰 (Dragon)',
    robWealth: '癸 (Gui)',
    sunStar: '午 (Horse)',
    moonStar: '子 (Rat)',
    heavenVirtue: '丙 (Bing)',
    skyHappiness: '丑 (Ox)'
  }
];
