// Comprehensive Ten Gods (十神) Analysis System
export interface TenGodDetail {
  chinese: string;
  pinyin: string;
  english: string;
  khmer: string;
  category: string;
  khmerCategory: string;
  personality: string;
  khmerPersonality: string;
  career: string;
  khmerCareer: string;
  relationships: string;
  khmerRelationships: string;
  wealth: string;
  khmerWealth: string;
  strengths: string[];
  khmerStrengths: string[];
  weaknesses: string[];
  khmerWeaknesses: string[];
}

export const tenGodsDetailed: { [key: string]: TenGodDetail } = {
  friend: {
    chinese: "比肩", pinyin: "Bǐ Jiān", english: "Friend/Companion", khmer: "មិត្តភក្តិ",
    category: "Companion Star", khmerCategory: "ផ្កាយមិត្ត",
    personality: "Independent, self-reliant, strong-willed. Values personal freedom and autonomy.",
    khmerPersonality: "ឯករាជ្យ ពឹងខ្លួនឯង ឆន្ទៈរឹងមាំ។ គោរពសេរីភាព និងស្វយ័តភាព។",
    career: "Entrepreneurship, self-employment, leadership roles. Excels in competitive environments.",
    khmerCareer: "សហគ្រិន ធ្វើការឯករាជ្យ តួនាទីដឹកនាំ។ ពូកែក្នុងបរិយាកាសប្រកួតប្រជែង។",
    relationships: "Loyal friend but may struggle with compromise. Values equality in partnerships.",
    khmerRelationships: "មិត្តស្មោះត្រង់ ប៉ុន្តែអាចលំបាកក្នុងការសម្របសម្រួល។",
    wealth: "Earns through own efforts. May face competition for resources.",
    khmerWealth: "រកប្រាក់ដោយខ្លួនឯង។ អាចប្រឈមមុខនឹងការប្រកួតប្រជែង។",
    strengths: ["Self-reliant", "Determined", "Competitive"],
    khmerStrengths: ["ពឹងខ្លួនឯង", "តាំងចិត្ត", "ប្រកួតប្រជែង"],
    weaknesses: ["Stubborn", "Resistant to help", "Competitive with peers"],
    khmerWeaknesses: ["រឹងរូស", "ប្រឆាំងនឹងជំនួយ", "ប្រកួតប្រជែងជាមួយមិត្ត"]
  },
  robWealth: {
    chinese: "劫财", pinyin: "Jié Cái", english: "Rob Wealth", khmer: "ប្លន់ទ្រព្យ",
    category: "Companion Star", khmerCategory: "ផ្កាយមិត្ត",
    personality: "Ambitious, assertive, takes initiative. Bold and action-oriented.",
    khmerPersonality: "មានមហិច្ឆតា ស្វាហាប់ ចាប់ផ្តើម។ ក្លាហាន និងសកម្ម។",
    career: "Sales, negotiation, competitive fields. Thrives under pressure.",
    khmerCareer: "លក់ ចរចា វិស័យប្រកួតប្រជែង។ រីកចម្រើនក្រោមសម្ពាធ។",
    relationships: "Passionate but may be possessive. Strong desire for control.",
    khmerRelationships: "ក្តៅក្រហាយ ប៉ុន្តែអាចមានការកាន់កាប់។",
    wealth: "Risk-taker with money. May experience financial ups and downs.",
    khmerWealth: "ហ៊ានប្រថុយជាមួយលុយ។ អាចជួបការឡើងចុះហិរញ្ញវត្ថុ។",
    strengths: ["Bold", "Decisive", "Action-oriented"],
    khmerStrengths: ["ក្លាហាន", "សម្រេចចិត្ត", "សកម្ម"],
    weaknesses: ["Impulsive", "Competitive", "May overstep boundaries"],
    khmerWeaknesses: ["ប្រញាប់", "ប្រកួតប្រជែង", "អាចហួសព្រំដែន"]
  },
  eatingGod: {
    chinese: "食神", pinyin: "Shí Shén", english: "Eating God", khmer: "ព្រះហូបបាយ",
    category: "Output Star", khmerCategory: "ផ្កាយលទ្ធផល",
    personality: "Creative, optimistic, enjoys life. Expressive and artistic nature.",
    khmerPersonality: "ច្នៃប្រឌិត សុទិដ្ឋិនិយម រីករាយជីវិត។ បង្ហាញមតិ និងសិល្បៈ។",
    career: "Arts, entertainment, food industry, creative fields. Natural performer.",
    khmerCareer: "សិល្បៈ កម្សាន្ត ឧស្សាហកម្មអាហារ វិស័យច្នៃប្រឌិត។",
    relationships: "Warm, generous, enjoys socializing. Good with children.",
    khmerRelationships: "ក្តៅក្រហាយ សប្បុរស ចូលចិត្តសង្គម។ ល្អជាមួយកុមារ។",
    wealth: "Steady income through creativity. Good at generating multiple income streams.",
    khmerWealth: "ប្រាក់ចំណូលស្ថិរតាមរយៈភាពច្នៃប្រឌិត។",
    strengths: ["Creative", "Optimistic", "Expressive"],
    khmerStrengths: ["ច្នៃប្រឌិត", "សុទិដ្ឋិនិយម", "បង្ហាញមតិ"],
    weaknesses: ["May overindulge", "Can be unrealistic", "Avoids conflict"],
    khmerWeaknesses: ["អាចលើសលប់", "អាចមិនជាក់ស្តែង", "ជៀសវាងទំនាស់"]
  }
};
