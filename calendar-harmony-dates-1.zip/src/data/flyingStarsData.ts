// Flying Stars (Xuan Kong Fei Xing) Data

export const periods = [
  { period: 1, startYear: 1864, endYear: 1883, element: "Water", khmerElement: "ទឹក" },
  { period: 2, startYear: 1884, endYear: 1903, element: "Earth", khmerElement: "ដី" },
  { period: 3, startYear: 1904, endYear: 1923, element: "Wood", khmerElement: "ឈើ" },
  { period: 4, startYear: 1924, endYear: 1943, element: "Wood", khmerElement: "ឈើ" },
  { period: 5, startYear: 1944, endYear: 1963, element: "Earth", khmerElement: "ដី" },
  { period: 6, startYear: 1964, endYear: 1983, element: "Metal", khmerElement: "ដែក" },
  { period: 7, startYear: 1984, endYear: 2003, element: "Metal", khmerElement: "ដែក" },
  { period: 8, startYear: 2004, endYear: 2023, element: "Earth", khmerElement: "ដី" },
  { period: 9, startYear: 2024, endYear: 2043, element: "Fire", khmerElement: "ភ្លើង" }
];

export const starMeanings: Record<number, { 
  name: string; 
  khmerName: string;
  element: string; 
  khmerElement: string;
  nature: string; 
  khmerNature: string;
  color: string 
}> = {
  1: { 
    name: "Tan Lang (Greedy Wolf)", 
    khmerName: "តាន់ ឡាំង (ចចកលោភ)",
    element: "Water", 
    khmerElement: "ទឹក",
    nature: "Auspicious", 
    khmerNature: "មង្គល",
    color: "bg-blue-100 border-blue-300" 
  },
  2: { 
    name: "Ju Men (Giant Gate)", 
    khmerName: "ជូ ម៉េន (ទ្វារយក្ស)",
    element: "Earth", 
    khmerElement: "ដី",
    nature: "Illness", 
    khmerNature: "ជំងឺ",
    color: "bg-yellow-100 border-yellow-300" 
  },
  3: { 
    name: "Lu Cun (Stored Wealth)", 
    khmerName: "លូ ឆន (ទ្រព្យរក្សា)",
    element: "Wood", 
    khmerElement: "ឈើ",
    nature: "Quarrel", 
    khmerNature: "ទំនាស់",
    color: "bg-green-100 border-green-300" 
  },
  4: { 
    name: "Wen Qu (Literary)", 
    khmerName: "វ៉េន ឈូ (អក្សរសាស្ត្រ)",
    element: "Wood", 
    khmerElement: "ឈើ",
    nature: "Romance", 
    khmerNature: "ស្នេហា",
    color: "bg-emerald-100 border-emerald-300" 
  },
  5: { 
    name: "Lian Zhen (Pure Virtue)", 
    khmerName: "លៀន ចិន (គុណធម៌បរិសុទ្ធ)",
    element: "Earth", 
    khmerElement: "ដី",
    nature: "Disaster", 
    khmerNature: "គ្រោះមហន្តរាយ",
    color: "bg-gray-100 border-gray-400" 
  },
  6: { 
    name: "Wu Qu (Military)", 
    khmerName: "វូ ឈូ (យោធា)",
    element: "Metal", 
    khmerElement: "ដែក",
    nature: "Authority", 
    khmerNature: "អំណាច",
    color: "bg-slate-100 border-slate-300" 
  },
  7: { 
    name: "Po Jun (Broken Army)", 
    khmerName: "ប៉ូ ជូន (កងទ័ពបែក)",
    element: "Metal", 
    khmerElement: "ដែក",
    nature: "Violence", 
    khmerNature: "ហិង្សា",
    color: "bg-red-100 border-red-300" 
  },
  8: { 
    name: "Zuo Fu (Left Assistant)", 
    khmerName: "ឈួ ហ្វូ (ជំនួយឆ្វេង)",
    element: "Earth", 
    khmerElement: "ដី",
    nature: "Wealth", 
    khmerNature: "ទ្រព្យសម្បត្តិ",
    color: "bg-amber-100 border-amber-300" 
  },
  9: { 
    name: "You Bi (Right Assistant)", 
    khmerName: "យូ ប៊ី (ជំនួយស្តាំ)",
    element: "Fire", 
    khmerElement: "ភ្លើង",
    nature: "Celebration", 
    khmerNature: "ការប្រារព្ធ",
    color: "bg-purple-100 border-purple-300" 
  }
};

export const directions = [
  "North", "Northeast", "East", "Southeast", "South", "Southwest", "West", "Northwest"
];

export const khmerDirections = [
  "ខាងជើង", "ឦសាន", "ខាងកើត", "អាគ្នេយ៍", "ខាងត្បូង", "និរតី", "ខាងលិច", "វាយុ"
];

export const annualStars2025 = [
  [6, 2, 4],
  [5, 7, 9],
  [1, 3, 8]
];
