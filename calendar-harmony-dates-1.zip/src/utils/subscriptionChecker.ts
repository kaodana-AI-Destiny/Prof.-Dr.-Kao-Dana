import { UserSubscription, SubscriptionStatus } from '@/lib/subscriptionTypes';

export const GRACE_PERIOD_DAYS = 3;

export function calculateDaysRemaining(endDate: string): number {
  const end = new Date(endDate);
  const now = new Date();
  const diff = end.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export function isSubscriptionExpired(subscription: UserSubscription): boolean {
  const daysRemaining = calculateDaysRemaining(subscription.end_date);
  return daysRemaining < 0;
}

export function isInGracePeriod(subscription: UserSubscription): boolean {
  if (!subscription.grace_period_end) return false;
  const graceDays = calculateDaysRemaining(subscription.grace_period_end);
  return graceDays >= 0;
}

export function shouldSendWarning(subscription: UserSubscription): boolean {
  const daysRemaining = calculateDaysRemaining(subscription.end_date);
  return daysRemaining <= 3 && daysRemaining > 0;
}

export function getSubscriptionStatus(subscription: UserSubscription): SubscriptionStatus {
  if (isSubscriptionExpired(subscription)) {
    if (isInGracePeriod(subscription)) {
      return 'grace_period';
    }
    return 'expired';
  }
  return subscription.status;
}

export function formatTimeRemaining(days: number): string {
  if (days < 0) return 'Expired';
  if (days === 0) return 'Expires today';
  if (days === 1) return '1 day remaining';
  return `${days} days remaining`;
}
