// Heavenly Stems (Tian Gan)
export const heavenlyStems = [
  { name: "Jia", element: "Wood", polarity: "Yang", khmer: "ជា", khmerElement: "ឈើ", khmerPolarity: "យ៉ាំង", hNumber: "H1", chinese: "甲" },
  { name: "Yi", element: "Wood", polarity: "Yin", khmer: "យី", khmerElement: "ឈើ", khmerPolarity: "យិន", hNumber: "H2", chinese: "乙" },
  { name: "Bing", element: "Fire", polarity: "Yang", khmer: "ប៊ីង", khmerElement: "ភ្លើង", khmerPolarity: "យ៉ាំង", hNumber: "H3", chinese: "丙" },
  { name: "Ding", element: "Fire", polarity: "Yin", khmer: "ឌីង", khmerElement: "ភ្លើង", khmerPolarity: "យិន", hNumber: "H4", chinese: "丁" },
  { name: "Wu", element: "Earth", polarity: "Yang", khmer: "វូ", khmerElement: "ដី", khmerPolarity: "យ៉ាំង", hNumber: "H5", chinese: "戊" },
  { name: "Ji", element: "Earth", polarity: "Yin", khmer: "ជី", khmerElement: "ដី", khmerPolarity: "យិន", hNumber: "H6", chinese: "己" },
  { name: "Geng", element: "Metal", polarity: "Yang", khmer: "ហ្គេង", khmerElement: "លោហៈ", khmerPolarity: "យ៉ាំង", hNumber: "H7", chinese: "庚" },
  { name: "Xin", element: "Metal", polarity: "Yin", khmer: "ស៊ីន", khmerElement: "លោហៈ", khmerPolarity: "យិន", hNumber: "H8", chinese: "辛" },
  { name: "Ren", element: "Water", polarity: "Yang", khmer: "រេន", khmerElement: "ទឹក", khmerPolarity: "យ៉ាំង", hNumber: "H9", chinese: "壬" },
  { name: "Gui", element: "Water", polarity: "Yin", khmer: "គុយ", khmerElement: "ទឹក", khmerPolarity: "យិន", hNumber: "H10", chinese: "癸" }
];


// Earthly Branches (Di Zhi) - Traditional order starting with Zi (Rat)
export const earthlyBranches = [
  { name: "Zi", animal: "Rat", khmerAnimal: "ជូត", element: "Water", khmerElement: "ទឹក", polarity: "Yang", khmerPolarity: "យ៉ាំង", chinese: "子" },
  { name: "Chou", animal: "Ox", khmerAnimal: "ឆ្លូវ", element: "Earth", khmerElement: "ដី", polarity: "Yin", khmerPolarity: "យិន", chinese: "丑" },
  { name: "Yin", animal: "Tiger", khmerAnimal: "ខាល", element: "Wood", khmerElement: "ឈើ", polarity: "Yang", khmerPolarity: "យ៉ាំង", chinese: "寅" },
  { name: "Mao", animal: "Rabbit", khmerAnimal: "ថោះ", element: "Wood", khmerElement: "ឈើ", polarity: "Yin", khmerPolarity: "យិន", chinese: "卯" },
  { name: "Chen", animal: "Dragon", khmerAnimal: "រោង", element: "Earth", khmerElement: "ដី", polarity: "Yang", khmerPolarity: "យ៉ាំង", chinese: "辰" },
  { name: "Si", animal: "Snake", khmerAnimal: "ម្សាញ់", element: "Fire", khmerElement: "ភ្លើង", polarity: "Yin", khmerPolarity: "យិន", chinese: "巳" },
  { name: "Wu", animal: "Horse", khmerAnimal: "មមី", element: "Fire", khmerElement: "ភ្លើង", polarity: "Yang", khmerPolarity: "យ៉ាំង", chinese: "午" },
  { name: "Wei", animal: "Goat", khmerAnimal: "មមែ", element: "Earth", khmerElement: "ដី", polarity: "Yin", khmerPolarity: "យិន", chinese: "未" },
  { name: "Shen", animal: "Monkey", khmerAnimal: "វក", element: "Metal", khmerElement: "លោហៈ", polarity: "Yang", khmerPolarity: "យ៉ាំង", chinese: "申" },
  { name: "You", animal: "Rooster", khmerAnimal: "រកា", element: "Metal", khmerElement: "លោហៈ", polarity: "Yin", khmerPolarity: "យិន", chinese: "酉" },
  { name: "Xu", animal: "Dog", khmerAnimal: "ច", element: "Earth", khmerElement: "ដី", polarity: "Yang", khmerPolarity: "យ៉ាំង", chinese: "戌" },
  { name: "Hai", animal: "Pig", khmerAnimal: "កុរ", element: "Water", khmerElement: "ទឹក", polarity: "Yin", khmerPolarity: "យិន", chinese: "亥" }
];


// Hidden Stems in Earthly Branches
export const hiddenStems: { [key: string]: number[] } = {
  "Zi": [9],           // 子 Rat: 癸 (Gui)
  "Chou": [5, 7, 9],   // 丑 Ox: 己辛癸
  "Yin": [0, 2, 4],    // 寅 Tiger: 甲丙戊
  "Mao": [1],          // 卯 Rabbit: 乙 (Yi)
  "Chen": [4, 1, 9],   // 辰 Dragon: 戊乙癸
  "Si": [2, 4, 6],     // 巳 Snake: 丙戊庚
  "Wu": [3, 5],        // 午 Horse: 丁己
  "Wei": [5, 3, 1],    // 未 Goat: 己丁乙
  "Shen": [6, 8, 4],   // 申 Monkey: 庚壬戊
  "You": [7],          // 酉 Rooster: 辛 (Xin)
  "Xu": [4, 7, 3],     // 戌 Dog: 戊辛丁
  "Hai": [8, 0]        // 亥 Pig: 壬甲
};

export interface TenGod {
  chinese: string;
  pinyin: string;
  english: string;
}

export interface BaZiPillar {
  stem: typeof heavenlyStems[0];
  branch: typeof earthlyBranches[0];
  hiddenStems: typeof heavenlyStems;
  tenGod?: TenGod;
}

export interface BaZiChart {
  year: BaZiPillar;
  month: BaZiPillar;
  day: BaZiPillar;
  hour: BaZiPillar;
  dayMaster: typeof heavenlyStems[0];
  elements: { [key: string]: number };
  tenGodsCount: { [key: string]: number };
}

// Element production cycle
const elementProduces: { [key: string]: string } = {
  Wood: "Fire", Fire: "Earth", Earth: "Metal", Metal: "Water", Water: "Wood"
};

// Element control cycle
const elementControls: { [key: string]: string } = {
  Wood: "Earth", Earth: "Water", Water: "Fire", Fire: "Metal", Metal: "Wood"
};

// Calculate Ten God
export function calculateTenGod(dayMaster: typeof heavenlyStems[0], targetStem: typeof heavenlyStems[0]): TenGod {
  const dmElement = dayMaster.element;
  const dmPolarity = dayMaster.polarity;
  const tElement = targetStem.element;
  const tPolarity = targetStem.polarity;
  
  if (dmElement === tElement) {
    return dmPolarity === tPolarity ? 
      { chinese: "比肩", pinyin: "Bǐ Jiān", english: "Friend" } :
      { chinese: "劫财", pinyin: "Jié Cái", english: "Rob Wealth" };
  }
  
  if (elementProduces[dmElement] === tElement) {
    return dmPolarity === tPolarity ?
      { chinese: "食神", pinyin: "Shí Shén", english: "Eating God" } :
      { chinese: "伤官", pinyin: "Shāng Guān", english: "Hurting Officer" };
  }
  
  if (elementControls[dmElement] === tElement) {
    return dmPolarity === tPolarity ?
      { chinese: "偏财", pinyin: "Piān Cái", english: "Indirect Wealth" } :
      { chinese: "正财", pinyin: "Zhèng Cái", english: "Direct Wealth" };
  }
  
  if (elementControls[tElement] === dmElement) {
    return dmPolarity === tPolarity ?
      { chinese: "七杀", pinyin: "Qī Shā", english: "Seven Killings" } :
      { chinese: "正官", pinyin: "Zhèng Guān", english: "Direct Officer" };
  }
  
  if (elementProduces[tElement] === dmElement) {
    return dmPolarity === tPolarity ?
      { chinese: "偏印", pinyin: "Piān Yìn", english: "Indirect Resource" } :
      { chinese: "正印", pinyin: "Zhèng Yìn", english: "Direct Resource" };
  }
  
  return { chinese: "比肩", pinyin: "Bǐ Jiān", english: "Friend" };
}

export function calculateBaZi(date: Date, hour: number): BaZiChart {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  // Year Pillar - 1924 is Jia Zi (甲子)
  const yearOffset = (year - 1924) % 60;
  const yearStemIndex = yearOffset % 10;
  const yearStem = heavenlyStems[yearStemIndex];
  const yearBranch = earthlyBranches[yearOffset % 12];
  const yearHiddenStems = hiddenStems[yearBranch.name].map(idx => heavenlyStems[idx]);
  
  // Month Pillar - using solar terms for accurate Chinese month determination
  // Chinese months start with Tiger (Yin) on Feb 4 each year
  // Each month begins at a solar term (Jie Qi)
  const solarTermMonths = [
    { month: 2, day: 4, branchIndex: 2 },   // Tiger (Yin) - Feb 4 (Lichun)
    { month: 3, day: 6, branchIndex: 3 },   // Rabbit (Mao) - Mar 6 (Jingzhe)
    { month: 4, day: 5, branchIndex: 4 },   // Dragon (Chen) - Apr 5 (Qingming)
    { month: 5, day: 6, branchIndex: 5 },   // Snake (Si) - May 6 (Lixia)
    { month: 6, day: 6, branchIndex: 6 },   // Horse (Wu) - Jun 6 (Mangzhong)
    { month: 7, day: 7, branchIndex: 7 },   // Goat (Wei) - Jul 7 (Xiaoshu)
    { month: 8, day: 8, branchIndex: 8 },   // Monkey (Shen) - Aug 8 (Liqiu)
    { month: 9, day: 8, branchIndex: 9 },   // Rooster (You) - Sep 8 (Bailu)
    { month: 10, day: 8, branchIndex: 10 }, // Dog (Xu) - Oct 8 (Hanlu)
    { month: 11, day: 7, branchIndex: 11 }, // Pig (Hai) - Nov 7 (Lidong)
    { month: 12, day: 7, branchIndex: 0 },  // Rat (Zi) - Dec 7 (Daxue)
    { month: 1, day: 6, branchIndex: 1 }    // Ox (Chou) - Jan 6 (Xiaohan)
  ];
  
  // Determine Chinese month based on solar terms
  // Find the appropriate branch based on current date
  let monthBranchIndex = 1; // Default to Ox (Chou) for early January
  
  // Check each solar term to find which month we're in
  for (let i = 0; i < solarTermMonths.length; i++) {
    const term = solarTermMonths[i];
    const nextTerm = solarTermMonths[(i + 1) % solarTermMonths.length];
    
    // Check if current date falls within this solar term period
    if (month === term.month && day >= term.day) {
      monthBranchIndex = term.branchIndex;
      break;
    } else if (month === term.month && day < term.day) {
      // Before the solar term, use previous month
      monthBranchIndex = solarTermMonths[(i - 1 + solarTermMonths.length) % solarTermMonths.length].branchIndex;
      break;
    } else if (month > term.month && (nextTerm.month > month || (nextTerm.month === 1 && month === 12))) {
      // Between this term and next term
      monthBranchIndex = term.branchIndex;
      break;
    }
  }
  
  // Month stem calculation using Five Tigers formula
  // Reference: For year stem Jia/Ji (0,5), Tiger month = Bing (2)
  // Traditional grouping: (Jia,Ji), (Yi,Geng), (Bing,Xin), (Ding,Ren), (Wu,Gui)
  const fiveTigersBase = [2, 4, 6, 8, 0]; // Bing, Wu, Geng, Ren, Jia for Tiger month
  const yearStemGroup = yearStemIndex % 5; // Correct grouping: 0&5, 1&6, 2&7, 3&8, 4&9
  const firstMonthStem = fiveTigersBase[yearStemGroup];
  // Calculate month stem based on branch offset from Tiger (index 2)
  const monthStemIndex = (firstMonthStem + (monthBranchIndex - 2 + 12)) % 10;


  
  const monthBranch = earthlyBranches[monthBranchIndex];
  const monthHiddenStems = hiddenStems[monthBranch.name].map(idx => heavenlyStems[idx]);




  
  // Day Pillar - Using Feb 15, 1924 as Jia Zi reference (day 0 of 60-day cycle)
  // This reference date is verified for accurate BaZi calculations
  const referenceDate = new Date(1924, 1, 15); // Feb 15, 1924 = Jia Zi
  const dayOffset = Math.floor((date.getTime() - referenceDate.getTime()) / (1000 * 60 * 60 * 24));
  const dayStemIndex = ((dayOffset % 10) + 10) % 10;
  const dayBranchIndex = ((dayOffset % 12) + 12) % 12;
  const dayStem = heavenlyStems[dayStemIndex];
  const dayBranch = earthlyBranches[dayBranchIndex];
  const dayHiddenStems = hiddenStems[dayBranch.name].map(idx => heavenlyStems[idx]);


  
  // Hour Pillar - using Five Rats Escape formula
  // Hour branch is determined by time (each branch = 2 hours)
  // Chinese hours: 23-01(Zi), 01-03(Chou), 03-05(Yin), 05-07(Mao), 07-09(Chen), etc.
  const hourBranchIndex = Math.floor((hour + 1) / 2) % 12;
  const hourBranch = earthlyBranches[hourBranchIndex];

  // Five Rats Escape: Hour stem based on day stem
  // Jia/Ji days (0,5): start with Jia (0) at Zi
  // Yi/Geng days (1,6): start with Bing (2) at Zi
  // Bing/Xin days (2,7): start with Wu (4) at Zi
  // Ding/Ren days (3,8): start with Geng (6) at Zi
  // Wu/Gui days (4,9): start with Ren (8) at Zi
  const fiveRatsBase = [0, 2, 4, 6, 8]; // Starting stems for Zi hour
  const dayStemGroup = dayStemIndex % 5; // Group day stem by modulo 5
  const ziHourStem = fiveRatsBase[dayStemGroup];
  const hourStemIndex = (ziHourStem + hourBranchIndex) % 10;
  const hourStem = heavenlyStems[hourStemIndex];
  const hourHiddenStems = hiddenStems[hourBranch.name].map(idx => heavenlyStems[idx]);

  
  const dayMaster = dayStem;
  
  const yearTenGod = calculateTenGod(dayMaster, yearStem);
  const monthTenGod = calculateTenGod(dayMaster, heavenlyStems[monthStemIndex]);
  const hourTenGod = calculateTenGod(dayMaster, hourStem);
  
  const chart: BaZiChart = {
    year: { stem: yearStem, branch: yearBranch, hiddenStems: yearHiddenStems, tenGod: yearTenGod },
    month: { stem: heavenlyStems[monthStemIndex], branch: monthBranch, hiddenStems: monthHiddenStems, tenGod: monthTenGod },
    day: { stem: dayStem, branch: dayBranch, hiddenStems: dayHiddenStems },
    hour: { stem: hourStem, branch: hourBranch, hiddenStems: hourHiddenStems, tenGod: hourTenGod },
    dayMaster: dayMaster,
    elements: { Wood: 0, Fire: 0, Earth: 0, Metal: 0, Water: 0 },
    tenGodsCount: {}
  };
  
  [chart.year, chart.month, chart.day, chart.hour].forEach(pillar => {
    chart.elements[pillar.stem.element]++;
    chart.elements[pillar.branch.element]++;
  });
  
  [chart.year, chart.month, chart.hour].forEach(pillar => {
    if (pillar.tenGod) {
      const key = pillar.tenGod.english;
      chart.tenGodsCount[key] = (chart.tenGodsCount[key] || 0) + 1;
    }
  });
  
  
  return chart;
}


// Helper function to calculate BaZi for a date (defaults to midnight hour)
export function calculateBaZiForDate(date: Date): BaZiChart {
  return calculateBaZi(date, 0);
}
