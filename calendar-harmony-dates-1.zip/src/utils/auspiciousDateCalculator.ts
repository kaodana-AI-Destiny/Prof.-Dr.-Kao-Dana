import { BaZiChart } from './baziCalculator';
import { calculateBaZiForDate } from './baziCalculator';

export type EventType = 'wedding' | 'business' | 'moving' | 'general';

export interface DateAnalysis {
  date: Date;
  dateString: string;
  baziChart: BaZiChart;
  score: number;
  level: 'excellent' | 'good' | 'neutral' | 'poor';
  favorableAspects: string[];
  challenges: string[];
  recommendations: string;
  elementBalance: Record<string, number>;
}

const ELEMENT_RELATIONS = {
  producing: { Wood: 'Fire', Fire: 'Earth', Earth: 'Metal', Metal: 'Water', Water: 'Wood' },
  controlling: { Wood: 'Earth', Earth: 'Water', Water: 'Fire', Fire: 'Metal', Metal: 'Wood' }
};

export function analyzeDateCompatibility(
  birthChart: BaZiChart,
  targetDate: Date,
  eventType: EventType
): DateAnalysis {
  const dateChart = calculateBaZiForDate(targetDate);
  let score = 50;
  const favorable: string[] = [];
  const challenges: string[] = [];
  
  const elementCount: Record<string, number> = { Wood: 0, Fire: 0, Earth: 0, Metal: 0, Water: 0 };
  [dateChart.year, dateChart.month, dateChart.day, dateChart.hour].forEach(pillar => {
    elementCount[pillar.element]++;
  });

  const dayMaster = birthChart.day.element;
  const targetDayElement = dateChart.day.element;
  
  if (ELEMENT_RELATIONS.producing[dayMaster] === targetDayElement) {
    score += 15;
    favorable.push(`កាលបរិច្ឆេទបង្កើតធាតុថ្ងៃរបស់អ្នក Date produces your day master (${dayMaster} → ${targetDayElement})`);
  }
  
  if (ELEMENT_RELATIONS.producing[targetDayElement] === dayMaster) {
    score += 10;
    favorable.push(`កាលបរិច្ឆេទគាំទ្រថាមពលរបស់អ្នក Date supports your energy`);
  }
  
  if (ELEMENT_RELATIONS.controlling[targetDayElement] === dayMaster) {
    score -= 15;
    challenges.push(`កាលបរិច្ឆេទគ្រប់គ្រងធាតុថ្ងៃរបស់អ្នក Date controls your day master`);
  }

  if (eventType === 'wedding') {
    if (targetDayElement === 'Fire' || targetDayElement === 'Wood') {
      score += 10;
      favorable.push('ថាមពលកក់ក្តៅ និងរីកចម្រើនល្អសម្រាប់ការរួបរួម Warm, growing energy favorable for unions');
    }
  } else if (eventType === 'business') {
    if (targetDayElement === 'Metal' || targetDayElement === 'Water') {
      score += 10;
      favorable.push('ថាមពលច្បាស់លាស់ និងហូរលូល្អសម្រាប់អាជីវកម្ម Sharp, flowing energy good for business');
    }
  } else if (eventType === 'moving') {
    if (targetDayElement === 'Earth' || targetDayElement === 'Wood') {
      score += 10;
      favorable.push('ថាមពលស្ថិរភាព និងចាក់ឫសគាំទ្រការផ្លាស់ទីលំនៅ Stable, rooting energy supports relocation');
    }
  }

  const clashPairs: Record<string, string> = {
    Rat: 'Horse', Horse: 'Rat', Ox: 'Goat', Goat: 'Ox',
    Tiger: 'Monkey', Monkey: 'Tiger', Rabbit: 'Rooster', Rooster: 'Rabbit',
    Dragon: 'Dog', Dog: 'Dragon', Snake: 'Pig', Pig: 'Snake'
  };
  
  if (clashPairs[birthChart.day.branch] === dateChart.day.branch) {
    score -= 20;
    challenges.push('មែកថ្ងៃប៉ះទង្គិចជាមួយថ្ងៃកំណើតរបស់អ្នក Day branch clashes with your birth day');
  }

  const level = score >= 75 ? 'excellent' : score >= 60 ? 'good' : score >= 40 ? 'neutral' : 'poor';
  
  return {
    date: targetDate,
    dateString: targetDate.toLocaleDateString(),
    baziChart: dateChart,
    score,
    level,
    favorableAspects: favorable,
    challenges,
    recommendations: generateRecommendations(level, eventType),
    elementBalance: elementCount
  };
}

function generateRecommendations(level: string, eventType: string): string {
  const eventName = eventType === 'wedding' ? 'wedding' : eventType === 'business' ? 'business launch' : eventType === 'moving' ? 'move' : 'event';
  
  if (level === 'excellent') return `ល្អបំផុតសម្រាប់ ${eventName} ធ្វើទៅដោយទំនុកចិត្ត Highly auspicious for ${eventName}. Proceed with confidence.`;
  if (level === 'good') return `កាលបរិច្ឆេទអំណោយផលសម្រាប់ ${eventName} ថាមពលហូរល្អ Favorable date for ${eventName}. Good energy flow.`;
  if (level === 'neutral') return `កាលបរិច្ឆេទអាចទទួលយកបាន ពិចារណាចំណូលចិត្តផ្ទាល់ខ្លួន Acceptable date. Consider personal preferences.`;
  return `មិនណែនាំសម្រាប់ ${eventName} ពិចារណាកាលបរិច្ឆេទជំនួស Not recommended for ${eventName}. Consider alternative dates.`;
}

export function findAuspiciousDates(
  birthChart: BaZiChart,
  startDate: Date,
  endDate: Date,
  eventType: EventType,
  limit: number = 20
): DateAnalysis[] {
  const results: DateAnalysis[] = [];
  const current = new Date(startDate);
  
  while (current <= endDate && results.length < limit * 3) {
    const analysis = analyzeDateCompatibility(birthChart, new Date(current), eventType);
    results.push(analysis);
    current.setDate(current.getDate() + 1);
  }
  
  return results.sort((a, b) => b.score - a.score).slice(0, limit);
}
