export interface YearData {
  year: number;
  zodiac: string;
  element: string;
  polarity: string;
  luckyColors: string[];
  luckyNumbers: number[];
  luckyDirections: string[];
  traits: string[];
  compatible: string[];
}

const zodiacCycle = ['Rat', 'Ox', 'Tiger', 'Rabbit', 'Dragon', 'Snake', 'Horse', 'Goat', 'Monkey', 'Rooster', 'Dog', 'Pig'];
const elementCycle = ['Metal', 'Metal', 'Water', 'Water', 'Wood', 'Wood', 'Fire', 'Fire', 'Earth', 'Earth'];
const polarityCycle = ['Yang', 'Yin'];

const elementColors: Record<string, string[]> = {
  Wood: ['Green', 'Brown', 'Teal'],
  Fire: ['Red', 'Orange', 'Purple'],
  Earth: ['Yellow', 'Beige', 'Brown'],
  Metal: ['White', 'Gold', 'Silver'],
  Water: ['Blue', 'Black', 'Gray']
};

const zodiacTraits: Record<string, string[]> = {
  Rat: ['Intelligent', 'Adaptable', 'Quick-witted', 'Charming'],
  Ox: ['Diligent', 'Dependable', 'Strong', 'Determined'],
  Tiger: ['Brave', 'Confident', 'Competitive', 'Charismatic'],
  Rabbit: ['Gentle', 'Quiet', 'Elegant', 'Kind'],
  Dragon: ['Confident', 'Intelligent', 'Enthusiastic', 'Ambitious'],
  Snake: ['Wise', 'Enigmatic', 'Graceful', 'Intuitive'],
  Horse: ['Animated', 'Active', 'Energetic', 'Independent'],
  Goat: ['Calm', 'Gentle', 'Creative', 'Compassionate'],
  Monkey: ['Sharp', 'Smart', 'Curious', 'Playful'],
  Rooster: ['Observant', 'Hardworking', 'Courageous', 'Honest'],
  Dog: ['Loyal', 'Honest', 'Friendly', 'Faithful'],
  Pig: ['Compassionate', 'Generous', 'Diligent', 'Honest']
};

export function getYearData(year: number): YearData {
  const zodiacIndex = (year - 4) % 12;
  const elementIndex = (year - 4) % 10;
  const polarityIndex = (year - 4) % 2;
  
  const zodiac = zodiacCycle[zodiacIndex];
  const element = elementCycle[elementIndex];
  const polarity = polarityCycle[polarityIndex];
  
  return {
    year,
    zodiac,
    element,
    polarity,
    luckyColors: elementColors[element],
    luckyNumbers: [Math.floor(Math.random() * 9) + 1, Math.floor(Math.random() * 9) + 1],
    luckyDirections: ['North', 'South', 'East', 'West'].slice(0, 2),
    traits: zodiacTraits[zodiac],
    compatible: getCompatibleSigns(zodiac)
  };
}

function getCompatibleSigns(zodiac: string): string[] {
  const compatibility: Record<string, string[]> = {
    Rat: ['Dragon', 'Monkey', 'Ox'],
    Ox: ['Rat', 'Snake', 'Rooster'],
    Tiger: ['Horse', 'Dog', 'Pig'],
    Rabbit: ['Goat', 'Pig', 'Dog'],
    Dragon: ['Rat', 'Monkey', 'Rooster'],
    Snake: ['Ox', 'Rooster', 'Monkey'],
    Horse: ['Tiger', 'Goat', 'Dog'],
    Goat: ['Rabbit', 'Horse', 'Pig'],
    Monkey: ['Rat', 'Dragon', 'Snake'],
    Rooster: ['Ox', 'Snake', 'Dragon'],
    Dog: ['Tiger', 'Rabbit', 'Horse'],
    Pig: ['Rabbit', 'Goat', 'Tiger']
  };
  return compatibility[zodiac] || [];
}


// Kua Number Calculation
export function calculateKuaNumber(birthYear: number, gender: 'male' | 'female'): number {
  // Sum all digits of birth year
  const digits = birthYear.toString().split('').map(Number);
  let sum = digits.reduce((acc, digit) => acc + digit, 0);
  
  // If sum is two digits, sum again
  while (sum > 9) {
    sum = Math.floor(sum / 10) + (sum % 10);
  }
  
  if (gender === 'male') {
    const kua = 11 - sum;
    return kua === 5 ? 2 : kua;
  } else {
    const kua = sum + 4;
    return kua === 5 ? 8 : kua > 9 ? kua - 9 : kua;
  }
}


// Get favorable directions based on Kua number
export function getFavorableDirections(kuaNumber: number): {
  best: string[];
  good: string[];
  avoid: string[];
} {
  const eastGroup = [1, 3, 4, 9];
  const isEastGroup = eastGroup.includes(kuaNumber);
  
  const directionMap: Record<number, { best: string[]; good: string[]; avoid: string[] }> = {
    1: { best: ['Southeast', 'East'], good: ['South', 'North'], avoid: ['West', 'Northwest', 'Southwest', 'Northeast'] },
    2: { best: ['Northeast', 'West'], good: ['Northwest', 'Southwest'], avoid: ['East', 'Southeast', 'South', 'North'] },
    3: { best: ['South', 'North'], good: ['Southeast', 'East'], avoid: ['West', 'Northwest', 'Southwest', 'Northeast'] },
    4: { best: ['North', 'Southeast'], good: ['East', 'South'], avoid: ['West', 'Northwest', 'Southwest', 'Northeast'] },
    6: { best: ['West', 'Southwest'], good: ['Northeast', 'Northwest'], avoid: ['East', 'Southeast', 'South', 'North'] },
    7: { best: ['Northwest', 'Southwest'], good: ['West', 'Northeast'], avoid: ['East', 'Southeast', 'South', 'North'] },
    8: { best: ['Southwest', 'Northeast'], good: ['West', 'Northwest'], avoid: ['East', 'Southeast', 'South', 'North'] },
    9: { best: ['East', 'South'], good: ['North', 'Southeast'], avoid: ['West', 'Northwest', 'Southwest', 'Northeast'] }
  };
  
  return directionMap[kuaNumber] || directionMap[1];
}

// Get lucky colors based on element
export function getLuckyColorsByElement(element: string): {
  primary: string[];
  supporting: string[];
  avoid: string[];
} {
  const colorMap: Record<string, { primary: string[]; supporting: string[]; avoid: string[] }> = {
    Wood: { primary: ['Green', 'Teal', 'Brown'], supporting: ['Blue', 'Black'], avoid: ['White', 'Gold', 'Silver'] },
    Fire: { primary: ['Red', 'Orange', 'Purple', 'Pink'], supporting: ['Green', 'Brown'], avoid: ['Blue', 'Black'] },
    Earth: { primary: ['Yellow', 'Beige', 'Tan', 'Brown'], supporting: ['Red', 'Orange'], avoid: ['Green', 'Teal'] },
    Metal: { primary: ['White', 'Gold', 'Silver', 'Gray'], supporting: ['Yellow', 'Beige'], avoid: ['Red', 'Orange'] },
    Water: { primary: ['Blue', 'Black', 'Navy', 'Turquoise'], supporting: ['White', 'Silver'], avoid: ['Yellow', 'Brown'] }
  };
  
  return colorMap[element] || colorMap.Wood;
}

// Get lucky numbers based on element
export function getLuckyNumbers(element: string): number[] {
  const numberMap: Record<string, number[]> = {
    Wood: [3, 4, 8],
    Fire: [2, 7, 9],
    Earth: [2, 5, 8],
    Metal: [6, 7, 9],
    Water: [1, 6, 4]
  };
  
  return numberMap[element] || [1, 6, 8];
}

// Get room placement recommendations
export function getRoomPlacements(kuaNumber: number, dayMaster: string): {
  bedroom: string;
  office: string;
  kitchen: string;
  livingRoom: string;
  entrance: string;
} {
  const directions = getFavorableDirections(kuaNumber);
  
  return {
    bedroom: directions.best[0],
    office: directions.best[1] || directions.best[0],
    kitchen: directions.good[0] || directions.best[0],
    livingRoom: directions.good[1] || directions.good[0],
    entrance: directions.best[0]
  };
}

export interface FengShuiProfile {
  kuaNumber: number;
  group: 'East' | 'West';
  favorableDirections: ReturnType<typeof getFavorableDirections>;
  luckyColors: ReturnType<typeof getLuckyColorsByElement>;
  luckyNumbers: number[];
  roomPlacements: ReturnType<typeof getRoomPlacements>;
  bestSittingDirection: string;
  bestFacingDirection: string;
}

export function generateFengShuiProfile(
  birthYear: number,
  gender: 'male' | 'female',
  dayMaster: string
): FengShuiProfile {
  const kuaNumber = calculateKuaNumber(birthYear, gender);
  const eastGroup = [1, 3, 4, 9];
  const group = eastGroup.includes(kuaNumber) ? 'East' : 'West';
  const favorableDirections = getFavorableDirections(kuaNumber);
  const luckyColors = getLuckyColorsByElement(dayMaster);
  const luckyNumbers = getLuckyNumbers(dayMaster);
  const roomPlacements = getRoomPlacements(kuaNumber, dayMaster);
  
  return {
    kuaNumber,
    group,
    favorableDirections,
    luckyColors,
    luckyNumbers,
    roomPlacements,
    bestSittingDirection: favorableDirections.best[0],
    bestFacingDirection: favorableDirections.best[1] || favorableDirections.best[0]
  };
}
