// Period 1 Flying Stars Calculator (2044-2063)
// Period 1: Center 1, East 8, West 3, SE 9, South 5, SW 7, NW 2, North 6, NE 4

export interface Period1StarGrid {
  center: number;
  east: number;
  west: number;
  southeast: number;
  south: number;
  southwest: number;
  northwest: number;
  north: number;
  northeast: number;
}

export interface Period1StarData {
  sector: string;
  periodStar: number;
  annualStar: number;
  monthlyStar: number;
  direction: string;
}

const PERIOD_1_STARS: Period1StarGrid = {
  center: 1,
  east: 8,
  west: 3,
  southeast: 9,
  south: 5,
  southwest: 7,
  northwest: 2,
  north: 6,
  northeast: 4
};

function distributeStars(centerStar: number): number[] {
  const luoShuPositions = [4, 9, 2, 3, 5, 7, 8, 1, 6];
  return luoShuPositions.map(pos => {
    let star = centerStar + (pos - 5);
    while (star <= 0) star += 9;
    while (star > 9) star -= 9;
    return star;
  });
}

function getAnnualCenterStar(year: number): number {
  let centerStar = 2 - (year - 2025);
  while (centerStar <= 0) centerStar += 9;
  while (centerStar > 9) centerStar -= 9;
  return centerStar;
}

function getMonthlyCenterStar(year: number, month: number): number {
  const yearDiff = year - 2025;
  const monthDiff = month - 9;
  let centerStar = 3 - monthDiff - (yearDiff * 9);
  while (centerStar <= 0) centerStar += 9;
  while (centerStar > 9) centerStar -= 9;
  return centerStar;
}

export function calculatePeriod1StarGrid(year: number, month: number): Period1StarData[] {
  const periodStars = [9, 5, 7, 8, 1, 3, 4, 6, 2]; // SE, S, SW, E, Center, W, NE, N, NW
  const annualCenter = getAnnualCenterStar(year);
  const monthlyCenter = getMonthlyCenterStar(year, month);
  const annualStars = distributeStars(annualCenter);
  const monthlyStars = distributeStars(monthlyCenter);
  const directions = ['SE', 'S', 'SW', 'E', 'Center', 'W', 'NE', 'N', 'NW'];
  
  return directions.map((dir, i) => ({
    sector: dir,
    periodStar: periodStars[i],
    annualStar: annualStars[i],
    monthlyStar: monthlyStars[i],
    direction: dir
  }));
}

export function isPeriod1Active(year: number, month: number): boolean {
  if (year < 2044) return false;
  if (year > 2063) return false;
  if (year === 2044 && month < 2) return false;
  if (year === 2063 && month > 2) return false;
  if (year === 2063 && month === 2) return true;
  return true;
}
