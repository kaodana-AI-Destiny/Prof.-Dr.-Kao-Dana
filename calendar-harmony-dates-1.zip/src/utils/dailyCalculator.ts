import { heavenlyStems } from "./baziCalculator";

export interface DailyData {
  zodiacIndex: number;
  element: string;
  elementType: string;
  polarity: string;
  date: Date;
  khmerElement: string;
  hNumber: string;
  chineseChar: string;
}


// Base reference: October 20, 2025 = Dog (index 2), Water Yang (Ren)
const baseDate = new Date(2025, 9, 20); // Month is 0-indexed (9 = October)
const baseZodiacIndex = 2; // Dog
const baseStemIndex = 8; // Water Yang (Ren 壬)

export function calculateDailyData(date: Date = new Date()): DailyData {
  // Calculate days since base date
  const daysDiff = Math.floor((date.getTime() - baseDate.getTime()) / (1000 * 60 * 60 * 24));
  
  // Zodiac: 12-day cycle
  const zodiacIndex = ((baseZodiacIndex + daysDiff) % 12 + 12) % 12;
  
  // Element: 10-day cycle using heavenly stems
  const stemIndex = ((baseStemIndex + daysDiff) % 10 + 10) % 10;
  const stem = heavenlyStems[stemIndex];
  
  return {
    zodiacIndex,
    element: stem.element,
    elementType: stem.polarity,
    polarity: stem.polarity,
    date,
    khmerElement: stem.khmerElement,
    hNumber: stem.hNumber,
    chineseChar: stem.chinese
  };
}
