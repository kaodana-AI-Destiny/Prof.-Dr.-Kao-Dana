import { heavenlyStems } from "./baziCalculator";

export interface MonthData {
  monthNumber: number;
  monthName: string;
  zodiacIndex: number;
  zodiacName: string;
  element: string;
  polarity: string;
  khmerElement: string;
  hNumber: string;
  chineseChar: string;
}


const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

// Zodiac cycle starting from Dog (index 2 in zodiacData.ts)
// Order: Dog(2), Pig(3), Rat(4), Ox(5), Tiger(6), Rabbit(7), Dragon(8), Snake(9), Horse(10), Goat(11), Monkey(0), Rooster(1)
const zodiacCycle = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 0, 1];
const zodiacNames = ["Dog", "Pig", "Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster"];

// Element cycle: Fire Yang, Fire Yin, Earth Yang, Earth Yin, Metal Yang, Metal Yin, Water Yang, Water Yin, Wood Yang, Wood Yin (repeats every 10)
const elementCycle = [
  { element: "Fire", polarity: "Yang" },
  { element: "Fire", polarity: "Yin" },
  { element: "Earth", polarity: "Yang" },
  { element: "Earth", polarity: "Yin" },
  { element: "Metal", polarity: "Yang" },
  { element: "Metal", polarity: "Yin" },
  { element: "Water", polarity: "Yang" },
  { element: "Water", polarity: "Yin" },
  { element: "Wood", polarity: "Yang" },
  { element: "Wood", polarity: "Yin" }
];
// Reference point: October 2025 = Dog Fire Yang (Bing Xu 丙戌)
// Bing is at index 2 in heavenlyStems
const REFERENCE_YEAR = 2025;
const REFERENCE_MONTH = 10;
const REFERENCE_STEM_INDEX = 2; // Bing (Fire Yang)


export function calculateMonthData(year: number, monthNumber: number): MonthData {
  // Calculate months elapsed since October 2025
  const monthsElapsed = (year - REFERENCE_YEAR) * 12 + (monthNumber - REFERENCE_MONTH);
  
  // Get zodiac (cycles every 12 months)
  const cyclePosition = ((monthsElapsed % 12) + 12) % 12;
  const zodiacIndex = zodiacCycle[cyclePosition];
  
  // Get element (cycles every 10 months) - this determines the heavenly stem
  // Add REFERENCE_STEM_INDEX to align with October 2025 = Bing (Fire Yang)
  const stemIndex = ((REFERENCE_STEM_INDEX + monthsElapsed) % 10 + 10) % 10;
  const stem = heavenlyStems[stemIndex];

  
  return {
    monthNumber,
    monthName: monthNames[monthNumber - 1],
    zodiacIndex,
    zodiacName: zodiacNames[cyclePosition],
    element: stem.element,
    polarity: stem.polarity,
    khmerElement: stem.khmerElement,
    hNumber: stem.hNumber,
    chineseChar: stem.chinese
  };
}


export function generateYearMonths(year: number): MonthData[] {
  return Array.from({ length: 12 }, (_, i) => calculateMonthData(year, i + 1));
}
