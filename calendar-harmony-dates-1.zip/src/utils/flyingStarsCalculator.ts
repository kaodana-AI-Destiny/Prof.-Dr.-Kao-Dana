import { periods } from '../data/flyingStarsData';

export interface FlyingStarCell {
  mountain: number;
  water: number;
  period: number;
  sector: string;
}

export function getPeriod(year: number): number {
  const period = periods.find(p => year >= p.startYear && year <= p.endYear);
  return period ? period.period : 9; // Default to period 9
}

export function calculateFlyingStars(constructionYear: number, facing: string): FlyingStarCell[][] {
  const period = getPeriod(constructionYear);
  
  // Base pattern for Period 8 facing South (example)
  // This is simplified - full implementation would have all 24 mountain patterns
  const basePattern: FlyingStarCell[][] = [
    [
      { mountain: 6, water: 2, period: 4, sector: "SE" },
      { mountain: 2, water: 6, period: 9, sector: "S" },
      { mountain: 4, water: 8, period: 2, sector: "SW" }
    ],
    [
      { mountain: 5, water: 3, period: 3, sector: "E" },
      { mountain: 7, water: 1, period: 5, sector: "Center" },
      { mountain: 9, water: 5, period: 7, sector: "W" }
    ],
    [
      { mountain: 1, water: 7, period: 8, sector: "NE" },
      { mountain: 3, water: 9, period: 1, sector: "N" },
      { mountain: 8, water: 4, period: 6, sector: "NW" }
    ]
  ];
  
  return basePattern;
}

export function getRecommendation(mountain: number, water: number, period: number): string {
  if (period === 8 && water === 8) return "Excellent wealth sector! Place water feature here.";
  if (period === 8 && mountain === 8) return "Great for health and relationships. Good for bedroom.";
  if (water === 5 || mountain === 5) return "Caution: Five Yellow present. Use metal cure.";
  if (water === 2 || mountain === 2) return "Illness star present. Avoid spending too much time here.";
  if (water === 7 && period === 8) return "Robbery star. Keep this area quiet and secure.";
  return "Neutral sector. General use is fine.";
}
