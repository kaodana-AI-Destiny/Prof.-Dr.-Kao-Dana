import { heavenlyStems } from "./baziCalculator";

export interface YearData {
  year: number;
  zodiacIndex: number;
  element: string;
  elementType: string;
  polarity: string;
  khmerElement: string;
  hNumber: string;
  chineseChar: string;
}


// Base reference: 1924 = Jia Zi (甲子) - Wood Yang Rat
// This aligns with the traditional 60-year Sexagenary cycle
const baseYear = 1924;

// Element order in 10-year cycle: Metal, Water, Wood, Fire, Earth (each for 2 years)
const elements = ["Metal", "Water", "Wood", "Fire", "Earth"];

// Zodiac animals in 12-year cycle starting with Rat (matching earthlyBranches order)
// Index matches earthlyBranches: 0=Rat, 1=Ox, 2=Tiger, 3=Rabbit, 4=Dragon, 5=Snake, 6=Horse, 7=Goat, 8=Monkey, 9=Rooster, 10=Dog, 11=Pig
const zodiacAnimals = ["Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig"];

export function calculateYearData(year: number): YearData {
  // Zodiac: 12-year cycle starting with Rat in 1924
  // earthlyBranches order: Rat(0), Ox(1), Tiger(2), Rabbit(3), Dragon(4), Snake(5), Horse(6), Goat(7), Monkey(8), Rooster(9), Dog(10), Pig(11)
  const earthlyBranchIndex = ((year - baseYear) % 12 + 12) % 12;
  
  // Map earthlyBranches index to zodiacData.ts index
  // zodiacData order: Monkey(0), Rooster(1), Dog(2), Pig(3), Rat(4), Ox(5), Tiger(6), Rabbit(7), Dragon(8), Snake(9), Horse(10), Goat(11)
  const zodiacIndex = (earthlyBranchIndex + 4) % 12;
  
  // Element: 10-year cycle using heavenly stems
  const stemIndex = ((year - baseYear) % 10 + 10) % 10;
  const stem = heavenlyStems[stemIndex];

  return {
    year,
    zodiacIndex,
    element: stem.element,
    elementType: stem.polarity,
    polarity: stem.polarity,
    khmerElement: stem.khmerElement,
    hNumber: stem.hNumber,
    chineseChar: stem.chinese
  };
}


export function generateYearsData(startYear: number, endYear: number): YearData[] {
  const years: YearData[] = [];
  for (let year = startYear; year <= endYear; year++) {
    years.push(calculateYearData(year));
  }
  return years;
}
