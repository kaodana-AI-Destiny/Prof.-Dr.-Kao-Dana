// Auxiliary Stars Calculator for BaZi
export interface AuxiliaryStar {
  name: string;
  chineseName: string;
  pillar: string;
  description: string;
  type: 'auspicious' | 'inauspicious' | 'neutral';
}

const heavenlyStems = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const earthlyBranches = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// Noble Person (天乙貴人) based on Day Stem
const noblePerson: Record<string, string[]> = {
  '甲': ['丑', '未'], '乙': ['申', '子'], '丙': ['酉', '亥'], '丁': ['酉', '亥'],
  '戊': ['丑', '未'], '己': ['申', '子'], '庚': ['丑', '未'], '辛': ['寅', '午'],
  '壬': ['卯', '巳'], '癸': ['卯', '巳']
};

// Peach Blossom (桃花) based on Year/Day Branch
const peachBlossom: Record<string, string> = {
  '子': '酉', '丑': '午', '寅': '卯', '卯': '子', '辰': '酉', '巳': '午',
  '午': '卯', '未': '子', '申': '酉', '酉': '午', '戌': '卯', '亥': '子'
};

// Academic Star (文昌) based on Day Stem
const academicStar: Record<string, string> = {
  '甲': '巳', '乙': '午', '丙': '申', '丁': '酉', '戊': '申',
  '己': '酉', '庚': '亥', '辛': '子', '壬': '寅', '癸': '卯'
};

// Traveling Horse (驛馬) based on Year/Day Branch
const travelingHorse: Record<string, string> = {
  '子': '寅', '丑': '亥', '寅': '申', '卯': '巳', '辰': '寅', '巳': '亥',
  '午': '申', '未': '巳', '申': '寅', '酉': '亥', '戌': '申', '亥': '巳'
};

export function calculateAuxiliaryStars(
  yearStem: string, yearBranch: string,
  monthStem: string, monthBranch: string,
  dayStem: string, dayBranch: string,
  hourStem: string, hourBranch: string
): AuxiliaryStar[] {
  const stars: AuxiliaryStar[] = [];
  const pillars = [
    { stem: yearStem, branch: yearBranch, name: 'Year' },
    { stem: monthStem, branch: monthBranch, name: 'Month' },
    { stem: dayStem, branch: dayBranch, name: 'Day' },
    { stem: hourStem, branch: hourBranch, name: 'Hour' }
  ];

  // Check Noble Person
  const noblePersonBranches = noblePerson[dayStem] || [];
  pillars.forEach(pillar => {
    if (noblePersonBranches.includes(pillar.branch)) {
      stars.push({
        name: 'Noble Person',
        chineseName: '天乙貴人',
        pillar: pillar.name,
        description: 'Brings helpful people and opportunities',
        type: 'auspicious'
      });
    }
  });

  // Check Peach Blossom
  const peachBlossomBranch = peachBlossom[dayBranch];
  pillars.forEach(pillar => {
    if (pillar.branch === peachBlossomBranch) {
      stars.push({
        name: 'Peach Blossom',
        chineseName: '桃花',
        pillar: pillar.name,
        description: 'Enhances charm and relationships',
        type: 'neutral'
      });
    }
  });

  // Check Academic Star
  const academicStarBranch = academicStar[dayStem];
  pillars.forEach(pillar => {
    if (pillar.branch === academicStarBranch) {
      stars.push({
        name: 'Academic Star',
        chineseName: '文昌',
        pillar: pillar.name,
        description: 'Favors learning and intelligence',
        type: 'auspicious'
      });
    }
  });

  // Check Traveling Horse
  const travelingHorseBranch = travelingHorse[dayBranch];
  pillars.forEach(pillar => {
    if (pillar.branch === travelingHorseBranch) {
      stars.push({
        name: 'Traveling Horse',
        chineseName: '驛馬',
        pillar: pillar.name,
        description: 'Indicates movement and travel',
        type: 'neutral'
      });
    }
  });

  return stars;
}
