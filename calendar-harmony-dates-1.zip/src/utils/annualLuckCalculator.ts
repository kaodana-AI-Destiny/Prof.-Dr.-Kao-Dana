// Annual Luck (流年 - Liu Nian) Calculator
const heavenlyStems = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const earthlyBranches = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
const stemElements = ['Wood', 'Wood', 'Fire', 'Fire', 'Earth', 'Earth', 'Metal', 'Metal', 'Water', 'Water'];
const branchElements = ['Water', 'Earth', 'Wood', 'Wood', 'Earth', 'Fire', 'Fire', 'Earth', 'Metal', 'Metal', 'Earth', 'Water'];
const stemPolarity = ['Yang', 'Yin', 'Yang', 'Yin', 'Yang', 'Yin', 'Yang', 'Yin', 'Yang', 'Yin'];
const stemEnglish = ['Jia', 'Yi', 'Bing', 'Ding', 'Wu', 'Ji', 'Geng', 'Xin', 'Ren', 'Gui'];
const stemKhmer = ['ជា', 'យី', 'ប៊ីង', 'ឌីង', 'វូ', 'ជី', 'ហ្គេង', 'ស៊ីន', 'រេន', 'គុយ'];
const branchEnglish = ['Zi', 'Chou', 'Yin', 'Mao', 'Chen', 'Si', 'Wu', 'Wei', 'Shen', 'You', 'Xu', 'Hai'];
const branchKhmer = ['ជ្រូ', 'គោ', 'ខ្លា', 'ទន្សាយ', 'នាគ', 'ពស់', 'សេះ', 'ពពែ', 'ស្វា', 'មាន់', 'ឆ្កែ', 'ជ្រូក'];

export interface AnnualLuck {
  year: number;
  stem: string;
  branch: string;
  stemChinese: string;
  branchChinese: string;
  stemEnglish: string;
  branchEnglish: string;
  stemKhmer: string;
  branchKhmer: string;
  element: string;
  polarity: string;
  interactions: string[];
  fortuneLevel: 'excellent' | 'good' | 'neutral' | 'challenging' | 'difficult';
  predictions: {
    career: string;
    wealth: string;
    relationships: string;
    health: string;
  };
  significantEvents: string[];
}


export function getYearPillar(year: number): { stem: string; branch: string; stemChinese: string; branchChinese: string } {
  const stemIndex = (year - 4) % 10;
  const branchIndex = (year - 4) % 12;
  return {
    stem: stemElements[stemIndex],
    branch: branchElements[branchIndex],
    stemChinese: heavenlyStems[stemIndex],
    branchChinese: earthlyBranches[branchIndex]
  };
}

function detectClashesAndHarmonies(yearBranch: string, birthChart: any, luckPillar: any): string[] {
  const interactions: string[] = [];
  const branchIndex = earthlyBranches.indexOf(yearBranch);
  
  // Check clash (opposite branches)
  const clashIndex = (branchIndex + 6) % 12;
  if (birthChart.dayBranch === earthlyBranches[clashIndex]) {
    interactions.push('⚠️ Clash with Day Branch - Major life changes');
  }
  
  // Check harmony (trine - 120 degrees)
  const trine1 = (branchIndex + 4) % 12;
  const trine2 = (branchIndex + 8) % 12;
  if (birthChart.dayBranch === earthlyBranches[trine1] || birthChart.dayBranch === earthlyBranches[trine2]) {
    interactions.push('✨ Trine harmony - Smooth progress');
  }
  
  return interactions;
}

export function calculateAnnualLuck(birthYear: number, birthChart: any, currentLuckPillar: any, startYear: number, numYears: number = 10): AnnualLuck[] {
  const annualLucks: AnnualLuck[] = [];
  
  for (let i = 0; i < numYears; i++) {
    const year = startYear + i;
    const stemIndex = (year - 4) % 10;
    const branchIndex = (year - 4) % 12;
    const pillar = getYearPillar(year);
    const interactions = detectClashesAndHarmonies(pillar.branchChinese, birthChart, currentLuckPillar);
    
    // Calculate fortune level based on element interactions
    const fortuneLevel = calculateFortuneLevel(pillar, birthChart, currentLuckPillar);
    
    annualLucks.push({
      year,
      stem: pillar.stem,
      branch: pillar.branch,
      stemChinese: pillar.stemChinese,
      branchChinese: pillar.branchChinese,
      stemEnglish: stemEnglish[stemIndex],
      branchEnglish: branchEnglish[branchIndex],
      stemKhmer: stemKhmer[stemIndex],
      branchKhmer: branchKhmer[branchIndex],
      element: pillar.stem,
      polarity: stemPolarity[stemIndex],
      interactions,
      fortuneLevel,
      predictions: generatePredictions(fortuneLevel, pillar, birthChart),
      significantEvents: interactions.length > 0 ? interactions : []
    });
  }
  
  return annualLucks;
}


function calculateFortuneLevel(yearPillar: any, birthChart: any, luckPillar: any): 'excellent' | 'good' | 'neutral' | 'challenging' | 'difficult' {
  const dayElement = birthChart.dayStem;
  const yearElement = yearPillar.stem;
  
  // Simplified fortune calculation based on element relationships
  if (isProducingCycle(yearElement, dayElement)) return 'excellent';
  if (yearElement === dayElement) return 'good';
  if (isControllingCycle(dayElement, yearElement)) return 'good';
  if (isControllingCycle(yearElement, dayElement)) return 'challenging';
  return 'neutral';
}

function isProducingCycle(producer: string, receiver: string): boolean {
  const cycles: Record<string, string> = {
    'Wood': 'Fire', 'Fire': 'Earth', 'Earth': 'Metal', 'Metal': 'Water', 'Water': 'Wood'
  };
  return cycles[producer] === receiver;
}

function isControllingCycle(controller: string, controlled: string): boolean {
  const cycles: Record<string, string> = {
    'Wood': 'Earth', 'Earth': 'Water', 'Water': 'Fire', 'Fire': 'Metal', 'Metal': 'Wood'
  };
  return cycles[controller] === controlled;
}

function generatePredictions(fortuneLevel: string, yearPillar: any, birthChart: any): any {
  const predictions: Record<string, any> = {
    excellent: {
      career: 'Excellent opportunities for advancement and recognition',
      wealth: 'Strong financial growth and profitable investments',
      relationships: 'Harmonious connections and potential new partnerships',
      health: 'Vibrant energy and good overall health'
    },
    good: {
      career: 'Steady progress with supportive colleagues',
      wealth: 'Stable income with moderate gains',
      relationships: 'Positive interactions and deepening bonds',
      health: 'Good vitality with minor attention needed'
    },
    neutral: {
      career: 'Maintain current position, focus on skills',
      wealth: 'Balanced finances, avoid major risks',
      relationships: 'Stable connections, communication key',
      health: 'Maintain wellness routines'
    },
    challenging: {
      career: 'Face obstacles with patience and strategy',
      wealth: 'Conservative approach recommended',
      relationships: 'Requires extra effort and understanding',
      health: 'Pay attention to stress and rest'
    },
    difficult: {
      career: 'Significant challenges, seek guidance',
      wealth: 'Avoid major investments, protect assets',
      relationships: 'Navigate conflicts with care',
      health: 'Prioritize self-care and prevention'
    }
  };
  
  return predictions[fortuneLevel] || predictions.neutral;
}
