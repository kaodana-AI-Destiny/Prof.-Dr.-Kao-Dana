import { heavenlyStems, earthlyBranches } from "./baziCalculator";

export interface ChineseYear {
  year: number;
  animal: string;
  chineseChar: string;
  element: string;
  polarity: string;
}

export interface ChineseMonth {
  animal: string;
  chineseChar: string;
  element: string;
  polarity: string;
}

// Get the earthly branch (animal) for a given month
function getMonthBranch(date: Date): number {
  const month = date.getMonth() + 1;
  const day = date.getDate();

  // Solar terms determine Chinese months
  if ((month === 2 && day >= 4) || (month === 3 && day <= 5)) return 2; // Tiger
  if ((month === 3 && day >= 6) || (month === 4 && day <= 4)) return 3; // Rabbit
  if ((month === 4 && day >= 5) || (month === 5 && day <= 5)) return 4; // Dragon
  if ((month === 5 && day >= 6) || (month === 6 && day <= 5)) return 5; // Snake
  if ((month === 6 && day >= 6) || (month === 7 && day <= 6)) return 6; // Horse
  if ((month === 7 && day >= 7) || (month === 8 && day <= 7)) return 7; // Goat
  if ((month === 8 && day >= 8) || (month === 9 && day <= 7)) return 8; // Monkey
  if ((month === 9 && day >= 8) || (month === 10 && day <= 7)) return 9; // Rooster
  if ((month === 10 && day >= 8) || (month === 11 && day <= 6)) return 10; // Dog
  if ((month === 11 && day >= 7) || (month === 12 && day <= 6)) return 11; // Pig
  if (month === 12 && day >= 7) return 0; // Rat
  if (month === 1 && day <= 5) return 0; // Rat
  if ((month === 1 && day >= 6) || (month === 2 && day <= 3)) return 1; // Ox

  return 2; // Default to Tiger
}

export function getChineseMonth(date: Date): ChineseMonth {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  // Get year stem for calculating month stem
  let chineseYear = year;
  if (month === 1 || (month === 2 && day < 4)) {
    chineseYear = year - 1;
  }
  
  const yearStemIndex = ((chineseYear - 1924) % 10 + 10) % 10;
  const monthBranchIndex = getMonthBranch(date);
  
  // Five Tigers formula: Calculate month stem based on year stem
  const fiveTigersBase = [2, 4, 6, 8, 0]; // Bing, Wu, Geng, Ren, Jia for Tiger month
  const yearStemGroup = Math.floor(yearStemIndex / 2);
  const firstMonthStem = fiveTigersBase[yearStemGroup];
  const monthStemIndex = (firstMonthStem + (monthBranchIndex - 2 + 12)) % 10;
  
  const monthStem = heavenlyStems[monthStemIndex];
  const monthBranch = earthlyBranches[monthBranchIndex];
  
  return {
    animal: monthBranch.animal,
    chineseChar: monthBranch.chinese,
    element: monthStem.element,
    polarity: monthStem.polarity
  };
}

const yearAnimals = [
  { animal: 'Monkey', chineseChar: '申', element: 'Metal', polarity: 'Yang' },
  { animal: 'Rooster', chineseChar: '酉', element: 'Metal', polarity: 'Yin' },
  { animal: 'Dog', chineseChar: '戌', element: 'Earth', polarity: 'Yang' },
  { animal: 'Pig', chineseChar: '亥', element: 'Water', polarity: 'Yin' },
  { animal: 'Rat', chineseChar: '子', element: 'Water', polarity: 'Yang' },
  { animal: 'Ox', chineseChar: '丑', element: 'Earth', polarity: 'Yin' },
  { animal: 'Tiger', chineseChar: '寅', element: 'Wood', polarity: 'Yang' },
  { animal: 'Rabbit', chineseChar: '卯', element: 'Wood', polarity: 'Yin' },
  { animal: 'Dragon', chineseChar: '辰', element: 'Earth', polarity: 'Yang' },
  { animal: 'Snake', chineseChar: '巳', element: 'Fire', polarity: 'Yin' },
  { animal: 'Horse', chineseChar: '午', element: 'Fire', polarity: 'Yang' },
  { animal: 'Goat', chineseChar: '未', element: 'Earth', polarity: 'Yin' }
];

export function getChineseYear(date: Date): ChineseYear {
  const month = date.getMonth() + 1;
  const day = date.getDate();
  let year = date.getFullYear();
  
  // Before Feb 4, use previous year
  if (month === 1 || (month === 2 && day < 4)) {
    year = year - 1;
  }
  
  const zodiacIndex = (year - 4) % 12;
  const yearData = yearAnimals[zodiacIndex];
  
  return {
    year,
    ...yearData
  };
}
