// Dong Kong (動空/Moving Void) Calculator
export interface DongKongDate {
  date: string;
  stem: string;
  branch: string;
  voidBranches: string[];
  description: string;
  suitable: string[];
  unsuitable: string[];
}

const heavenlyStems = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const earthlyBranches = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// Kong Wang (空亡/Void) pairs based on 60 Jia Zi cycle
const voidPairs: Record<string, string[]> = {
  '甲子': ['戌', '亥'], '甲戌': ['申', '酉'], '甲申': ['午', '未'],
  '甲午': ['辰', '巳'], '甲辰': ['寅', '卯'], '甲寅': ['子', '丑'],
  '乙丑': ['戌', '亥'], '乙亥': ['申', '酉'], '乙酉': ['午', '未'],
  '乙未': ['辰', '巳'], '乙巳': ['寅', '卯'], '乙卯': ['子', '丑'],
  '丙寅': ['戌', '亥'], '丙子': ['申', '酉'], '丙戌': ['午', '未'],
  '丙申': ['辰', '巳'], '丙午': ['寅', '卯'], '丙辰': ['子', '丑'],
  '丁卯': ['戌', '亥'], '丁丑': ['申', '酉'], '丁亥': ['午', '未'],
  '丁酉': ['辰', '巳'], '丁未': ['寅', '卯'], '丁巳': ['子', '丑'],
  '戊辰': ['戌', '亥'], '戊寅': ['申', '酉'], '戊子': ['午', '未'],
  '戊戌': ['辰', '巳'], '戊申': ['寅', '卯'], '戊午': ['子', '丑'],
  '己巳': ['戌', '亥'], '己卯': ['申', '酉'], '己丑': ['午', '未'],
  '己亥': ['辰', '巳'], '己酉': ['寅', '卯'], '己未': ['子', '丑'],
  '庚午': ['戌', '亥'], '庚辰': ['申', '酉'], '庚寅': ['午', '未'],
  '庚子': ['辰', '巳'], '庚戌': ['寅', '卯'], '庚申': ['子', '丑'],
  '辛未': ['戌', '亥'], '辛巳': ['申', '酉'], '辛卯': ['午', '未'],
  '辛丑': ['辰', '巳'], '辛亥': ['寅', '卯'], '辛酉': ['子', '丑'],
  '壬申': ['戌', '亥'], '壬午': ['申', '酉'], '壬辰': ['午', '未'],
  '壬寅': ['辰', '巳'], '壬子': ['寅', '卯'], '壬戌': ['子', '丑'],
  '癸酉': ['戌', '亥'], '癸未': ['申', '酉'], '癸巳': ['午', '未'],
  '癸卯': ['辰', '巳'], '癸丑': ['寅', '卯'], '癸亥': ['子', '丑']
};

export function calculateDongKongDates(dayStem: string, dayBranch: string): DongKongDate[] {
  const dates: DongKongDate[] = [];
  const dayPillar = dayStem + dayBranch;
  
  const voidBranches = voidPairs[dayPillar] || ['戌', '亥'];
  
  // Generate sample dates for the next 10 days
  const today = new Date();
  for (let i = 0; i < 10; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    
    const stemIndex = (heavenlyStems.indexOf(dayStem) + i) % 10;
    const branchIndex = (earthlyBranches.indexOf(dayBranch) + i) % 12;
    
    const stem = heavenlyStems[stemIndex];
    const branch = earthlyBranches[branchIndex];
    const pillar = stem + branch;
    const currentVoid = voidPairs[pillar] || voidBranches;
    
    dates.push({
      date: date.toLocaleDateString('en-CA'),
      stem,
      branch,
      voidBranches: currentVoid,
      description: `Void: ${currentVoid.join(', ')}`,
      suitable: ['Meditation', 'Planning', 'Study'],
      unsuitable: ['Major decisions', 'Signing contracts', 'Starting projects']
    });
  }
  
  return dates;
}
