// Monthly Flying Stars Calculator for Period 9 (2024-2043), Period 1 (2044-2063), Period 2 (2064-2083)

export interface MonthlyStarData {
  sector: string;
  periodStar: number;
  annualStar: number;
  monthlyStar: number;
  direction: string;
  favorability: 'excellent' | 'good' | 'neutral' | 'poor' | 'bad';
  activities: string[];
}


// Solar month date ranges
const solarMonthRanges: [number, number, number, number][] = [
  [4, 2, 5, 3], [6, 3, 4, 4], [5, 4, 5, 5], [6, 5, 5, 6],
  [6, 6, 6, 7], [7, 7, 7, 8], [8, 8, 7, 9], [8, 9, 7, 10],
  [8, 10, 6, 11], [7, 11, 6, 12], [7, 12, 5, 1], [6, 1, 3, 2]
];

function getSolarMonth(year: number, month: number, day: number): number {
  for (let i = 0; i < solarMonthRanges.length; i++) {
    const [startDay, startMonth, endDay, endMonth] = solarMonthRanges[i];
    if (startMonth === endMonth) {
      if (month === startMonth && day >= startDay && day <= endDay) return i + 1;
    } else if (startMonth < endMonth) {
      if ((month === startMonth && day >= startDay) || (month === endMonth && day <= endDay)) return i + 1;
    } else {
      if ((month === startMonth && day >= startDay) || (month === endMonth && day <= endDay)) return i + 1;
    }
  }
  return 1;
}

export function getAnnualCenterStar(year: number, month: number, day: number): number {
  let effectiveYear = year;
  if (month < 2 || (month === 2 && day < 4)) effectiveYear--;
  let centerStar = 2 - (effectiveYear - 2025);
  while (centerStar <= 0) centerStar += 9;
  while (centerStar > 9) centerStar -= 9;
  return centerStar;
}

export function getMonthlyCenterStar(year: number, month: number, day: number = 15): number {
  const solarMonth = getSolarMonth(year, month, day);
  let effectiveYear = year;
  if (month < 2 || (month === 2 && day < 4)) effectiveYear--;
  const yearDiff = effectiveYear - 2025;
  const monthDiff = solarMonth - 9;
  let centerStar = 3 - monthDiff - (yearDiff * 9);
  while (centerStar <= 0) centerStar += 9;
  while (centerStar > 9) centerStar -= 9;
  return centerStar;
}

function distributeStars(centerStar: number): number[] {
  const luoShuPositions = [4, 9, 2, 3, 5, 7, 8, 1, 6];
  return luoShuPositions.map(pos => {
    let star = centerStar + (pos - 5);
    while (star <= 0) star += 9;
    while (star > 9) star -= 9;
    return star;
  });
}

// Get period stars based on year (grid order: SE, S, SW, E, Center, W, NE, N, NW)
function getPeriodStars(year: number, month: number, day: number): number[] {
  let effectiveYear = year;
  if (month < 2 || (month === 2 && day < 4)) effectiveYear--;
  
  // Period 9: 2024-2043, Period 1: 2044-2063, Period 2: 2064-2083
  if (effectiveYear >= 2024 && effectiveYear <= 2043) {
    return [8, 4, 6, 7, 9, 2, 3, 5, 1]; // Period 9
  } else if (effectiveYear >= 2044 && effectiveYear <= 2063) {
    return [9, 5, 7, 8, 1, 3, 4, 6, 2]; // Period 1
  } else if (effectiveYear >= 2064 && effectiveYear <= 2083) {
    return [1, 6, 8, 9, 2, 4, 5, 7, 3]; // Period 2
  }
  return [8, 4, 6, 7, 9, 2, 3, 5, 1]; // Default to Period 9
}

export function calculateMonthlyFlyingStars(year: number, month: number, day: number = 15): MonthlyStarData[] {
  const periodStars = getPeriodStars(year, month, day);
  const annualCenter = getAnnualCenterStar(year, month, day);
  const monthlyCenter = getMonthlyCenterStar(year, month, day);
  const annualStars = distributeStars(annualCenter);
  const monthlyStars = distributeStars(monthlyCenter);
  const directions = ['SE', 'S', 'SW', 'E', 'Center', 'W', 'NE', 'N', 'NW'];
  
  return directions.map((dir, i) => ({
    sector: dir,
    periodStar: periodStars[i],
    annualStar: annualStars[i],
    monthlyStar: monthlyStars[i],
    direction: dir,
    favorability: analyzeCombination(annualStars[i], monthlyStars[i]),
    activities: getActivities(annualStars[i], monthlyStars[i])
  }));
}


function analyzeCombination(annual: number, monthly: number): 'excellent' | 'good' | 'neutral' | 'poor' | 'bad' {
  const sum = annual + monthly;
  if ((annual === 8 && monthly === 9) || (annual === 9 && monthly === 8)) return 'excellent';
  if ((annual === 1 && monthly === 6) || (annual === 6 && monthly === 1)) return 'excellent';
  if (sum === 10 || sum === 15) return 'excellent';
  if ([1, 6, 8, 9].includes(annual) && [1, 6, 8, 9].includes(monthly)) return 'good';
  if ((annual === 2 && monthly === 5) || (annual === 5 && monthly === 2)) return 'bad';
  if ([2, 3, 5, 7].includes(annual) && [2, 3, 5, 7].includes(monthly)) return 'bad';
  return 'neutral';
}

function getActivities(annual: number, monthly: number): string[] {
  const activities: string[] = [];
  if ([8, 9].includes(annual) || [8, 9].includes(monthly)) activities.push('Wealth');
  if ([1, 6].includes(annual) && [1, 6].includes(monthly)) activities.push('Career', 'Relationships');
  if (annual === 4 || monthly === 4) activities.push('Education', 'Creativity');
  if (annual === 1 || monthly === 1) activities.push('Career', 'Health');
  if (annual === 6 || monthly === 6) activities.push('Authority', 'Leadership');
  return activities.length > 0 ? activities : ['General'];
}
