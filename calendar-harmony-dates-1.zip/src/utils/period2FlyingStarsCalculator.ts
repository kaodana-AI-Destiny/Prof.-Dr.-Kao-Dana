// Period 2 Flying Stars Calculator (2064-2083)
// Period 2: Center 2, East 9, West 4, SE 1, South 6, SW 8, NW 3, North 7, NE 5

export interface Period2StarGrid {
  center: number;
  east: number;
  west: number;
  southeast: number;
  south: number;
  southwest: number;
  northwest: number;
  north: number;
  northeast: number;
}

export interface Period2StarData {
  sector: string;
  periodStar: number;
  annualStar: number;
  monthlyStar: number;
  direction: string;
}

const PERIOD_2_STARS: Period2StarGrid = {
  center: 2,
  east: 9,
  west: 4,
  southeast: 1,
  south: 6,
  southwest: 8,
  northwest: 3,
  north: 7,
  northeast: 5
};

function distributeStars(centerStar: number): number[] {
  const luoShuPositions = [4, 9, 2, 3, 5, 7, 8, 1, 6];
  return luoShuPositions.map(pos => {
    let star = centerStar + (pos - 5);
    while (star <= 0) star += 9;
    while (star > 9) star -= 9;
    return star;
  });
}

function getAnnualCenterStar(year: number): number {
  let centerStar = 2 - (year - 2025);
  while (centerStar <= 0) centerStar += 9;
  while (centerStar > 9) centerStar -= 9;
  return centerStar;
}

function getMonthlyCenterStar(year: number, month: number): number {
  const yearDiff = year - 2025;
  const monthDiff = month - 9;
  let centerStar = 3 - monthDiff - (yearDiff * 9);
  while (centerStar <= 0) centerStar += 9;
  while (centerStar > 9) centerStar -= 9;
  return centerStar;
}

export function calculatePeriod2StarGrid(year: number, month: number): Period2StarData[] {
  const periodStars = [1, 6, 8, 9, 2, 4, 5, 7, 3]; // SE, S, SW, E, Center, W, NE, N, NW
  const annualCenter = getAnnualCenterStar(year);
  const monthlyCenter = getMonthlyCenterStar(year, month);
  const annualStars = distributeStars(annualCenter);
  const monthlyStars = distributeStars(monthlyCenter);
  const directions = ['SE', 'S', 'SW', 'E', 'Center', 'W', 'NE', 'N', 'NW'];
  
  return directions.map((dir, i) => ({
    sector: dir,
    periodStar: periodStars[i],
    annualStar: annualStars[i],
    monthlyStar: monthlyStars[i],
    direction: dir
  }));
}

export function isPeriod2Active(year: number, month: number): boolean {
  if (year < 2064) return false;
  if (year > 2083) return false;
  if (year === 2064 && month < 2) return false;
  if (year === 2083 && month > 2) return false;
  if (year === 2083 && month === 2) return true;
  return true;
}
