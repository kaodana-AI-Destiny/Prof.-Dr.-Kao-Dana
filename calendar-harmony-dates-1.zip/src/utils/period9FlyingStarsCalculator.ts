// Period 9 Flying Stars Calculator with Year, Month, Day, Time
import { getPeriod } from './flyingStarsCalculator';

export interface Period9FlyingStars {
  yearStar: number;
  monthStar: number;
  dayStar: number;
  timeStar: number;
  clashDirection: string;
  clashDegrees: number;
}

export interface Period9StarData {
  sector: string;
  periodStar: number;
  annualStar: number;
  direction: string;
}


const earthlyBranches = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
const branchToDirection: Record<string, { name: string; degrees: number }> = {
  '子': { name: 'North', degrees: 0 },
  '丑': { name: 'NNE', degrees: 30 },
  '寅': { name: 'ENE', degrees: 60 },
  '卯': { name: 'East', degrees: 90 },
  '辰': { name: 'ESE', degrees: 120 },
  '巳': { name: 'SSE', degrees: 150 },
  '午': { name: 'South', degrees: 180 },
  '未': { name: 'SSW', degrees: 210 },
  '申': { name: 'WSW', degrees: 240 },
  '酉': { name: 'West', degrees: 270 },
  '戌': { name: 'WNW', degrees: 300 },
  '亥': { name: 'NNW', degrees: 330 }
};

export function calculatePeriod9FlyingStars(date: Date, hour: number): Period9FlyingStars {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  // Year Star - 2025 = Center 2, decreases by 1 each year
  let yearStar = 2 - (year - 2025);
  while (yearStar <= 0) yearStar += 9;
  while (yearStar > 9) yearStar -= 9;
  
  // Month Star (based on month)
  const monthStar = ((month - 1) % 9) + 1;
  
  // Day Star (based on day of month)
  const dayStar = ((day - 1) % 9) + 1;
  
  // Time Star (based on hour - Chinese 2-hour periods)
  const timeIndex = Math.floor((hour + 1) / 2) % 12;
  const timeStar = ((timeIndex) % 9) + 1;
  
  // Calculate clash direction based on year branch
  const yearBranch = earthlyBranches[(year - 4) % 12];
  const clashIndex = (earthlyBranches.indexOf(yearBranch) + 6) % 12;
  const clashBranch = earthlyBranches[clashIndex];
  const clashInfo = branchToDirection[clashBranch];
  
  return {
    yearStar,
    monthStar,
    dayStar,
    timeStar,
    clashDirection: clashInfo.name,
    clashDegrees: clashInfo.degrees
  };
}



// Get period stars based on year (grid order: SE, S, SW, E, Center, W, NE, N, NW)
function getPeriodStarsForYear(year: number): number[] {
  let effectiveYear = year;
  
  // Period 9: 2024-2043, Period 1: 2044-2063, Period 2: 2064-2083
  if (effectiveYear >= 2024 && effectiveYear <= 2043) {
    return [8, 4, 6, 7, 9, 2, 3, 5, 1]; // Period 9
  } else if (effectiveYear >= 2044 && effectiveYear <= 2063) {
    return [9, 5, 7, 8, 1, 3, 4, 6, 2]; // Period 1
  } else if (effectiveYear >= 2064 && effectiveYear <= 2083) {
    return [1, 6, 8, 9, 2, 4, 5, 7, 3]; // Period 2
  }
  return [8, 4, 6, 7, 9, 2, 3, 5, 1]; // Default to Period 9
}

function distributeStars(centerStar: number): number[] {
  const luoShuPositions = [4, 9, 2, 3, 5, 7, 8, 1, 6];
  return luoShuPositions.map(pos => {
    let star = centerStar + (pos - 5);
    while (star <= 0) star += 9;
    while (star > 9) star -= 9;
    return star;
  });
}

export function calculatePeriod9StarGrid(year: number): Period9StarData[] {
  const periodStars = getPeriodStarsForYear(year);
  
  // Calculate annual center star: 2025 = Center 2, decreases by 1 each year
  let annualCenter = 2 - (year - 2025);
  while (annualCenter <= 0) annualCenter += 9;
  while (annualCenter > 9) annualCenter -= 9;
  
  const annualStars = distributeStars(annualCenter);
  const directions = ['SE', 'S', 'SW', 'E', 'Center', 'W', 'NE', 'N', 'NW'];
  
  return directions.map((dir, i) => ({
    sector: dir,
    periodStar: periodStars[i],
    annualStar: annualStars[i],
    direction: dir
  }));
}

