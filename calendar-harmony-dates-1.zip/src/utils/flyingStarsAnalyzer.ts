import { starMeanings, combinations } from '../data/flyingStarsCombinations';

export interface StarAnalysis {
  sector: string;
  periodStar: number;
  annualStar: number;
  monthlyStar: number;
  interpretation: string;
  remedy: string;
  rating: "excellent" | "good" | "neutral" | "poor" | "dangerous";
  details: string;
}

export function analyzeThreeStars(
  sector: string,
  period: number,
  annual: number,
  monthly: number
): StarAnalysis {
  const key1 = `${period}-${annual}`;
  const key2 = `${annual}-${monthly}`;
  const key3 = `${period}-${monthly}`;
  
  let combo = combinations[key1] || combinations[key2] || combinations[key3];
  
  const hasEvil = [period, annual, monthly].some(s => [2, 3, 5, 7].includes(s));
  const hasGood = [period, annual, monthly].some(s => [1, 4, 6, 8, 9].includes(s));
  const has5 = [period, annual, monthly].includes(5);
  const has2 = [period, annual, monthly].includes(2);
  
  if (!combo) {
    if (has5 && has2) {
      combo = { interpretation: "Illness & Misfortune", remedy: "Metal wind chimes, salt water", rating: "dangerous" };
    } else if (has5) {
      combo = { interpretation: "Misfortune Present", remedy: "6-rod metal wind chime", rating: "poor" };
    } else if (hasEvil && !hasGood) {
      combo = { interpretation: "Challenging Energy", remedy: "Metal or water elements", rating: "poor" };
    } else if (hasGood && !hasEvil) {
      combo = { interpretation: "Favorable Energy", remedy: "Enhance with appropriate elements", rating: "good" };
    } else {
      combo = { interpretation: "Mixed Energy", remedy: "Balance with five elements", rating: "neutral" };
    }
  }
  
  const details = `Period ${period} (${starMeanings[period].name} ${starMeanings[period].element}), Annual ${annual}, Monthly ${monthly}`;
  
  return {
    sector,
    periodStar: period,
    annualStar: annual,
    monthlyStar: monthly,
    interpretation: combo.interpretation,
    remedy: combo.remedy,
    rating: combo.rating,
    details
  };
}
