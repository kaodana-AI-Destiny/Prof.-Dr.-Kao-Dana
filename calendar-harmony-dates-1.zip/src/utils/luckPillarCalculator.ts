import { heavenlyStems, earthlyBranches, calculateTenGod, type BaZiChart } from './baziCalculator';

export interface LuckPillar {
  startAge: number;
  endAge: number;
  stem: typeof heavenlyStems[0];
  branch: typeof earthlyBranches[0];
  element: string;
  polarity: string;
  tenGod: {
    chinese: string;
    pinyin: string;
    english: string;
  };
  interactions: {
    favorable: string[];
    challenging: string[];
    strengthens: string[];
    weakens: string[];
  };
}

export function calculateLuckPillars(
  birthDate: Date,
  gender: 'male' | 'female',
  baziChart: BaZiChart
): { startingAge: number; pillars: LuckPillar[] } {
  const year = birthDate.getFullYear();
  const month = birthDate.getMonth() + 1;
  
  // Determine if year is Yang or Yin based on year stem
  const yearStemPolarity = baziChart.year.stem.polarity;
  
  // Calculate starting age based on gender and year polarity
  // Male Yang year or Female Yin year: forward counting
  // Male Yin year or Female Yang year: backward counting
  const isForward = (gender === 'male' && yearStemPolarity === 'Yang') || 
                    (gender === 'female' && yearStemPolarity === 'Yin');
  
  // Starting age calculation (simplified - typically 1-10 years)
  const startingAge = isForward ? 3 : 7;
  
  // Get month pillar indices
  const monthStemIndex = heavenlyStems.findIndex(s => s.name === baziChart.month.stem.name);
  const monthBranchIndex = earthlyBranches.findIndex(b => b.name === baziChart.month.branch.name);
  
  const pillars: LuckPillar[] = [];
  
  // Generate 8 luck pillars (80 years)
  for (let i = 0; i < 8; i++) {
    const stemIndex = isForward ? 
      (monthStemIndex + i + 1) % 10 : 
      (monthStemIndex - i - 1 + 10) % 10;
    const branchIndex = isForward ? 
      (monthBranchIndex + i + 1) % 12 : 
      (monthBranchIndex - i - 1 + 12) % 12;
    
    const stem = heavenlyStems[stemIndex];
    const branch = earthlyBranches[branchIndex];
    const tenGod = calculateTenGod(baziChart.dayMaster, stem);
    
    const interactions = analyzeLuckPillarInteractions(stem, branch, baziChart);
    
    pillars.push({
      startAge: startingAge + (i * 10),
      endAge: startingAge + (i * 10) + 9,
      stem,
      branch,
      element: stem.element,
      polarity: stem.polarity,
      tenGod,
      interactions
    });
  }
  
  return { startingAge, pillars };
}

function analyzeLuckPillarInteractions(
  stem: typeof heavenlyStems[0],
  branch: typeof earthlyBranches[0],
  baziChart: BaZiChart
): LuckPillar['interactions'] {
  const favorable: string[] = [];
  const challenging: string[] = [];
  const strengthens: string[] = [];
  const weakens: string[] = [];
  
  const dayMaster = baziChart.dayMaster;
  const pillarElement = stem.element;
  
  // Element cycle analysis
  const elementProduces: { [key: string]: string } = {
    Wood: "Fire", Fire: "Earth", Earth: "Metal", Metal: "Water", Water: "Wood"
  };
  const elementControls: { [key: string]: string } = {
    Wood: "Earth", Earth: "Water", Water: "Fire", Fire: "Metal", Metal: "Wood"
  };
  
  // Check if pillar strengthens day master
  if (pillarElement === dayMaster.element) {
    strengthens.push(`Strengthens ${dayMaster.element} Day Master`);
    favorable.push("Same element support");
  }
  
  if (elementProduces[pillarElement] === dayMaster.element) {
    strengthens.push(`Produces ${dayMaster.element} energy`);
    favorable.push("Nourishing influence");
  }
  
  if (elementControls[pillarElement] === dayMaster.element) {
    weakens.push(`Controls ${dayMaster.element} Day Master`);
    challenging.push("Restrictive pressure");
  }
  
  if (elementControls[dayMaster.element] === pillarElement) {
    favorable.push("Day Master controls this element");
  }
  
  // Check element balance
  const currentElements = baziChart.elements;
  if (currentElements[pillarElement] < 2) {
    favorable.push(`Balances weak ${pillarElement}`);
  } else if (currentElements[pillarElement] > 3) {
    challenging.push(`Excess ${pillarElement} energy`);
  }
  
  return { favorable, challenging, strengthens, weakens };
}
