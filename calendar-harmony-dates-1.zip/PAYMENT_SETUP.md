# Payment Verification System Setup

## Supabase Configuration

### 1. Environment Variables
Create a `.env` file in the root directory:
```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 2. Database Schema
Run this SQL in your Supabase SQL Editor:

```sql
-- Create payment_verifications table
CREATE TABLE payment_verifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_name TEXT NOT NULL,
  user_email TEXT NOT NULL,
  user_phone TEXT NOT NULL,
  plan_name TEXT NOT NULL,
  plan_price TEXT NOT NULL,
  receipt_url TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  verified_at TIMESTAMP WITH TIME ZONE,
  admin_notes TEXT
);

-- Create storage bucket for receipts
INSERT INTO storage.buckets (id, name, public) VALUES ('payment-receipts', 'payment-receipts', true);

-- Allow public uploads
CREATE POLICY "Allow public uploads" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'payment-receipts');

-- Allow public reads
CREATE POLICY "Allow public reads" ON storage.objects FOR SELECT USING (bucket_id = 'payment-receipts');
```

## Usage

1. Users click "I've Paid" after payment
2. Upload receipt with contact details
3. Admin visits `/admin` to review submissions
4. Admin approves/rejects with optional notes
5. Real-time updates via Supabase subscriptions

## Admin Access
Navigate to `/admin` to access the verification panel.
